/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const STATE_FILE = path.join(DATA_DIR, 'csc_state.json');

app.use(express.json({ limit: '10mb' }));

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

import { createDefaultState } from './src/services/auctionStore';
import { generateSmartQueue } from './src/data/initialData';
import {
  getNextMinimumBid,
  validateBidAmount,
  checkTeamEligibility,
  OPENING_BID,
  INITIAL_TIMER_SECONDS,
  EXTENSION_DURATION_SECONDS,
  EXTENSION_THRESHOLD_SECONDS,
} from './src/utils/auctionRules';
import { Bid, SaleRecord } from './src/types/auction';

// Lock flag to prevent concurrent bidding, timer, or sale operations during reset
let isResettingAuction = false;

// In-memory state cache
let serverState: any = null;

if (fs.existsSync(STATE_FILE)) {
  try {
    serverState = JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
    console.log('[Server] Loaded persisted state from disk');
  } catch (e) {
    console.warn('[Server] Could not parse persisted state:', e);
  }
}

if (!serverState) {
  serverState = createDefaultState();
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(serverState, null, 2), 'utf-8');
    console.log('[Server] Initialized new authoritative event state on disk');
  } catch (err) {
    console.warn('[Server] Could not write initial state:', err);
  }
}

// Ensure initial 30 teams credentials match TEAM1..TEAM30 and 00001..00030
if (serverState && Array.isArray(serverState.teams)) {
  let updatedCreds = false;
  for (let i = 1; i <= 30; i++) {
    const t = serverState.teams.find((item: any) => item.id === `team-${i}`);
    const expectedLoginId = `TEAM${i}`;
    const expectedPassword = i.toString().padStart(5, '0');
    if (t) {
      if (t.loginId !== expectedLoginId || t.plainPassword !== expectedPassword) {
        t.loginId = expectedLoginId;
        t.plainPassword = expectedPassword;
        updatedCreds = true;
      }
    }
  }
  if (updatedCreds) {
    try {
      fs.writeFileSync(STATE_FILE, JSON.stringify(serverState, null, 2), 'utf-8');
      console.log('[Server] Synchronized TEAM1-TEAM30 credentials on disk');
    } catch (e) {
      console.warn('[Server] Could not write updated credentials to disk:', e);
    }
  }
}

// Authoritative Server-Side Timer Loop (1 second tick)
setInterval(() => {
  if (
    serverState &&
    serverState.currentAuction &&
    serverState.currentAuction.timerIsRunning &&
    serverState.currentAuction.status === 'ACTIVE' &&
    serverState.currentAuction.timerDeadline
  ) {
    const now = Date.now();
    const rem = Math.max(0, Math.ceil((serverState.currentAuction.timerDeadline - now) / 1000));
    serverState.currentAuction.timerSeconds = rem;

    if (rem <= 0) {
      serverState.currentAuction.timerSeconds = 0;
      serverState.currentAuction.timerIsRunning = false;
      serverState.currentAuction.status = 'CONCLUDED';
      serverState.currentAuction.timerDeadline = null;

      serverState.auditLogs.unshift({
        id: `log-${now}-expired`,
        action: 'TIMER_EXPIRED',
        details: `Auction timer reached 00:00 for "${serverState.currentAuction.card?.name || 'card'}". Bids closed. Awaiting administrator sale decision (no automatic sale).`,
        actor: 'SYSTEM',
        timestamp: now,
      });

      console.log('[Server Timer] Timer expired. Auction marked CONCLUDED. No automatic sale.');
      broadcastState(serverState);
    }
  }
}, 500);

// SSE Connected clients
const sseClients: Response[] = [];

function broadcastState(state: any) {
  state.lastUpdated = Date.now();
  serverState = state;
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf-8');
  } catch (err) {
    console.warn('[Server] Failed to write state to disk:', err);
  }

  const payload = `data: ${JSON.stringify({ type: 'STATE_UPDATE', state })}\n\n`;
  for (let i = sseClients.length - 1; i >= 0; i--) {
    try {
      sseClients[i].write(payload);
    } catch (e) {
      sseClients.splice(i, 1);
    }
  }
}

// --- API ROUTES ---

// SSE Stream
app.get('/api/auction/events', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  sseClients.push(res);

  // Send current state immediately on connect (calculating live remaining seconds)
  if (serverState) {
    if (serverState.currentAuction && serverState.currentAuction.timerDeadline && serverState.currentAuction.timerIsRunning) {
      serverState.currentAuction.timerSeconds = Math.max(0, Math.ceil((serverState.currentAuction.timerDeadline - Date.now()) / 1000));
    }
    res.write(`data: ${JSON.stringify({ type: 'INITIAL_STATE', state: serverState })}\n\n`);
  }

  // Keep-alive heartbeat
  const heartbeat = setInterval(() => {
    try {
      res.write(': keep-alive\n\n');
    } catch (err) {
      clearInterval(heartbeat);
    }
  }, 15000);

  req.on('close', () => {
    clearInterval(heartbeat);
    const index = sseClients.indexOf(res);
    if (index !== -1) sseClients.splice(index, 1);
  });
});

// GET current state
app.get('/api/auction/state', (_req: Request, res: Response) => {
  if (serverState && serverState.currentAuction && serverState.currentAuction.timerDeadline && serverState.currentAuction.timerIsRunning) {
    serverState.currentAuction.timerSeconds = Math.max(0, Math.ceil((serverState.currentAuction.timerDeadline - Date.now()) / 1000));
  }
  res.json({ state: serverState });
});

// POST sync state (full state sync fallback)
app.post('/api/auction/sync', (req: Request, res: Response) => {
  const incoming = req.body;
  if (incoming && incoming.lastUpdated) {
    if (!serverState || incoming.lastUpdated >= (serverState.lastUpdated || 0)) {
      broadcastState(incoming);
    }
  }
  res.json({ success: true, state: serverState });
});

// POST load card
app.post('/api/auction/load-card', (req: Request, res: Response) => {
  if (isResettingAuction) {
    return res.status(423).json({ success: false, error: 'Auction is currently resetting.' });
  }

  const { cardId } = req.body;
  if (!serverState) return res.status(500).json({ success: false, error: 'Server not ready' });

  const card = serverState.cards.find((c: any) => c.id === cardId);
  if (!card) return res.status(404).json({ success: false, error: 'Card not found' });

  // Reset previous card if in auction
  if (serverState.currentAuction.cardId && serverState.currentAuction.cardId !== cardId) {
    const prev = serverState.cards.find((c: any) => c.id === serverState.currentAuction.cardId);
    if (prev && prev.status === 'IN_AUCTION') {
      prev.status = 'AVAILABLE';
    }
  }

  card.status = 'IN_AUCTION';

  // Fresh 60-second countdown initialized in READY state
  serverState.currentAuction = {
    cardId: card.id,
    card: { ...card },
    status: 'READY',
    currentBid: OPENING_BID,
    currentBidder: null,
    confirmedFinalBid: null,
    confirmedFinalBidStatus: 'NONE',
    bidCount: 0,
    timerSeconds: INITIAL_TIMER_SECONDS, // Exactly 60s
    timerDuration: INITIAL_TIMER_SECONDS,
    timerIsRunning: false,
    timerHasExtended: false,
    timerDeadline: null,
    auctionAttemptId: `att-${Date.now()}-${card.id}`,
    completedSale: null,
  };

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-load`,
    action: 'LOAD_CARD',
    details: `Card loaded: "${card.name}" (${card.category} - ${card.sector}). Timer reset to 01:00 (READY).`,
    actor: 'ADMINISTRATOR',
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({ success: true, state: serverState });
});

// POST timer control
app.post('/api/auction/timer', (req: Request, res: Response) => {
  if (isResettingAuction) {
    return res.status(423).json({ success: false, error: 'Auction is currently resetting.' });
  }

  const { action } = req.body;
  if (!serverState || !serverState.currentAuction) {
    return res.status(500).json({ success: false, error: 'No active auction' });
  }

  const auction = serverState.currentAuction;
  if (!auction.card) {
    return res.status(400).json({ success: false, error: 'No card loaded' });
  }

  const now = Date.now();

  if (action === 'START' || action === 'RESUME') {
    const duration = auction.timerSeconds > 0 ? auction.timerSeconds : INITIAL_TIMER_SECONDS;
    auction.timerSeconds = duration;
    auction.timerDeadline = now + duration * 1000;
    auction.timerIsRunning = true;
    auction.status = 'ACTIVE';

    serverState.auditLogs.unshift({
      id: `log-${now}-start`,
      action: action === 'START' ? 'START_TIMER' : 'RESUME_TIMER',
      details: `Countdown started from ${duration}s. Deadline set to ${new Date(auction.timerDeadline).toISOString()}`,
      actor: 'ADMINISTRATOR',
      timestamp: now,
    });
  } else if (action === 'PAUSE') {
    if (auction.timerDeadline) {
      auction.timerSeconds = Math.max(0, Math.ceil((auction.timerDeadline - now) / 1000));
    }
    auction.timerDeadline = null;
    auction.timerIsRunning = false;
    auction.status = 'PAUSED';

    serverState.auditLogs.unshift({
      id: `log-${now}-pause`,
      action: 'PAUSE_TIMER',
      details: `Countdown paused at ${auction.timerSeconds}s remaining.`,
      actor: 'ADMINISTRATOR',
      timestamp: now,
    });
  } else if (action === 'RESET') {
    auction.timerSeconds = INITIAL_TIMER_SECONDS;
    auction.timerDuration = INITIAL_TIMER_SECONDS;
    auction.timerDeadline = null;
    auction.timerIsRunning = false;
    auction.timerHasExtended = false;
    auction.status = 'READY';

    serverState.auditLogs.unshift({
      id: `log-${now}-reset`,
      action: 'RESET_TIMER',
      details: `Timer reset to initial 60 seconds (READY).`,
      actor: 'ADMINISTRATOR',
      timestamp: now,
    });
  } else if (action === 'EXTEND') {
    auction.timerSeconds += EXTENSION_DURATION_SECONDS;
    if (auction.timerDeadline) {
      auction.timerDeadline += EXTENSION_DURATION_SECONDS * 1000;
    }
    serverState.auditLogs.unshift({
      id: `log-${now}-manual-ext`,
      action: 'TIMER_MANUAL_EXTENSION',
      details: `Manual +20s extension added by administrator.`,
      actor: 'ADMINISTRATOR',
      timestamp: now,
    });
  }

  broadcastState(serverState);
  res.json({ success: true, state: serverState });
});

// POST submit authoritative bid
app.post('/api/auction/bid', (req: Request, res: Response) => {
  if (isResettingAuction) {
    return res.status(423).json({ success: false, error: 'Auction is currently resetting. Bidding operations are temporarily disabled.' });
  }

  if (!serverState || !serverState.currentAuction) {
    return res.status(500).json({ success: false, error: 'Server not ready' });
  }

  const auction = serverState.currentAuction;
  if (!auction.card) {
    return res.status(400).json({ success: false, error: 'Cannot bid: No card loaded in auction' });
  }

  if (auction.status === 'SOLD' || auction.status === 'UNSOLD') {
    return res.status(400).json({ success: false, error: 'Auction round has concluded' });
  }

  const now = Date.now();

  // Check timer expiry
  if (auction.status === 'CONCLUDED' || (auction.timerIsRunning && auction.timerDeadline && now >= auction.timerDeadline)) {
    auction.timerSeconds = 0;
    auction.timerIsRunning = false;
    auction.status = 'CONCLUDED';
    auction.timerDeadline = null;
    broadcastState(serverState);
    return res.status(400).json({ success: false, error: 'Auction timer has expired (00:00). Bids can no longer be accepted.' });
  }

  // Calculate next valid bid
  const nextMin = getNextMinimumBid(auction.currentBid, auction.bidCount);
  const amount = Number(req.body.amount) || nextMin;

  const validation = validateBidAmount(amount, auction.currentBid, auction.bidCount);
  if (!validation.valid) {
    return res.status(400).json({ success: false, error: validation.error || 'Invalid bid amount' });
  }

  const isUnassigned = !!req.body.isUnassignedAdmin || !req.body.teamId;
  let bidderId: string | null = null;
  let bidderName = 'Administrator (Unassigned)';

  if (!isUnassigned && req.body.teamId) {
    const team = serverState.teams.find((t: any) => t.id === req.body.teamId);
    if (!team) {
      return res.status(400).json({ success: false, error: 'Selected team not found' });
    }
    const eligibility = checkTeamEligibility(team, auction.card.category, amount);
    if (!eligibility.eligible) {
      return res.status(400).json({ success: false, error: eligibility.reason });
    }
    bidderId = team.id;
    bidderName = team.name;
  }

  // Auto-start 60s countdown if bid placed from READY state
  if (auction.status === 'READY') {
    auction.status = 'ACTIVE';
    auction.timerIsRunning = true;
    auction.timerSeconds = INITIAL_TIMER_SECONDS;
    auction.timerDeadline = now + INITIAL_TIMER_SECONDS * 1000;
  }

  // Timer check: if active and <= 10 seconds remaining, trigger one-time 20-second extension (timer reset to 20s)
  if (auction.timerIsRunning && !auction.timerHasExtended && auction.timerDeadline) {
    const remSecs = Math.max(0, Math.ceil((auction.timerDeadline - now) / 1000));
    if (remSecs <= EXTENSION_THRESHOLD_SECONDS && remSecs > 0) {
      auction.timerHasExtended = true;
      auction.timerSeconds = EXTENSION_DURATION_SECONDS;
      auction.timerDeadline = now + EXTENSION_DURATION_SECONDS * 1000;

      serverState.auditLogs.unshift({
        id: `log-${now}-ext`,
        action: 'TIMER_EXTENSION',
        details: `One-time 20-second extension triggered (timer reset to 20s) by bid of ₹${amount.toLocaleString('en-IN')} with ${remSecs}s remaining`,
        actor: 'SYSTEM',
        timestamp: now,
      });
    }
  }

  const bidRecord: Bid = {
    id: `bid-${now}-${Math.random().toString(36).substring(2, 6)}`,
    auctionAttemptId: auction.auctionAttemptId,
    cardId: auction.card.id,
    cardName: auction.card.name,
    amount,
    bidderId,
    bidderName: isUnassigned ? null : bidderName,
    isUnassignedAdmin: isUnassigned,
    timestamp: now,
  };

  // Update auction state
  auction.currentBid = amount;
  auction.bidCount += 1;
  auction.currentBidder = {
    id: bidderId,
    name: bidderName,
    isUnassignedAdmin: isUnassigned,
  };

  serverState.bidHistory.unshift(bidRecord);

  serverState.auditLogs.unshift({
    id: `log-${now}-bid`,
    action: 'ACCEPTED_BID',
    details: `Accepted bid of ₹${amount.toLocaleString('en-IN')} by ${bidderName}`,
    actor: isUnassigned ? 'ADMINISTRATOR' : bidderName,
    timestamp: now,
  });

  broadcastState(serverState);
  res.json({ success: true, bid: bidRecord, state: serverState });
});

// POST set confirmed final bid
app.post('/api/auction/set-final-bid', (req: Request, res: Response) => {
  const amount = Number(req.body.amount);
  if (isNaN(amount) || amount < OPENING_BID) {
    return res.status(400).json({ success: false, error: 'Final bid must be at least ₹10 Lakh' });
  }

  serverState.currentAuction.confirmedFinalBid = amount;
  serverState.currentAuction.confirmedFinalBidStatus = 'CONFIRMED';

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-finbid`,
    action: 'SET_FINAL_BID',
    details: `Confirmed final bid set to ₹${amount.toLocaleString('en-IN')}`,
    actor: 'ADMINISTRATOR',
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({ success: true, state: serverState });
});

// POST sell card
app.post('/api/auction/sell', (req: Request, res: Response) => {
  if (isResettingAuction) {
    return res.status(423).json({ success: false, error: 'Auction is currently resetting. Sales are temporarily disabled.' });
  }

  const { teamId, amount: rawAmount } = req.body;
  const auction = serverState.currentAuction;

  if (!auction.card) {
    return res.status(400).json({ success: false, error: 'No card loaded in auction' });
  }
  if (auction.status === 'SOLD') {
    return res.status(400).json({ success: false, error: 'This card has already been sold' });
  }

  const card = serverState.cards.find((c: any) => c.id === auction.card.id);
  if (!card || card.status === 'SOLD') {
    return res.status(400).json({ success: false, error: 'Card is no longer available for sale' });
  }

  const team = serverState.teams.find((t: any) => t.id === teamId);
  if (!team) {
    return res.status(400).json({ success: false, error: 'Please select a valid winning team' });
  }

  const amount = Math.round(Number(rawAmount) || auction.confirmedFinalBid || auction.currentBid);
  if (amount < OPENING_BID) {
    return res.status(400).json({ success: false, error: 'Sale amount cannot be less than opening bid' });
  }

  const eligibility = checkTeamEligibility(team, card.category, amount);
  if (!eligibility.eligible) {
    return res.status(400).json({ success: false, error: eligibility.reason });
  }

  const now = Date.now();
  const saleId = `sale-${now}-${team.id}`;

  // Deduct from budget
  team.remainingBudget -= amount;
  team.totalSpent += amount;

  // Add to portfolio
  team.acquiredCards.push({
    cardId: card.id,
    cardName: card.name,
    category: card.category,
    sector: card.sector,
    amount,
    timestamp: now,
    attemptId: auction.auctionAttemptId,
  });
  team.categoryProgress[card.category] = true;

  // Mark card SOLD
  card.status = 'SOLD';

  // Record in sales register
  const saleRecord: SaleRecord = {
    id: saleId,
    auctionAttemptId: auction.auctionAttemptId,
    cardId: card.id,
    cardName: card.name,
    category: card.category,
    sector: card.sector,
    winningTeamId: team.id,
    winningTeamName: team.name,
    amount,
    timestamp: now,
    isReversed: false,
  };
  serverState.salesRegister.unshift(saleRecord);

  // Update auction state
  auction.status = 'SOLD';
  auction.timerIsRunning = false;
  auction.timerDeadline = null;
  auction.completedSale = {
    cardId: card.id,
    cardName: card.name,
    category: card.category,
    sector: card.sector,
    winningTeamId: team.id,
    winningTeamName: team.name,
    amount,
    timestamp: now,
    attemptId: auction.auctionAttemptId,
  };

  serverState.auditLogs.unshift({
    id: `log-${now}-sale`,
    action: 'SALE_CONFIRMED',
    details: `Card "${card.name}" SOLD to ${team.name} for ₹${amount.toLocaleString('en-IN')}. Remaining budget: ₹${team.remainingBudget.toLocaleString('en-IN')}`,
    actor: 'ADMINISTRATOR',
    timestamp: now,
  });

  broadcastState(serverState);
  res.json({ success: true, state: serverState });
});

// POST mark unsold
app.post('/api/auction/no-sale', (req: Request, res: Response) => {
  if (isResettingAuction) {
    return res.status(423).json({ success: false, error: 'Auction is currently resetting.' });
  }

  const auction = serverState.currentAuction;
  if (!auction.card) {
    return res.status(400).json({ success: false, error: 'No card loaded' });
  }

  const card = serverState.cards.find((c: any) => c.id === auction.card.id);
  if (card) {
    card.status = 'UNSOLD';
  }

  auction.status = 'UNSOLD';
  auction.timerIsRunning = false;
  auction.timerDeadline = null;
  auction.completedSale = null;

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-unsold`,
    action: 'MARK_UNSOLD',
    details: `Card "${auction.card.name}" marked as UNSOLD (No Sale)`,
    actor: 'ADMINISTRATOR',
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({ success: true, state: serverState });
});

// POST undo last sale
app.post('/api/auction/undo-sale', (req: Request, res: Response) => {
  if (isResettingAuction) {
    return res.status(423).json({ success: false, error: 'Auction is currently resetting.' });
  }

  const { saleId } = req.body;
  const saleToUndo = saleId
    ? serverState.salesRegister.find((s: any) => s.id === saleId && !s.isReversed)
    : serverState.salesRegister.find((s: any) => !s.isReversed);

  if (!saleToUndo) {
    return res.status(400).json({ success: false, error: 'No eligible sale found to reverse' });
  }

  const team = serverState.teams.find((t: any) => t.id === saleToUndo.winningTeamId);
  if (!team) {
    return res.status(400).json({ success: false, error: 'Associated team not found' });
  }

  const card = serverState.cards.find((c: any) => c.id === saleToUndo.cardId);

  // Restore budget exactly once
  team.remainingBudget += saleToUndo.amount;
  team.totalSpent = Math.max(0, team.totalSpent - saleToUndo.amount);

  // Remove card from portfolio
  team.acquiredCards = team.acquiredCards.filter((ac: any) => ac.cardId !== saleToUndo.cardId);
  const remainingInCat = team.acquiredCards.some((ac: any) => ac.category === saleToUndo.category);
  team.categoryProgress[saleToUndo.category] = remainingInCat;

  if (card) {
    card.status = 'AVAILABLE';
  }

  saleToUndo.isReversed = true;
  saleToUndo.reversedAt = Date.now();

  if (serverState.currentAuction.completedSale && serverState.currentAuction.completedSale.cardId === saleToUndo.cardId) {
    serverState.currentAuction.status = 'READY';
    serverState.currentAuction.completedSale = null;
  }

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-undo`,
    action: 'UNDO_SALE',
    details: `Reversed sale of "${saleToUndo.cardName}" to ${saleToUndo.winningTeamName} (₹${saleToUndo.amount.toLocaleString('en-IN')}). Budget restored.`,
    actor: 'ADMINISTRATOR',
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({ success: true, state: serverState });
});

function checkAdminAuth(req: Request): boolean {
  const authHeader = req.headers['authorization'] || req.headers['x-admin-key'] || req.headers['x-admin-token'];
  const { adminPassword, adminUser } = req.body || {};
  return (
    authHeader === 'Bearer ANEKAL2026' ||
    authHeader === 'ANEKAL2026' ||
    req.headers['x-admin-key'] === 'ANEKAL2026' ||
    req.headers['x-admin-token'] === 'ANEKAL2026' ||
    adminPassword === 'ANEKAL2026' ||
    (adminUser === 'ALLIANCEONE2026' && adminPassword === 'ANEKAL2026')
  );
}

// POST reset auction (STRICTLY ADMINISTRATOR ONLY)
app.post('/api/auction/reset', (req: Request, res: Response) => {
  // 1. Enforce strict administrator authorization on backend
  if (!checkAdminAuth(req)) {
    console.warn('[Server] Unauthorized reset auction attempt blocked');
    return res.status(403).json({
      success: false,
      error: 'Access Denied: Only authenticated administrators can reset the auction. Team users cannot perform this operation.',
    });
  }

  if (isResettingAuction) {
    return res.status(409).json({ success: false, error: 'A reset operation is already in progress.' });
  }

  isResettingAuction = true;

  try {
    const now = Date.now();

    // 2. Safely archive current active bids and sales register to eventArchives for audit & recovery
    if (!Array.isArray(serverState.eventArchives)) {
      serverState.eventArchives = [];
    }
    if (
      (serverState.bidHistory && serverState.bidHistory.length > 0) ||
      (serverState.salesRegister && serverState.salesRegister.length > 0)
    ) {
      serverState.eventArchives.unshift({
        id: `archive-${now}`,
        archivedAt: now,
        bidsCount: serverState.bidHistory.length,
        salesCount: serverState.salesRegister.length,
        bidHistory: [...serverState.bidHistory],
        salesRegister: [...serverState.salesRegister],
      });
    }

    // Clear active bid history and sales register
    serverState.bidHistory = [];
    serverState.salesRegister = [];

    // 3. Restore all 120 cards to AVAILABLE status (preserving custom names, descriptions, categories, sectors)
    if (Array.isArray(serverState.cards)) {
      serverState.cards.forEach((card: any) => {
        card.status = 'AVAILABLE';
      });
    }

    // 4. Restore each team's available budget to ₹10 Crore, clear spending and portfolios (preserving credentials, passwords, accounts)
    if (Array.isArray(serverState.teams)) {
      serverState.teams.forEach((team: any) => {
        const baseBudget = team.initialBudget || 100_000_000;
        team.remainingBudget = baseBudget;
        team.totalSpent = 0;
        team.acquiredCards = [];
        team.categoryProgress = {
          STAKEHOLDER: false,
          CHALLENGE: false,
          CONSTRAINT: false,
          IMPACT: false,
        };
      });
    }

    // 5. Generate fresh card queue following strict category progression: Stakeholder -> Challenge -> Constraint -> Impact
    const newQueue = generateSmartQueue(serverState.cards);
    serverState.auctionQueue = newQueue;

    // 6. Setup fresh starting auction session: first eligible Stakeholder card ready, timer inactive at 60s
    const firstCardId = newQueue.length > 0 ? newQueue[0] : null;
    const firstCard = firstCardId ? serverState.cards.find((c: any) => c.id === firstCardId) : null;
    if (firstCard) {
      firstCard.status = 'IN_AUCTION';
    }

    serverState.currentAuction = {
      cardId: firstCard ? firstCard.id : null,
      card: firstCard ? { ...firstCard } : null,
      status: 'READY',
      currentBid: OPENING_BID,
      currentBidder: null,
      confirmedFinalBid: null,
      confirmedFinalBidStatus: 'NONE',
      bidCount: 0,
      timerSeconds: INITIAL_TIMER_SECONDS, // Exactly 60s
      timerDuration: INITIAL_TIMER_SECONDS,
      timerIsRunning: false, // Inactive until card is opened/started
      timerHasExtended: false,
      timerDeadline: null,
      auctionAttemptId: `att-${now}-${firstCard?.id || 'fresh'}`,
      completedSale: null,
    };

    // 7. Audit Log
    serverState.auditLogs.unshift({
      id: `log-${now}-reset-auction`,
      action: 'RESET_AUCTION',
      details: 'Auction reset to fresh starting state by administrator. All card statuses restored to Available, bids/sales cleared & archived, and 30 team budgets restored to ₹10 Crore. First Stakeholder card ready.',
      actor: 'ADMINISTRATOR',
      timestamp: now,
    });

    // 8. Persist & Broadcast to all screens via SSE
    broadcastState(serverState);

    console.log('[Server] Auction successfully reset to starting baseline by administrator.');
    return res.json({
      success: true,
      message: 'The auction has been successfully reset to its starting state. Stakeholder Card #1 loaded with a fresh 60-second timer.',
      state: serverState,
    });
  } catch (err: any) {
    console.error('[Server] Reset failed:', err);
    return res.status(500).json({
      success: false,
      error: `Failed to reset auction: ${err.message || 'Internal server error'}`,
    });
  } finally {
    isResettingAuction = false;
  }
});

// POST auth login
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { loginId, password, portal } = req.body;

  if (portal === 'admin') {
    // Standard secure admin verification
    const formattedId = (loginId || '').trim().toUpperCase();
    if (formattedId === 'ALLIANCEONE2026' && password === 'ANEKAL2026') {
      return res.json({
        success: true,
        user: { role: 'admin', name: 'ALLIANCEONE2026' },
      });
    }
    return res.status(401).json({ success: false, error: 'Invalid administrator credentials' });
  }

  // Team login verification
  if (serverState && Array.isArray(serverState.teams)) {
    const rawId = (loginId || '').trim().toUpperCase();
    const cleanId = rawId.replace(/\s+/g, '');
    const cleanPassword = String(password ?? '').trim();

    const team = serverState.teams.find((t: any) => {
      const tLoginClean = (t.loginId || '').replace(/\s+/g, '').toUpperCase();
      const tNameClean = (t.name || '').replace(/\s+/g, '').toUpperCase();
      return tLoginClean === cleanId || tNameClean === cleanId;
    });

    if (team) {
      if (team.isArchived) {
        return res.status(403).json({ success: false, error: 'This team account is archived' });
      }
      // String comparison preserving leading zeros
      if (team.plainPassword && String(team.plainPassword) === cleanPassword) {
        return res.json({
          success: true,
          user: {
            role: 'team',
            teamId: team.id,
            name: team.name,
            loginId: team.loginId,
          },
        });
      }
      return res.status(401).json({ success: false, error: 'Incorrect password' });
    }
  }

  return res.status(401).json({ success: false, error: 'Invalid team ID or password' });
});

// --- BANK CARD MANAGEMENT (ADMIN ONLY) ---

// GET all cards
app.get('/api/cards', (_req: Request, res: Response) => {
  if (!serverState || !Array.isArray(serverState.cards)) {
    return res.status(500).json({ success: false, error: 'Cards not initialized' });
  }
  res.json({ success: true, count: serverState.cards.length, cards: serverState.cards });
});

// POST edit card details
app.post('/api/cards/edit', (req: Request, res: Response) => {
  if (!checkAdminAuth(req)) {
    return res.status(403).json({
      success: false,
      error: 'Access Denied: Only authenticated administrators can edit bank cards.',
    });
  }

  const { cardId, name, category, sector, description } = req.body;
  if (!serverState || !serverState.cards) {
    return res.status(500).json({ success: false, error: 'Server not ready' });
  }

  const card = serverState.cards.find((c: any) => c.id === cardId);
  if (!card) {
    return res.status(404).json({ success: false, error: 'Card not found' });
  }

  if (!name || !name.trim()) {
    return res.status(400).json({ success: false, error: 'Card name/title is required' });
  }

  const validCategories = ['STAKEHOLDER', 'CHALLENGE', 'CONSTRAINT', 'IMPACT'];
  const validSectors = ['MOBILITY', 'WASTE MANAGEMENT', 'WATER MANAGEMENT'];

  if (category && !validCategories.includes(category)) {
    return res.status(400).json({ success: false, error: 'Invalid card category' });
  }

  if (sector && !validSectors.includes(sector)) {
    return res.status(400).json({ success: false, error: 'Invalid card sector' });
  }

  const oldName = card.name;
  card.name = name.trim();
  if (description !== undefined) card.description = description.trim();
  if (category) card.category = category;
  if (sector) card.sector = sector;

  // If card is currently active in auction, update the live auction card representation too
  if (serverState.currentAuction && serverState.currentAuction.cardId === cardId && serverState.currentAuction.card) {
    serverState.currentAuction.card.name = card.name;
    serverState.currentAuction.card.description = card.description;
    serverState.currentAuction.card.category = card.category;
    serverState.currentAuction.card.sector = card.sector;
  }

  // Update card details in sales register to keep names consistent across displays
  if (Array.isArray(serverState.salesRegister)) {
    serverState.salesRegister.forEach((s: any) => {
      if (s.cardId === cardId) {
        s.cardName = card.name;
        s.category = card.category;
        s.sector = card.sector;
      }
    });
  }

  // Update card details in team acquired card portfolios
  if (Array.isArray(serverState.teams)) {
    serverState.teams.forEach((t: any) => {
      if (Array.isArray(t.acquiredCards)) {
        t.acquiredCards.forEach((ac: any) => {
          if (ac.cardId === cardId) {
            ac.cardName = card.name;
            ac.category = card.category;
            ac.sector = card.sector;
          }
        });
      }
    });
  }

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-editcard`,
    action: 'EDIT_CARD',
    details: `Card "${card.id}" updated from "${oldName}" to "${card.name}" (${card.category} - ${card.sector}).`,
    actor: 'ADMINISTRATOR',
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({ success: true, card, state: serverState });
});

// POST add new card
app.post('/api/cards/add', (req: Request, res: Response) => {
  if (!checkAdminAuth(req)) {
    return res.status(403).json({
      success: false,
      error: 'Access Denied: Only authenticated administrators can add new cards.',
    });
  }

  const { id: rawId, name, category, sector, description } = req.body;
  if (!serverState || !Array.isArray(serverState.cards)) {
    return res.status(500).json({ success: false, error: 'Server not ready' });
  }

  if (!name || !name.trim()) {
    return res.status(400).json({ success: false, error: 'Card name/title is required' });
  }

  const validCategories = ['STAKEHOLDER', 'CHALLENGE', 'CONSTRAINT', 'IMPACT'];
  const validSectors = ['MOBILITY', 'WASTE MANAGEMENT', 'WATER MANAGEMENT'];

  if (!category || !validCategories.includes(category)) {
    return res.status(400).json({ success: false, error: 'Valid category (STAKEHOLDER, CHALLENGE, CONSTRAINT, IMPACT) is required' });
  }

  if (!sector || !validSectors.includes(sector)) {
    return res.status(400).json({ success: false, error: 'Valid sector (MOBILITY, WASTE MANAGEMENT, WATER MANAGEMENT) is required' });
  }

  let finalId = (rawId || '').trim().toUpperCase();
  if (!finalId) {
    const prefixMap: Record<string, string> = {
      STAKEHOLDER: 'STK',
      CHALLENGE: 'CHL',
      CONSTRAINT: 'CST',
      IMPACT: 'IMP',
    };
    const prefix = prefixMap[category] || 'CRD';
    // Find highest index with this prefix
    let maxNum = 0;
    serverState.cards.forEach((c: any) => {
      if (c.id && c.id.startsWith(prefix)) {
        const parts = c.id.split('-');
        const n = parseInt(parts[1] || '0', 10);
        if (!isNaN(n) && n > maxNum) maxNum = n;
      }
    });
    finalId = `${prefix}-${String(maxNum + 1).padStart(2, '0')}`;
  }

  if (serverState.cards.some((c: any) => c.id === finalId)) {
    return res.status(400).json({ success: false, error: `Card ID "${finalId}" already exists. Please provide a unique ID.` });
  }

  const newCard = {
    id: finalId,
    name: name.trim(),
    category,
    sector,
    description: (description || '').trim(),
    status: 'AVAILABLE',
    queueOrder: serverState.cards.length + 1,
  };

  serverState.cards.push(newCard);
  if (Array.isArray(serverState.auctionQueue)) {
    serverState.auctionQueue.push(finalId);
  }

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-addcard`,
    action: 'ADD_CARD',
    details: `Added new card "${newCard.name}" (${newCard.id}) to ${newCard.category} - ${newCard.sector}.`,
    actor: 'ADMINISTRATOR',
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({ success: true, card: newCard, state: serverState });
});

// POST archive card
app.post('/api/cards/archive', (req: Request, res: Response) => {
  if (!checkAdminAuth(req)) {
    return res.status(403).json({
      success: false,
      error: 'Access Denied: Only authenticated administrators can archive cards.',
    });
  }

  const { cardId, isArchived } = req.body;
  if (!serverState || !Array.isArray(serverState.cards)) {
    return res.status(500).json({ success: false, error: 'Server not ready' });
  }

  const card = serverState.cards.find((c: any) => c.id === cardId);
  if (!card) {
    return res.status(404).json({ success: false, error: 'Card not found' });
  }

  if (serverState.currentAuction && serverState.currentAuction.cardId === cardId && ['ACTIVE', 'READY'].includes(serverState.currentAuction.status)) {
    return res.status(400).json({ success: false, error: 'Cannot archive card while currently loaded in the live auction.' });
  }

  const shouldArchive = isArchived !== false;
  card.status = shouldArchive ? 'ARCHIVED' : 'AVAILABLE';

  if (shouldArchive) {
    if (Array.isArray(serverState.auctionQueue)) {
      serverState.auctionQueue = serverState.auctionQueue.filter((id: string) => id !== cardId);
    }
  } else {
    if (Array.isArray(serverState.auctionQueue) && !serverState.auctionQueue.includes(cardId)) {
      serverState.auctionQueue.push(cardId);
    }
  }

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-archivecard`,
    action: shouldArchive ? 'ARCHIVE_CARD' : 'UNARCHIVE_CARD',
    details: `Card "${card.name}" (${card.id}) ${shouldArchive ? 'archived' : 'restored to available'}.`,
    actor: 'ADMINISTRATOR',
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({ success: true, card, state: serverState });
});

// POST delete card (Strict safety: checks for sales & active auction)
app.post('/api/cards/delete', (req: Request, res: Response) => {
  if (!checkAdminAuth(req)) {
    return res.status(403).json({
      success: false,
      error: 'Access Denied: Only authenticated administrators can delete cards.',
    });
  }

  const { cardId } = req.body;
  if (!serverState || !Array.isArray(serverState.cards)) {
    return res.status(500).json({ success: false, error: 'Server not ready' });
  }

  const card = serverState.cards.find((c: any) => c.id === cardId);
  if (!card) {
    return res.status(404).json({ success: false, error: 'Card not found' });
  }

  if (serverState.currentAuction && serverState.currentAuction.cardId === cardId) {
    return res.status(400).json({ success: false, error: 'Cannot delete card currently loaded in the active auction.' });
  }

  const hasSale = Array.isArray(serverState.salesRegister) && serverState.salesRegister.some((s: any) => s.cardId === cardId && !s.isReversed);
  const inTeamPortfolio = Array.isArray(serverState.teams) && serverState.teams.some((t: any) =>
    Array.isArray(t.acquiredCards) && t.acquiredCards.some((ac: any) => ac.cardId === cardId)
  );

  if (hasSale || inTeamPortfolio || card.status === 'SOLD') {
    return res.status(400).json({
      success: false,
      error: `Cannot delete card "${card.name}" (${cardId}) because it has already been acquired by a team. Archive the card instead to protect transaction history and financial integrity.`,
    });
  }

  // Safe to delete
  serverState.cards = serverState.cards.filter((c: any) => c.id !== cardId);
  if (Array.isArray(serverState.auctionQueue)) {
    serverState.auctionQueue = serverState.auctionQueue.filter((id: string) => id !== cardId);
  }

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-deletecard`,
    action: 'DELETE_CARD',
    details: `Card "${card.name}" (${card.id}) permanently removed from card bank by administrator.`,
    actor: 'ADMINISTRATOR',
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({ success: true, message: `Card ${cardId} deleted successfully`, state: serverState });
});

// POST register team Google email
app.post('/api/team/register-email', (req: Request, res: Response) => {
  const { teamId, email, currentPassword } = req.body;
  if (!serverState || !serverState.teams) {
    return res.status(500).json({ success: false, error: 'Server not ready' });
  }

  const team = serverState.teams.find((t: any) => t.id === teamId);
  if (!team) return res.status(404).json({ success: false, error: 'Team not found' });

  if (team.isArchived) {
    return res.status(403).json({ success: false, error: 'This team account is archived' });
  }

  // Verify current team password
  if (String(team.plainPassword) !== String(currentPassword ?? '').trim()) {
    return res.status(401).json({ success: false, error: 'Current password verification failed' });
  }

  const cleanEmail = (email || '').trim().toLowerCase();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!cleanEmail || !emailRegex.test(cleanEmail)) {
    return res.status(400).json({ success: false, error: 'Please enter a valid Google email address' });
  }

  // Prevent duplicate email assignment across different teams
  const duplicate = serverState.teams.find(
    (t: any) => t.id !== team.id && t.registeredEmail?.toLowerCase() === cleanEmail && t.emailVerified
  );
  if (duplicate) {
    return res.status(400).json({ success: false, error: 'This email address is already linked to another verified team account' });
  }

  // 6-digit verification code
  const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
  team.registeredEmail = cleanEmail;
  team.emailVerified = false;
  team.emailVerificationCode = verificationCode;
  team.emailVerificationExpiry = Date.now() + 15 * 60 * 1000; // 15 mins

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-regemail`,
    action: 'REGISTER_TEAM_EMAIL',
    details: `Verification code generated for team "${team.name}" to link Google email "${cleanEmail}".`,
    actor: team.name,
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({
    success: true,
    message: `A 6-digit verification code has been dispatched to ${cleanEmail}. Please enter it to verify ownership.`,
    verificationCodeForDev: verificationCode,
    state: serverState,
  });
});

// POST verify team Google email
app.post('/api/team/verify-email', (req: Request, res: Response) => {
  const { teamId, code } = req.body;
  if (!serverState || !serverState.teams) {
    return res.status(500).json({ success: false, error: 'Server not ready' });
  }

  const team = serverState.teams.find((t: any) => t.id === teamId);
  if (!team) return res.status(404).json({ success: false, error: 'Team not found' });

  if (!team.emailVerificationCode || !team.emailVerificationExpiry) {
    return res.status(400).json({ success: false, error: 'No pending email verification for this team' });
  }

  if (Date.now() > team.emailVerificationExpiry) {
    return res.status(400).json({ success: false, error: 'Verification code has expired. Please request a new code.' });
  }

  if (String(team.emailVerificationCode).trim() !== String(code).trim()) {
    return res.status(400).json({ success: false, error: 'Invalid verification code. Please check and try again.' });
  }

  team.emailVerified = true;
  team.emailVerificationCode = undefined;
  team.emailVerificationExpiry = undefined;

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-veremail`,
    action: 'VERIFY_TEAM_EMAIL',
    details: `Google email "${team.registeredEmail}" successfully verified and locked to team "${team.name}".`,
    actor: team.name,
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({
    success: true,
    message: `Google email "${team.registeredEmail}" successfully verified and linked to your team account.`,
    state: serverState,
  });
});

// POST forgot password - request reset
app.post('/api/team/forgot-password', (req: Request, res: Response) => {
  const { loginId, email } = req.body;
  if (!serverState || !serverState.teams) {
    return res.status(500).json({ success: false, error: 'Server not ready' });
  }

  const cleanId = (loginId || '').trim().replace(/\s+/g, '').toUpperCase();
  const cleanEmail = (email || '').trim().toLowerCase();

  const team = serverState.teams.find((t: any) => {
    const tLogin = (t.loginId || '').replace(/\s+/g, '').toUpperCase();
    const tName = (t.name || '').replace(/\s+/g, '').toUpperCase();
    return tLogin === cleanId || tName === cleanId;
  });

  if (!team) {
    return res.status(404).json({ success: false, error: 'Team ID not found. Please verify your team ID (e.g., TEAM1).' });
  }

  if (!team.registeredEmail || !team.emailVerified) {
    return res.status(400).json({
      success: false,
      error: 'Account setup required: This team has not registered and verified a Google email address yet. Password recovery requires a verified email.',
    });
  }

  if (team.registeredEmail.toLowerCase() !== cleanEmail) {
    return res.status(400).json({
      success: false,
      error: 'The provided email address does not match the registered Google email address for this team.',
    });
  }

  const resetToken = `rst-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
  team.passwordResetToken = resetToken;
  team.passwordResetExpiry = Date.now() + 15 * 60 * 1000;

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-forgotpwd`,
    action: 'FORGOT_PASSWORD_REQUEST',
    details: `Password reset dispatched to verified email "${team.registeredEmail}" for "${team.name}".`,
    actor: team.name,
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({
    success: true,
    message: `A secure password reset token has been dispatched to ${cleanEmail}.`,
    resetToken,
  });
});

// POST reset password with token
app.post('/api/team/reset-password', (req: Request, res: Response) => {
  const { loginId, resetToken, newPassword } = req.body;
  if (!serverState || !serverState.teams) {
    return res.status(500).json({ success: false, error: 'Server not ready' });
  }

  const cleanId = (loginId || '').trim().replace(/\s+/g, '').toUpperCase();
  const team = serverState.teams.find((t: any) => {
    const tLogin = (t.loginId || '').replace(/\s+/g, '').toUpperCase();
    const tName = (t.name || '').replace(/\s+/g, '').toUpperCase();
    return tLogin === cleanId || tName === cleanId;
  });

  if (!team) return res.status(404).json({ success: false, error: 'Team not found' });

  if (!team.passwordResetToken || !team.passwordResetExpiry) {
    return res.status(400).json({ success: false, error: 'No active password reset request for this team' });
  }

  if (Date.now() > team.passwordResetExpiry) {
    return res.status(400).json({ success: false, error: 'Password reset link has expired. Please request a new one.' });
  }

  if (String(team.passwordResetToken).trim() !== String(resetToken).trim()) {
    return res.status(400).json({ success: false, error: 'Invalid or expired reset token' });
  }

  const cleanPwd = String(newPassword ?? '').trim();
  if (!cleanPwd || cleanPwd.length < 5) {
    return res.status(400).json({ success: false, error: 'Password must be at least 5 characters long' });
  }

  team.plainPassword = cleanPwd;
  team.customPasswordSet = true;
  team.passwordResetToken = undefined;
  team.passwordResetExpiry = undefined;

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-resetpwddone`,
    action: 'RESET_PASSWORD_COMPLETED',
    details: `Team "${team.name}" successfully created a new custom password via verified Google email recovery.`,
    actor: team.name,
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({
    success: true,
    message: 'Your password has been successfully reset. You may now sign in using your new custom password.',
    state: serverState,
  });
});

// POST change password for logged-in team
app.post('/api/team/change-password', (req: Request, res: Response) => {
  const { teamId, currentPassword, newPassword } = req.body;
  if (!serverState || !serverState.teams) {
    return res.status(500).json({ success: false, error: 'Server not ready' });
  }

  const team = serverState.teams.find((t: any) => t.id === teamId);
  if (!team) return res.status(404).json({ success: false, error: 'Team not found' });

  if (String(team.plainPassword) !== String(currentPassword ?? '').trim()) {
    return res.status(401).json({ success: false, error: 'Current password is incorrect' });
  }

  const cleanPwd = String(newPassword ?? '').trim();
  if (!cleanPwd || cleanPwd.length < 5) {
    return res.status(400).json({ success: false, error: 'New password must be at least 5 characters long' });
  }

  team.plainPassword = cleanPwd;
  team.customPasswordSet = true;

  serverState.auditLogs.unshift({
    id: `log-${Date.now()}-changepwd`,
    action: 'CHANGE_PASSWORD',
    details: `Team "${team.name}" updated their account password in Team Portal settings.`,
    actor: team.name,
    timestamp: Date.now(),
  });

  broadcastState(serverState);
  res.json({
    success: true,
    message: 'Password updated successfully.',
    state: serverState,
  });
});

// Explicit 404 for unhandled API routes
app.all('/api/*', (_req: Request, res: Response) => {
  res.status(404).json({ success: false, error: 'API route not found' });
});

// Server boot & Vite integration
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const distPath = path.join(__dirname, 'dist');
  const distIndex = path.join(distPath, 'index.html');
  const hasDist = fs.existsSync(distIndex);

  if (isProd && hasDist) {
    console.log('[Server] Serving production static assets from dist/');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      if (req.path.startsWith('/api/')) {
        return res.status(404).json({ success: false, error: 'API route not found' });
      }
      res.sendFile(distIndex);
    });
  } else {
    console.log('[Server] Initializing Vite middleware mode');
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] The City Strategy Challenge listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
