/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { CSCState, Team } from './types/auction';
import { auctionStore } from './services/auctionStore';
import { ProjectorView } from './components/ProjectorView';
import { OpenBidPanel } from './components/OpenBidPanel';
import { TeamLogin } from './components/TeamLogin';
import { AdminLogin } from './components/AdminLogin';
import { TeamDashboard } from './components/TeamDashboard';
import { AdminPortal } from './components/AdminPortal';
import { Header } from './components/Header';
import { formatRupees, formatRupeesWords, formatTimer } from './utils/formatters';
import {
  Users,
  Shield,
  Radio,
  FileSpreadsheet,
  ArrowRight,
  Sparkles,
  ExternalLink,
  Layers,
} from 'lucide-react';

export default function App() {
  const [state, setState] = useState<CSCState>(auctionStore.getState());
  const [currentPath, setCurrentPath] = useState<string>(window.location.pathname);
  const [searchParams, setSearchParams] = useState<URLSearchParams>(
    new URLSearchParams(window.location.search)
  );

  // Auth state
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('csc_admin_auth') === 'true';
  });

  const [authenticatedTeamId, setAuthenticatedTeamId] = useState<string | null>(() => {
    return sessionStorage.getItem('csc_team_id');
  });

  // Subscribe to real-time auction store
  useEffect(() => {
    const unsubscribe = auctionStore.subscribe((nextState) => {
      setState(nextState);
    });
    return () => unsubscribe();
  }, []);

  // Handle browser navigation (back/forward, URL changes)
  useEffect(() => {
    const handleLocationChange = () => {
      setCurrentPath(window.location.pathname);
      setSearchParams(new URLSearchParams(window.location.search));
    };

    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  // Navigation helper
  const navigateTo = (path: string, search: string = '') => {
    const newUrl = search ? `${path}?${search}` : path;
    window.history.pushState({}, '', newUrl);
    setCurrentPath(path);
    setSearchParams(new URLSearchParams(search));
  };

  // Auth Handlers
  const handleAdminLoginSuccess = () => {
    sessionStorage.setItem('csc_admin_auth', 'true');
    setIsAdminAuthenticated(true);
    const destination = currentPath.includes('card') || searchParams.get('tab') === 'cards' ? '/admin?tab=cards' : '/admin';
    navigateTo(destination);
  };

  const handleAdminLogout = () => {
    sessionStorage.removeItem('csc_admin_auth');
    setIsAdminAuthenticated(false);
    navigateTo('/');
  };

  const handleTeamLoginSuccess = (team: Team) => {
    sessionStorage.setItem('csc_team_id', team.id);
    setAuthenticatedTeamId(team.id);
    navigateTo('/team-portal');
  };

  const handleTeamLogout = () => {
    sessionStorage.removeItem('csc_team_id');
    setAuthenticatedTeamId(null);
    navigateTo('/team-login');
  };

  // 1. PROJECTOR DISPLAY ROUTE: ?view=projector OR /projector
  if (searchParams.get('view') === 'projector' || currentPath === '/projector') {
    return <ProjectorView currentAuction={state.currentAuction} />;
  }

  // 2. OPEN BID PANEL ROUTE: ?view=bid-panel OR /bid-panel
  if (searchParams.get('view') === 'bid-panel' || currentPath === '/bid-panel') {
    return (
      <OpenBidPanel
        currentAuction={state.currentAuction}
        teams={state.teams}
      />
    );
  }

  // 3. TEAM LOGIN ROUTE: /team-login
  if (currentPath === '/team-login') {
    return (
      <TeamLogin
        teams={state.teams}
        onLoginSuccess={handleTeamLoginSuccess}
      />
    );
  }

  // 4. ADMIN LOGIN ROUTE: /admin-login
  if (currentPath === '/admin-login') {
    if (isAdminAuthenticated) {
      return <AdminPortal state={state} onLogout={handleAdminLogout} initialTab="live" />;
    }
    return <AdminLogin onLoginSuccess={handleAdminLoginSuccess} />;
  }

  // 5. AUTHENTICATED TEAM DASHBOARD ROUTE: /team-portal
  if (currentPath === '/team-portal') {
    const currentTeam = state.teams.find((t) => t.id === authenticatedTeamId);
    if (!currentTeam || currentTeam.isArchived) {
      // Not authenticated or archived, redirect to team login
      return (
        <TeamLogin
          teams={state.teams}
          onLoginSuccess={handleTeamLoginSuccess}
        />
      );
    }
    return (
      <TeamDashboard
        team={currentTeam}
        currentAuction={state.currentAuction}
        onLogout={handleTeamLogout}
      />
    );
  }

  // 6. ADMIN PORTAL ROUTE: /admin, /admin/cards, /card-bank, /cards, /admin-cards, /card-bank-management
  if (
    currentPath === '/admin' ||
    currentPath === '/admin/' ||
    currentPath.startsWith('/admin/') ||
    currentPath === '/card-bank' ||
    currentPath === '/cards' ||
    currentPath.startsWith('/cards') ||
    currentPath === '/admin-cards' ||
    currentPath === '/admin-dashboard' ||
    currentPath === '/card-bank-management' ||
    searchParams.get('tab') === 'cards' ||
    searchParams.get('view') === 'cards' ||
    searchParams.get('view') === 'card-bank'
  ) {
    if (!isAdminAuthenticated) {
      return <AdminLogin onLoginSuccess={handleAdminLoginSuccess} />;
    }
    const initialTab =
      currentPath.includes('card') ||
      searchParams.get('tab') === 'cards' ||
      searchParams.get('view') === 'cards' ||
      searchParams.get('view') === 'card-bank'
        ? 'cards'
        : (searchParams.get('tab') as any) || 'live';

    return <AdminPortal state={state} onLogout={handleAdminLogout} initialTab={initialTab} />;
  }

  // 7. DEFAULT / PORTAL DIRECTORY LANDING PAGE
  return (
    <div className="min-h-screen bg-[#07090c] text-slate-100 flex flex-col selection:bg-amber-500/20">
      <Header
        currentRole={isAdminAuthenticated ? 'admin' : authenticatedTeamId ? 'team' : 'guest'}
        teamName={state.teams.find((t) => t.id === authenticatedTeamId)?.name}
        onLogout={isAdminAuthenticated ? handleAdminLogout : handleTeamLogout}
        onTabChange={(tab) => {
          navigateTo('/admin', `tab=${tab}`);
        }}
      />

      <main className="flex-1 max-w-6xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10 lg:py-16 space-y-12">
        {/* Hero Section */}
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#171c26] border border-[#2b3547] text-xs font-semibold text-[#d4af37] tracking-wider uppercase">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Official Event Auction Environment</span>
          </div>

          <h1 className="font-display text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-wide leading-tight">
            THE CITY STRATEGY CHALLENGE
          </h1>

          <p className="text-[#94a3b8] text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            Welcome to the official strategy card auction. Select your dedicated portal below to access real-time bidding, projector display, or administrative controls.
          </p>
        </div>

        {/* Live Event Status Snapshot */}
        <div className="bg-[#10141b] border border-[#232b3b] rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-wrap items-center justify-between gap-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#9ca3af]">
                LIVE AUCTION STATUS: {state.currentAuction.status}
              </span>
            </div>
            <h3 className="font-display text-xl sm:text-2xl font-bold text-white">
              {state.currentAuction.card ? state.currentAuction.card.name : 'Waiting for Round to Commence'}
            </h3>
            {state.currentAuction.card && (
              <p className="text-xs text-[#8e95a2]">
                Category: <strong className="text-[#d4af37]">{state.currentAuction.card.category}</strong> · Sector: <strong className="text-slate-300">{state.currentAuction.card.sector}</strong>
              </p>
            )}
          </div>

          <div className="flex items-center gap-8">
            <div>
              <p className="text-[11px] font-semibold text-[#8e95a2] uppercase tracking-wider">
                CURRENT BID
              </p>
              <p className="text-2xl sm:text-3xl font-black font-mono-val text-[#d4af37]">
                {formatRupees(state.currentAuction.currentBid)}
              </p>
              <p className="text-xs text-[#8e95a2]">
                {formatRupeesWords(state.currentAuction.currentBid)}
              </p>
            </div>

            <div className="pl-6 border-l border-[#242c3b]">
              <p className="text-[11px] font-semibold text-[#8e95a2] uppercase tracking-wider">
                TIMER
              </p>
              <p className={`text-2xl sm:text-3xl font-black font-mono-val tabular-nums ${
                state.currentAuction.timerSeconds <= 10 ? 'text-rose-500 animate-pulse' : 'text-white'
              }`}>
                {formatTimer(state.currentAuction.timerSeconds)}
              </p>
            </div>
          </div>
        </div>

        {/* Portals Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Team Portal Card */}
          <div
            onClick={() => navigateTo('/team-login')}
            className="group p-8 rounded-3xl bg-[#11141b] border border-[#212733] hover:border-[#d4af37] transition-all duration-200 cursor-pointer shadow-xl flex flex-col justify-between space-y-6"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-[#181d26] border border-[#283242] flex items-center justify-center text-[#d4af37] group-hover:scale-110 transition-transform">
                <Users className="w-6 h-6" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#d4af37]">
                  Participant Access
                </span>
                <h3 className="font-display text-2xl font-bold text-white mt-1 group-hover:text-[#d4af37] transition-colors">
                  Team Login Portal
                </h3>
                <p className="text-xs font-mono text-[#64748b] mt-0.5">
                  Direct URL: /team-login
                </p>
              </div>

              <p className="text-sm text-[#94a3b8] leading-relaxed">
                Log in with your official Team ID (e.g. TEAM 1 through TEAM 30) and password. View your initial budget, real-time expenditure, remaining budget, and acquired strategy card portfolio.
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#d4af37] group-hover:translate-x-1 transition-transform">
              <span>Sign in to Team Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          {/* Admin Portal Card */}
          <div
            onClick={() => navigateTo(isAdminAuthenticated ? '/admin' : '/admin-login')}
            className="group p-8 rounded-3xl bg-[#11141b] border border-[#212733] hover:border-[#d4af37] transition-all duration-200 cursor-pointer shadow-xl flex flex-col justify-between space-y-6"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-2xl bg-[#181d26] border border-[#283242] flex items-center justify-center text-[#d4af37] group-hover:scale-110 transition-transform">
                  <Shield className="w-6 h-6" />
                </div>
                {isAdminAuthenticated && (
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/40 uppercase tracking-wider">
                    Admin Authenticated
                  </span>
                )}
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#d4af37]">
                  Authorized Auctioneers
                </span>
                <h3 className="font-display text-2xl font-bold text-white mt-1 group-hover:text-[#d4af37] transition-colors">
                  {isAdminAuthenticated ? 'Admin Console & Card Bank' : 'Admin Login Portal'}
                </h3>
                <p className="text-xs font-mono text-[#64748b] mt-0.5">
                  Direct URL: /admin · /card-bank · /admin?tab=cards
                </p>
              </div>

              <p className="text-sm text-[#94a3b8] leading-relaxed">
                Full administrative console: CARD BANK MANAGEMENT (120 Cards across 4 categories), live timer controls, official bidding, sale confirmation, and team portfolio management.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  navigateTo(isAdminAuthenticated ? '/admin' : '/admin-login');
                }}
                className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#d4af37] group-hover:translate-x-1 transition-transform"
              >
                <span>{isAdminAuthenticated ? 'Open Admin Portal' : 'Access Admin Portal'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {isAdminAuthenticated && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    navigateTo('/admin', 'tab=cards');
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider bg-[#d4af37]/15 hover:bg-[#d4af37]/25 text-[#d4af37] border border-[#d4af37]/40 flex items-center gap-1.5 cursor-pointer ml-auto"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Card Bank</span>
                </button>
              )}
            </div>
          </div>

          {/* Projector Display Card */}
          <div
            onClick={() => navigateTo('/?view=projector', 'view=projector')}
            className="group p-8 rounded-3xl bg-[#11141b] border border-[#212733] hover:border-emerald-500 transition-all duration-200 cursor-pointer shadow-xl flex flex-col justify-between space-y-6"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-[#181d26] border border-[#283242] flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                <Radio className="w-6 h-6" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                  Auditorium Display
                </span>
                <h3 className="font-display text-2xl font-bold text-white mt-1 group-hover:text-emerald-400 transition-colors">
                  Projector Display
                </h3>
                <p className="text-xs font-mono text-[#64748b] mt-0.5">
                  Direct URL: /?view=projector
                </p>
              </div>

              <p className="text-sm text-[#94a3b8] leading-relaxed">
                Full-screen stage presentation display. Features real-time countdown timer, live accepted bid, and prominent winning team celebration screen after confirmed sale.
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 group-hover:translate-x-1 transition-transform">
              <span>Launch Projector Display</span>
              <ExternalLink className="w-4 h-4" />
            </div>
          </div>

          {/* Open Bid Panel Card */}
          <div
            onClick={() => navigateTo('/bid-panel')}
            className="group p-8 rounded-3xl bg-[#11141b] border border-[#212733] hover:border-sky-500 transition-all duration-200 cursor-pointer shadow-xl flex flex-col justify-between space-y-6"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-[#181d26] border border-[#283242] flex items-center justify-center text-sky-400 group-hover:scale-110 transition-transform">
                <FileSpreadsheet className="w-6 h-6" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-sky-400">
                  Auction Floor Assistant
                </span>
                <h3 className="font-display text-2xl font-bold text-white mt-1 group-hover:text-sky-400 transition-colors">
                  Open Bid Panel (30 Teams)
                </h3>
                <p className="text-xs font-mono text-[#64748b] mt-0.5">
                  Direct URL: /bid-panel
                </p>
              </div>

              <p className="text-sm text-[#94a3b8] leading-relaxed">
                Dedicated tablet/operator interface containing the 30 team buttons. Instant single-click official bid entry with budget and category validation.
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sky-400 group-hover:translate-x-1 transition-transform">
              <span>Open Floor Bid Panel</span>
              <ExternalLink className="w-4 h-4" />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
