/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Category = 'STAKEHOLDER' | 'CHALLENGE' | 'CONSTRAINT' | 'IMPACT';

export type Sector = 'MOBILITY' | 'WASTE MANAGEMENT' | 'WATER MANAGEMENT';

export type AuctionStatus = 
  | 'IDLE' 
  | 'READY' 
  | 'ACTIVE' 
  | 'PAUSED' 
  | 'CONCLUDED' 
  | 'SOLD' 
  | 'UNSOLD';

export type CardStatus = 'AVAILABLE' | 'IN_AUCTION' | 'SOLD' | 'UNSOLD' | 'ARCHIVED';

export interface Card {
  id: string;
  name: string;
  category: Category;
  sector: Sector;
  description: string;
  status: CardStatus;
  queueOrder: number;
}

export interface AcquiredCard {
  cardId: string;
  cardName: string;
  category: Category;
  sector: Sector;
  amount: number;
  timestamp: number;
  attemptId: string;
}

export interface Team {
  id: string;
  name: string; // e.g. "TEAM 1"
  loginId: string; // e.g. "TEAM 1"
  passwordHash?: string; // stored or hashed
  plainPassword?: string; // only for admin creation modal
  initialBudget: number; // 100,000,000 (₹10 Cr)
  totalSpent: number;
  remainingBudget: number;
  acquiredCards: AcquiredCard[];
  categoryProgress: {
    STAKEHOLDER: boolean;
    CHALLENGE: boolean;
    CONSTRAINT: boolean;
    IMPACT: boolean;
  };
  isArchived: boolean;
  notes?: string;
  createdAt: number;
  registeredEmail?: string;
  emailVerified?: boolean;
  emailVerificationCode?: string;
  emailVerificationExpiry?: number;
  passwordResetToken?: string;
  passwordResetExpiry?: number;
  customPasswordSet?: boolean;
}

export interface Bid {
  id: string;
  auctionAttemptId: string;
  cardId: string;
  cardName: string;
  amount: number;
  bidderId?: string | null;
  bidderName?: string | null; // null if isUnassignedAdmin
  isUnassignedAdmin: boolean;
  timestamp: number;
}

export interface SaleRecord {
  id: string;
  auctionAttemptId: string;
  cardId: string;
  cardName: string;
  category: Category;
  sector: Sector;
  winningTeamId: string;
  winningTeamName: string;
  amount: number;
  timestamp: number;
  isReversed?: boolean;
  reversedAt?: number;
}

export interface AuditLogItem {
  id: string;
  action: string;
  details: string;
  actor: string;
  timestamp: number;
}

export interface CurrentAuctionState {
  cardId: string | null;
  card: Card | null;
  status: AuctionStatus;
  currentBid: number; // in integer Rupees
  currentBidder: {
    id?: string | null;
    name?: string | null;
    isUnassignedAdmin?: boolean;
  } | null;
  confirmedFinalBid: number | null;
  confirmedFinalBidStatus: 'NONE' | 'PENDING' | 'CONFIRMED';
  bidCount: number;
  timerSeconds: number;
  timerDuration: number;
  timerIsRunning: boolean;
  timerHasExtended: boolean; // one-time 20s extension
  timerDeadline: number | null; // epoch ms
  auctionAttemptId: string;
  completedSale: {
    cardId: string;
    cardName: string;
    category: Category;
    sector: Sector;
    winningTeamId: string;
    winningTeamName: string;
    amount: number;
    timestamp: number;
    attemptId: string;
  } | null;
}

export interface CSCState {
  version: number;
  currentAuction: CurrentAuctionState;
  teams: Team[];
  cards: Card[];
  auctionQueue: string[]; // card IDs in sequence
  bidHistory: Bid[];
  salesRegister: SaleRecord[];
  auditLogs: AuditLogItem[];
  lastUpdated: number;
}
