/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  RotateCcw,
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  X,
  Loader2,
  ShieldAlert,
  Info,
} from 'lucide-react';
import { auctionStore } from '../services/auctionStore';

interface ResetAuctionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (message: string) => void;
}

export const ResetAuctionModal: React.FC<ResetAuctionModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [confirmText, setConfirmText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const isConfirmed = confirmText.trim().toUpperCase() === 'RESET';

  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isConfirmed || isSubmitting) return;

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await auctionStore.resetAuction('ANEKAL2026');
      if (res.success) {
        onSuccess(
          res.message ||
            'The auction has been successfully reset to its starting state. Stakeholder Card #1 loaded with a fresh 60-second timer.'
        );
        onClose();
      } else {
        setErrorMessage(res.error || 'Failed to execute reset. Please try again.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred during reset.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-[#10141c] border-2 border-rose-500/40 rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative space-y-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          disabled={isSubmitting}
          className="absolute right-5 top-5 p-2 rounded-xl text-[#94a3b8] hover:text-white hover:bg-[#1a202c] transition-colors disabled:opacity-50"
          title="Cancel and close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
            <AlertTriangle className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <span className="text-[11px] font-mono font-bold tracking-widest text-rose-400 uppercase">
              Administrator Security Action
            </span>
            <h3 className="font-display font-extrabold text-2xl text-white mt-0.5">
              RESET AUCTION TO STARTING STATE
            </h3>
            <p className="text-xs text-[#94a3b8] mt-1">
              Clear current event progress to restart the challenge cleanly from the beginning.
            </p>
          </div>
        </div>

        {/* Detailed Impact Breakdown */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          {/* Will Be Reset */}
          <div className="bg-rose-950/20 border border-rose-500/25 rounded-2xl p-4 space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-rose-400 uppercase tracking-wider text-[11px]">
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Will Be Reset</span>
            </div>
            <ul className="space-y-1.5 text-[#cbd5e1] text-[11px] list-disc list-inside">
              <li>Current active card, bids &amp; floor session</li>
              <li>Timer reset to inactive 01:00 (no auto-start)</li>
              <li>Category progression returned to <strong>Stakeholder</strong></li>
              <li>Card statuses restored to <strong>Available</strong></li>
              <li>Team budgets restored to <strong>₹10 Crore</strong></li>
              <li>Team portfolios &amp; spending cleared</li>
              <li>Active bid &amp; sales history archived</li>
            </ul>
          </div>

          {/* Will Be Safely Preserved */}
          <div className="bg-emerald-950/20 border border-emerald-500/25 rounded-2xl p-4 space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-emerald-400 uppercase tracking-wider text-[11px]">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Will Be Preserved</span>
            </div>
            <ul className="space-y-1.5 text-[#cbd5e1] text-[11px] list-disc list-inside">
              <li>All <strong>30 Teams</strong> (TEAM1 to TEAM30)</li>
              <li>All <strong>120 Strategy Cards</strong> &amp; custom titles</li>
              <li>Team passwords &amp; verified emails</li>
              <li>Full audit trail &amp; archived event history</li>
              <li>Official bidding increments &amp; rules</li>
              <li>System routes, logins &amp; security rules</li>
            </ul>
          </div>
        </div>

        {/* Error Alert if reset fails */}
        {errorMessage && (
          <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2.5">
            <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Explicit Confirmation Input */}
        <form onSubmit={handleResetSubmit} className="space-y-4 pt-2 border-t border-[#1e2533]">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#94a3b8] mb-2">
              Type <strong className="text-white font-mono bg-[#1c222e] px-1.5 py-0.5 rounded border border-[#2c3545]">RESET</strong> to confirm:
            </label>
            <input
              type="text"
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              disabled={isSubmitting}
              placeholder="Type RESET here"
              className="w-full bg-[#151922] border border-[#2b3545] focus:border-rose-500 focus:ring-1 focus:ring-rose-500 text-white px-4 py-3 rounded-xl text-sm font-mono tracking-wider outline-none transition-all uppercase placeholder:normal-case placeholder:text-[#525f75] disabled:opacity-50"
              autoFocus
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-[#94a3b8] hover:text-white bg-[#161a22] hover:bg-[#1e2430] border border-[#2b3545] rounded-xl transition-all cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!isConfirmed || isSubmitting}
              className="px-6 py-2.5 text-xs font-black uppercase tracking-wider text-white bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 active:scale-[0.99] rounded-xl transition-all shadow-lg shadow-rose-600/25 flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Resetting Auction...</span>
                </>
              ) : (
                <>
                  <RotateCcw className="w-4 h-4" />
                  <span>CONFIRM &amp; RESET AUCTION</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
