/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CurrentAuctionState, Team } from '../types/auction';
import { formatRupees, formatRupeesWords, formatTimer, formatTime } from '../utils/formatters';
import { Header } from './Header';
import {
  Award,
  CheckCircle2,
  Clock,
  DollarSign,
  Layers,
  Radio,
  ShieldAlert,
  ShieldCheck,
  KeyRound,
  Mail,
  AlertCircle,
  Lock,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { auctionStore } from '../services/auctionStore';

interface TeamDashboardProps {
  team: Team;
  currentAuction: CurrentAuctionState;
  onLogout: () => void;
}

export const TeamDashboard: React.FC<TeamDashboardProps> = ({ team, currentAuction, onLogout }) => {
  // Always query latest authoritative store state for real-time reactivity
  const liveTeam = auctionStore.getState().teams.find((t) => t.id === team.id) || team;
  const card = currentAuction.card;
  const categories = ['STAKEHOLDER', 'CHALLENGE', 'CONSTRAINT', 'IMPACT'] as const;

  const categoryDefinitions: { key: 'STAKEHOLDER' | 'CHALLENGE' | 'CONSTRAINT' | 'IMPACT'; label: string; number: number; desc: string }[] = [
    { key: 'STAKEHOLDER', label: 'Stakeholder', number: 1, desc: 'Key urban actors & decision-makers' },
    { key: 'CHALLENGE', label: 'Challenge', number: 2, desc: 'Core urban issues & infrastructure needs' },
    { key: 'CONSTRAINT', label: 'Constraint', number: 3, desc: 'Regulatory, resource & spatial limits' },
    { key: 'IMPACT', label: 'Impact', number: 4, desc: 'Target outcomes & measurable value' },
  ];

  // Account Settings Drawer / Section State
  const [isSecurityOpen, setIsSecurityOpen] = useState(false);

  // Change Password state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwdLoading, setPwdLoading] = useState(false);
  const [pwdFeedback, setPwdFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Email setup inside dashboard
  const [emailInput, setEmailInput] = useState(team.registeredEmail || '');
  const [emailStep, setEmailStep] = useState<1 | 2>(1);
  const [emailCode, setEmailCode] = useState('');
  const [emailLoading, setEmailLoading] = useState(false);
  const [emailFeedback, setEmailFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwdFeedback(null);

    if (!currentPassword) {
      setPwdFeedback({ type: 'error', message: 'Current password is required.' });
      return;
    }

    if (newPassword.length < 5) {
      setPwdFeedback({ type: 'error', message: 'New password must be at least 5 characters long.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      setPwdFeedback({ type: 'error', message: 'New password and confirmation do not match.' });
      return;
    }

    setPwdLoading(true);

    const res = await auctionStore.changeTeamPassword({
      teamId: team.id,
      currentPassword,
      newPassword,
    });

    setPwdLoading(false);

    if (res.success) {
      setPwdFeedback({
        type: 'success',
        message: 'Your custom password has been successfully updated. All budgets and card records remain fully intact.',
      });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } else {
      setPwdFeedback({
        type: 'error',
        message: res.error || 'Failed to update password.',
      });
    }
  };

  const handleRegisterEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailFeedback(null);

    const clean = emailInput.trim().toLowerCase();
    if (!clean) {
      setEmailFeedback({ type: 'error', message: 'Please enter a valid Google email address.' });
      return;
    }

    setEmailLoading(true);

    const res = await auctionStore.registerTeamEmail({
      teamId: team.id,
      email: clean,
      currentPassword: team.plainPassword || '',
    });

    setEmailLoading(false);

    if (res.success) {
      setEmailFeedback({
        type: 'success',
        message: res.message || 'Verification code dispatched.',
      });
      if (res.verificationCodeForDev) {
        setEmailCode(res.verificationCodeForDev);
      }
      setEmailStep(2);
    } else {
      setEmailFeedback({
        type: 'error',
        message: res.error || 'Failed to register email.',
      });
    }
  };

  const handleVerifyEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailFeedback(null);

    if (!emailCode.trim()) {
      setEmailFeedback({ type: 'error', message: 'Please enter the 6-digit verification code.' });
      return;
    }

    setEmailLoading(true);

    const res = await auctionStore.verifyTeamEmail({
      teamId: team.id,
      code: emailCode.trim(),
    });

    setEmailLoading(false);

    if (res.success) {
      setEmailFeedback({
        type: 'success',
        message: `Google email successfully verified and linked to ${team.name}!`,
      });
      setEmailStep(1);
    } else {
      setEmailFeedback({
        type: 'error',
        message: res.error || 'Verification code failed.',
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#07090c] text-slate-100 flex flex-col">
      <Header currentRole="team" teamName={liveTeam.name} onLogout={onLogout} />

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Welcome & Financial Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {/* Team Info */}
          <div className="bg-[#10141a] border border-[#212836] rounded-2xl p-6 shadow-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#9ca3af]">
                  AUTHENTICATED TEAM
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  ACTIVE
                </span>
              </div>
              <h2 className="font-display text-2xl lg:text-3xl font-extrabold text-white mt-2">
                {liveTeam.name}
              </h2>
            </div>
            <div className="mt-4 flex items-center justify-between text-xs text-[#8e95a2] font-mono">
              <span>ID: {liveTeam.loginId}</span>
              <button
                onClick={() => setIsSecurityOpen(!isSecurityOpen)}
                className="text-xs text-[#d4af37] hover:underline flex items-center gap-1 cursor-pointer font-sans"
              >
                <KeyRound className="w-3 h-3" />
                <span>Security</span>
              </button>
            </div>
          </div>

          {/* Initial Budget */}
          <div className="bg-[#10141a] border border-[#212836] rounded-2xl p-6 shadow-lg flex flex-col justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#9ca3af]">
              STARTING BUDGET
            </span>
            <div className="mt-2">
              <div className="text-2xl lg:text-3xl font-black font-mono-val text-white">
                {formatRupees(liveTeam.initialBudget)}
              </div>
              <p className="text-xs text-[#8e95a2] mt-1 font-semibold">
                {formatRupeesWords(liveTeam.initialBudget)}
              </p>
            </div>
            <p className="text-[11px] text-[#64748b] mt-3">
              Standard base tournament allocation (₹10 Crore)
            </p>
          </div>

          {/* Total Spent */}
          <div className="bg-[#10141a] border border-[#212836] rounded-2xl p-6 shadow-lg flex flex-col justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#9ca3af]">
              TOTAL CONFIRMED SPENDING
            </span>
            <div className="mt-2">
              <div className="text-2xl lg:text-3xl font-black font-mono-val text-amber-400">
                {formatRupees(liveTeam.totalSpent)}
              </div>
              <p className="text-xs text-amber-400/80 mt-1 font-semibold">
                {formatRupeesWords(liveTeam.totalSpent)}
              </p>
            </div>
            <p className="text-[11px] text-[#64748b] mt-3">
              Sum of confirmed purchases only ({liveTeam.acquiredCards.length} card{liveTeam.acquiredCards.length !== 1 ? 's' : ''})
            </p>
          </div>

          {/* Remaining Budget */}
          <div className="bg-[#10141a] border border-[#d4af37]/40 rounded-2xl p-6 shadow-lg flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-[#d4af37]/10 rounded-bl-full pointer-events-none" />
            <span className="text-xs font-bold uppercase tracking-wider text-[#d4af37]">
              REMAINING BUDGET AVAILABLE
            </span>
            <div className="mt-2">
              <div className="text-2xl lg:text-3xl font-black font-mono-val text-[#d4af37]">
                {formatRupees(liveTeam.remainingBudget)}
              </div>
              <p className="text-xs text-[#f4d068] mt-1 font-semibold">
                {formatRupeesWords(liveTeam.remainingBudget)}
              </p>
            </div>
            <p className="text-[11px] text-[#8e95a2] mt-3">
              Starting Budget (₹10 Cr) − Total Confirmed Spending
            </p>
          </div>
        </div>

        {/* Live Active Bid Status Indicator */}
        {currentAuction.currentBidder?.id === liveTeam.id && (currentAuction.status === 'ACTIVE' || currentAuction.status === 'READY') && (
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex flex-wrap items-center justify-between gap-3 animate-pulse">
            <div className="flex items-center gap-3">
              <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <div>
                <p className="font-bold text-sm text-white">
                  Active Leading Bid: {formatRupees(currentAuction.currentBid)} ({formatRupeesWords(currentAuction.currentBid)})
                </p>
                <p className="text-amber-300/80 mt-0.5">
                  Your team currently holds the highest bid on the floor. Live bids do NOT deduct from your remaining budget until the administrator officially confirms the sale.
                </p>
              </div>
            </div>
            <span className="px-3 py-1 rounded-full font-mono font-bold text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase">
              LEADING BIDDER
            </span>
          </div>
        )}

        {/* ACCOUNT SETTINGS & PASSWORD MANAGEMENT PANEL */}
        <div className="bg-[#10141b] border border-[#232b3b] rounded-3xl p-6 sm:p-8 shadow-xl">
          <div className="flex items-center justify-between cursor-pointer" onClick={() => setIsSecurityOpen(!isSecurityOpen)}>
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-[#171c26] border border-[#2b3548] text-[#d4af37]">
                <KeyRound className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-display text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                  <span>Account Credentials & Security</span>
                  {team.emailVerified ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      EMAIL VERIFIED
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      SETUP REQUIRED
                    </span>
                  )}
                </h3>
                <p className="text-xs text-[#8e95a2] mt-0.5">
                  Manage your team's custom password and link your verified Google email address.
                </p>
              </div>
            </div>

            <button className="text-[#8e95a2] hover:text-white p-2">
              {isSecurityOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            </button>
          </div>

          {isSecurityOpen && (
            <div className="mt-6 pt-6 border-t border-[#1f2635] grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fadeIn">
              {/* Left Column: Google Email Linking */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#d4af37]" />
                  <h4 className="font-display text-base font-bold text-white">
                    Registered Google Email Address
                  </h4>
                </div>

                {team.emailVerified ? (
                  <div className="bg-[#141922] border border-emerald-500/30 rounded-2xl p-5 space-y-3">
                    <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                      <ShieldCheck className="w-4 h-4" />
                      <span>Verified Google Email Linked</span>
                    </div>
                    <p className="font-mono text-sm text-white font-semibold break-all">
                      {team.registeredEmail}
                    </p>
                    <p className="text-xs text-[#8e95a2] leading-relaxed">
                      This verified email address is linked to your team account ({team.loginId}). You can use it at any time on the login page to recover or reset your password.
                    </p>
                  </div>
                ) : (
                  <div className="bg-[#141922] border border-[#2b3545] rounded-2xl p-5 space-y-4">
                    <div className="flex items-center gap-2 text-amber-400 text-xs font-bold">
                      <AlertCircle className="w-4 h-4" />
                      <span>Google Email Not Yet Verified</span>
                    </div>
                    <p className="text-xs text-[#8e95a2] leading-relaxed">
                      Link an official Google email address to enable self-service password reset and secure your account against lockouts.
                    </p>

                    {emailFeedback && (
                      <div
                        className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                          emailFeedback.type === 'success'
                            ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                            : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
                        }`}
                      >
                        <span>{emailFeedback.message}</span>
                      </div>
                    )}

                    {emailStep === 1 ? (
                      <form onSubmit={handleRegisterEmail} className="space-y-3">
                        <div>
                          <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#9ca3af] mb-1">
                            Google Email Address
                          </label>
                          <input
                            type="email"
                            value={emailInput}
                            onChange={(e) => setEmailInput(e.target.value)}
                            placeholder="yourteam@gmail.com"
                            required
                            className="w-full bg-[#181d26] border border-[#283244] focus:border-[#d4af37] text-white px-3 py-2 rounded-xl text-xs outline-none"
                          />
                        </div>
                        <button
                          type="submit"
                          disabled={emailLoading}
                          className="px-4 py-2 bg-[#d4af37] hover:bg-[#e4be42] text-[#0a0c10] text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
                        >
                          {emailLoading ? 'Sending...' : 'Send Verification Code'}
                        </button>
                      </form>
                    ) : (
                      <form onSubmit={handleVerifyEmail} className="space-y-3">
                        <div>
                          <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#9ca3af] mb-1">
                            Enter 6-Digit Code sent to {emailInput}
                          </label>
                          <input
                            type="text"
                            value={emailCode}
                            onChange={(e) => setEmailCode(e.target.value)}
                            placeholder="e.g. 123456"
                            maxLength={6}
                            required
                            className="w-full bg-[#181d26] border border-[#283244] focus:border-[#d4af37] text-white px-3 py-2 rounded-xl text-center font-mono text-sm tracking-widest outline-none"
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setEmailStep(1)}
                            className="text-xs text-[#8e95a2] hover:text-white px-2 py-1"
                          >
                            Edit Email
                          </button>
                          <button
                            type="submit"
                            disabled={emailLoading}
                            className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
                          >
                            {emailLoading ? 'Verifying...' : 'Verify & Lock Email'}
                          </button>
                        </div>
                      </form>
                    )}
                  </div>
                )}
              </div>

              {/* Right Column: Change Password */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#d4af37]" />
                  <h4 className="font-display text-base font-bold text-white">
                    Change Custom Password
                  </h4>
                </div>

                <div className="bg-[#141922] border border-[#2b3545] rounded-2xl p-5 space-y-4">
                  {pwdFeedback && (
                    <div
                      className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                        pwdFeedback.type === 'success'
                          ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                          : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
                      }`}
                    >
                      {pwdFeedback.type === 'success' ? (
                        <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                      ) : (
                        <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                      )}
                      <span>{pwdFeedback.message}</span>
                    </div>
                  )}

                  <form onSubmit={handleChangePassword} className="space-y-3">
                    <div>
                      <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#9ca3af] mb-1">
                        Current Password
                      </label>
                      <input
                        type="password"
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        placeholder="Enter current password"
                        required
                        className="w-full bg-[#181d26] border border-[#283244] focus:border-[#d4af37] text-white px-3 py-2 rounded-xl text-xs outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#9ca3af] mb-1">
                        New Custom Password
                      </label>
                      <input
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="At least 5 characters"
                        required
                        className="w-full bg-[#181d26] border border-[#283244] focus:border-[#d4af37] text-white px-3 py-2 rounded-xl text-xs outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#9ca3af] mb-1">
                        Confirm New Password
                      </label>
                      <input
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Re-enter new password"
                        required
                        className="w-full bg-[#181d26] border border-[#283244] focus:border-[#d4af37] text-white px-3 py-2 rounded-xl text-xs outline-none"
                      />
                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        disabled={pwdLoading}
                        className="w-full py-2.5 px-4 bg-[#d4af37] hover:bg-[#e4be42] text-[#0a0c10] text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
                      >
                        {pwdLoading ? 'Updating Password...' : 'Save New Password'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Current Live Auction Section */}
        <div className="bg-[#10141a] border border-[#232b3b] rounded-3xl p-6 sm:p-8 shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-[#1f2633]">
            <div className="flex items-center gap-2.5">
              <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#9ca3af]">
                CURRENT AUCTION STATUS
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-mono font-bold tracking-wider ${
                currentAuction.status === 'ACTIVE'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : currentAuction.status === 'SOLD'
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                  : 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
              }`}>
                {currentAuction.status}
              </span>
              {currentAuction.timerHasExtended && (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  +20S EXTENSION
                </span>
              )}
            </div>
          </div>

          {card ? (
            <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Card Details */}
              <div className="lg:col-span-2 space-y-4">
                <div className="flex flex-wrap gap-2.5">
                  <span className="px-3 py-1 rounded text-xs font-extrabold uppercase tracking-wider bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/30">
                    {card.category}
                  </span>
                  <span className="px-3 py-1 rounded text-xs font-bold uppercase tracking-wider bg-[#1c222e] text-[#9ca3af] border border-[#2b3547]">
                    {card.sector}
                  </span>
                </div>

                <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-white">
                  {card.name}
                </h3>

                <p className="text-sm sm:text-base text-[#94a3b8] leading-relaxed">
                  {card.description}
                </p>

                {/* Team Eligibility Notice for Current Card */}
                <div className="pt-2">
                  {team.categoryProgress[card.category] ? (
                    <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
                      <span>Notice: Your team already owns a card in this category ({card.category}). You are ineligible to purchase this card.</span>
                    </div>
                  ) : team.acquiredCards.length >= 4 ? (
                    <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/30 text-xs text-purple-300 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 shrink-0 text-purple-400" />
                      <span>Strategy Complete: Your team has acquired all 4 categories!</span>
                    </div>
                  ) : (
                    <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                      <span>Your team is eligible for this category ({card.category}).</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Live Bid & Timer */}
              <div className="bg-[#151a23] border border-[#263040] rounded-2xl p-6 flex flex-col justify-between space-y-6">
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#8e95a2]">
                    CURRENT ACCEPTED BID
                  </span>
                  <div className="font-mono-val text-3xl sm:text-4xl font-black text-[#d4af37] mt-1">
                    {formatRupees(currentAuction.currentBid)}
                  </div>
                  <p className="text-xs text-[#8e95a2] mt-0.5">
                    {formatRupeesWords(currentAuction.currentBid)}
                  </p>
                </div>

                <div className="pt-4 border-t border-[#232b38]">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#8e95a2]">
                    COUNTDOWN
                  </span>
                  <div className={`font-mono-val text-3xl sm:text-4xl font-black mt-1 ${
                    currentAuction.timerSeconds <= 10 ? 'text-rose-500 animate-pulse' : 'text-white'
                  }`}>
                    {formatTimer(currentAuction.timerSeconds)}
                  </div>
                </div>

                <div className="pt-2 text-[11px] text-[#64748b] font-mono">
                  Read-only view · Floor bidding is conducted by authorized auctioneer
                </div>
              </div>
            </div>
          ) : (
            <div className="py-8 text-center text-[#64748b]">
              No active card in auction at this moment.
            </div>
          )}
        </div>

        {/* Acquired Cards Portfolio */}
        <div className="bg-[#10141a] border border-[#232b3b] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-[#1f2633]">
            <div>
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-[#d4af37]" />
                <h3 className="font-display text-xl sm:text-2xl font-bold text-white">
                  Acquired Cards Portfolio
                </h3>
              </div>
              <p className="text-xs text-[#8e95a2] mt-1">
                Cards won by {liveTeam.name} remain permanently in your portfolio across all rounds
              </p>
            </div>

            {/* Total Acquired Count & Progress Badge */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
              <div className="flex items-center gap-2 bg-[#161a22] border border-[#263040] px-3.5 py-1.5 rounded-xl">
                <span className="text-xs font-semibold text-[#8e95a2]">Total Acquired:</span>
                <span className="font-mono-val font-bold text-sm text-[#d4af37]">
                  {liveTeam.acquiredCards.length} / 4 Categories
                </span>
              </div>
            </div>
          </div>

          {/* Category Progress Bar & Category Summary Chips */}
          <div className="space-y-3 bg-[#131720] border border-[#212836] rounded-2xl p-4 sm:p-5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold uppercase tracking-wider text-[#9ca3af]">
                PORTFOLIO STRATEGY COMPLETION
              </span>
              <span className="font-mono font-bold text-[#d4af37]">
                {Math.round((liveTeam.acquiredCards.length / 4) * 100)}%
              </span>
            </div>
            <div className="w-full h-2.5 bg-[#1b212c] rounded-full overflow-hidden border border-[#263142]">
              <div
                className="h-full bg-gradient-to-r from-[#d4af37] to-emerald-400 transition-all duration-500 rounded-full"
                style={{ width: `${Math.min(100, (liveTeam.acquiredCards.length / 4) * 100)}%` }}
              />
            </div>

            {/* Category breakdown chips */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
              {categoryDefinitions.map((cat) => {
                const count = liveTeam.acquiredCards.filter((ac) => ac.category === cat.key).length;
                const isAcquired = count > 0;
                return (
                  <div
                    key={cat.key}
                    className={`p-2.5 rounded-xl border flex items-center justify-between transition-colors ${
                      isAcquired
                        ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                        : 'bg-[#161a22] border-[#222936] text-[#8e95a2]'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      {isAcquired ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      ) : (
                        <Clock className="w-3.5 h-3.5 text-[#64748b] shrink-0" />
                      )}
                      <span className="text-[11px] font-bold uppercase tracking-wider">
                        {cat.number}. {cat.label}
                      </span>
                    </div>
                    <span className={`text-[11px] font-mono font-extrabold ${isAcquired ? 'text-emerald-400' : 'text-[#64748b]'}`}>
                      {count}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 4 Dedicated Category Slots */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 pt-2">
            {categoryDefinitions.map((cat) => {
              const catCards = liveTeam.acquiredCards.filter((ac) => ac.category === cat.key);
              const isAcquired = catCards.length > 0;

              return (
                <div
                  key={cat.key}
                  className={`rounded-2xl p-5 flex flex-col justify-between space-y-4 border transition-all ${
                    isAcquired
                      ? 'bg-gradient-to-b from-[#141b24] to-[#10141a] border-emerald-500/40 shadow-lg shadow-emerald-950/20'
                      : 'bg-[#12161e] border-dashed border-[#263042] opacity-90'
                  }`}
                >
                  <div className="space-y-3">
                    {/* Slot Header: Category Name & Status Badge */}
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-black uppercase tracking-wider text-white">
                        {cat.number}. {cat.label}
                      </span>
                      {isAcquired ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>ACQUIRED</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>PENDING</span>
                        </span>
                      )}
                    </div>

                    {isAcquired ? (
                      /* Acquired Card Details */
                      catCards.map((ac) => (
                        <div key={ac.cardId} className="space-y-3 pt-1">
                          <div>
                            <span className="inline-block px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-[#d4af37]/15 text-[#d4af37] border border-[#d4af37]/30 mb-1.5">
                              {ac.sector}
                            </span>
                            <h4 className="font-display text-base font-extrabold text-white leading-snug">
                              {ac.cardName}
                            </h4>
                          </div>

                          <div className="pt-2 border-t border-[#1e2533] space-y-1">
                            <p className="text-[10px] uppercase font-bold text-[#64748b]">
                              Final Purchase Price
                            </p>
                            <p className="font-mono-val text-lg font-black text-emerald-400">
                              {formatRupees(ac.amount)}
                            </p>
                            <p className="text-[11px] text-[#8e95a2] font-semibold">
                              {formatRupeesWords(ac.amount)}
                            </p>
                          </div>
                        </div>
                      ))
                    ) : (
                      /* Pending Slot Details */
                      <div className="space-y-3 pt-3">
                        <div className="w-10 h-10 rounded-xl bg-[#171c26] border border-[#232b38] flex items-center justify-center text-[#64748b]">
                          <Layers className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-[#cbd5e1]">
                            No Card Acquired Yet
                          </p>
                          <p className="text-xs text-[#64748b] mt-1 leading-relaxed">
                            {cat.desc}
                          </p>
                        </div>
                        <div className="pt-2 border-t border-[#1e2533]">
                          <span className={`inline-block px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider border ${
                            liveTeam.acquiredCards.length >= 4
                              ? 'bg-purple-950/30 text-purple-300 border-purple-500/30'
                              : 'bg-emerald-950/20 text-emerald-400 border-emerald-500/30'
                          }`}>
                            {liveTeam.acquiredCards.length >= 4 ? 'Portfolio Limit Reached (4/4)' : 'Eligible for Live Bidding'}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Slot Footer */}
                  {isAcquired && (
                    <div className="pt-3 border-t border-[#1e2533] flex items-center justify-between text-[10px] font-mono text-[#64748b]">
                      <span>Acquired: {formatTime(catCards[0].timestamp)}</span>
                      <span className="text-emerald-400 font-bold">CONFIRMED</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Confirmed Acquisitions History Table (If any cards acquired) */}
          {liveTeam.acquiredCards.length > 0 && (
            <div className="mt-8 pt-6 border-t border-[#1e2636] space-y-4">
              <h4 className="font-display text-sm font-bold uppercase tracking-wider text-white">
                Confirmed Acquisitions History
              </h4>
              <div className="overflow-x-auto rounded-2xl border border-[#212734] bg-[#0e1117]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#141821] border-b border-[#212733] text-[#8e95a2] uppercase tracking-wider font-semibold">
                    <tr>
                      <th className="py-3 px-4">#</th>
                      <th className="py-3 px-4">Card Name</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4">Sector</th>
                      <th className="py-3 px-4">Purchase Price</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Timestamp</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1a202c]">
                    {liveTeam.acquiredCards.map((ac, idx) => (
                      <tr key={ac.cardId} className="hover:bg-[#131720] transition-colors">
                        <td className="py-3 px-4 font-mono text-[#64748b]">{idx + 1}</td>
                        <td className="py-3 px-4 font-display font-bold text-white">{ac.cardName}</td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-[#d4af37]/15 text-[#d4af37] border border-[#d4af37]/30">
                            {ac.category}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-[#8e95a2]">{ac.sector}</td>
                        <td className="py-3 px-4 font-mono-val font-bold text-emerald-400">
                          {formatRupees(ac.amount)}
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                            SALE CONFIRMED
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-[#64748b]">
                          {formatTime(ac.timestamp)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
