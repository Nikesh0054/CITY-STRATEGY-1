/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Card, CurrentAuctionState, Team } from '../types/auction';
import {
  formatRupees,
  formatRupeesWords,
  formatTimer,
  formatTime,
} from '../utils/formatters';
import {
  checkTeamEligibility,
  getNextMinimumBid,
  getPreviousBid,
  OPENING_BID,
  validateBidAmount,
} from '../utils/auctionRules';
import { auctionStore } from '../services/auctionStore';
import {
  Play,
  Pause,
  RotateCcw,
  Plus,
  Minus,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowRight,
  RotateCw,
  Award,
  Layers,
  ChevronRight,
  Edit2,
} from 'lucide-react';
import { ResetAuctionModal } from './ResetAuctionModal';

interface AdminLiveAuctionProps {
  currentAuction: CurrentAuctionState;
  teams: Team[];
  cards: Card[];
  auctionQueue: string[];
  onOpenResetModal?: () => void;
  onOpenCardBank?: () => void;
  onEditCurrentCard?: (card: Card) => void;
}

export const AdminLiveAuction: React.FC<AdminLiveAuctionProps> = ({
  currentAuction,
  teams,
  cards,
  auctionQueue,
  onOpenResetModal,
  onOpenCardBank,
  onEditCurrentCard,
}) => {
  const card = currentAuction.card;
  const isTimerExpired = currentAuction.timerSeconds <= 0 || currentAuction.status === 'CONCLUDED';
  const isBiddingOpen = (currentAuction.status === 'ACTIVE' || currentAuction.status === 'READY') && !isTimerExpired;
  const isConcluded = currentAuction.status === 'CONCLUDED' || currentAuction.status === 'SOLD' || currentAuction.status === 'UNSOLD';

  // Manual bid input state
  const [manualBidInput, setManualBidInput] = useState<number>(
    currentAuction.currentBid || OPENING_BID
  );
  const [bidError, setBidError] = useState<string | null>(null);

  // Winning team selection
  const [selectedTeamId, setSelectedTeamId] = useState<string>('');

  // Confirmation modal state for Sell Card
  const [saleConfirmationModal, setSaleConfirmationModal] = useState<{
    team: Team;
    amount: number;
    card: Card;
    remainingBudgetAfter: number;
  } | null>(null);

  // Team-specific bid selection
  const [teamBidSelectId, setTeamBidSelectId] = useState<string>('');

  // Status/feedback
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [showLocalResetModal, setShowLocalResetModal] = useState(false);

  const nextMinBid = getNextMinimumBid(currentAuction.currentBid, currentAuction.bidCount);

  // Minus button for manual input
  const handleDecrementInput = () => {
    const dec = getPreviousBid(manualBidInput, OPENING_BID);
    setManualBidInput(dec);
    setBidError(null);
  };

  // Plus button for manual input
  const handleIncrementInput = () => {
    const inc = getNextMinimumBid(manualBidInput);
    setManualBidInput(inc);
    setBidError(null);
  };

  // Set As Final Bid button
  const handleSetAsFinalBid = async () => {
    const validation = validateBidAmount(manualBidInput, 0);
    if (!validation.valid) {
      setBidError(validation.error || 'Invalid bid amount');
      return;
    }
    const res = await auctionStore.setConfirmedFinalBid(manualBidInput);
    if (res.success) {
      setBidError(null);
      setFeedback({
        type: 'success',
        message: `Confirmed Final Bid set to ${formatRupees(manualBidInput)} (${formatRupeesWords(manualBidInput)})`,
      });
      setTimeout(() => setFeedback(null), 3000);
    } else {
      setBidError(res.error || 'Failed to set final bid');
    }
  };

  // Direct + BID button (official unassigned admin bid)
  const handleDirectPlusBid = async () => {
    setBidError(null);
    if (!isBiddingOpen) {
      setBidError(isTimerExpired ? 'Auction timer has expired (00:00). Bids closed.' : 'Auction is not active for bidding.');
      return;
    }

    const res = await auctionStore.submitBid({
      amount: nextMinBid,
      isUnassignedAdmin: true,
    });

    if (res.success) {
      setManualBidInput(nextMinBid);
      setFeedback({
        type: 'success',
        message: `Accepted Official Bid: ${formatRupees(nextMinBid)} (${formatRupeesWords(nextMinBid)})`,
      });
      setTimeout(() => setFeedback(null), 2500);
    } else {
      setBidError(res.error || 'Bid rejected');
    }
  };

  // Submit team bid
  const handleTeamSpecificBid = async () => {
    if (!teamBidSelectId) {
      setBidError('Please select a team for team-specific bid');
      return;
    }
    if (!isBiddingOpen) {
      setBidError(isTimerExpired ? 'Auction timer has expired (00:00). Bids closed.' : 'Auction is not active for bidding.');
      return;
    }

    const res = await auctionStore.submitBid({
      amount: nextMinBid,
      teamId: teamBidSelectId,
      isUnassignedAdmin: false,
    });

    if (res.success) {
      const team = teams.find((t) => t.id === teamBidSelectId);
      setManualBidInput(nextMinBid);
      setFeedback({
        type: 'success',
        message: `Accepted Bid: ${formatRupees(nextMinBid)} for ${team?.name}`,
      });
      setTimeout(() => setFeedback(null), 2500);
    } else {
      setBidError(res.error || 'Bid rejected');
    }
  };

  // Initiate Sell Card workflow: opens review summary modal
  const handleInitiateSellCard = () => {
    if (!card) {
      setBidError('No active card loaded in auction.');
      return;
    }

    if (!selectedTeamId) {
      setBidError('Please select a winning team in Sale & Team Assignment.');
      return;
    }

    const team = teams.find((t) => t.id === selectedTeamId);
    if (!team) {
      setBidError('Selected team not found.');
      return;
    }

    // Determine final amount: confirmedFinalBid or currentBid
    const finalAmount = currentAuction.confirmedFinalBid || currentAuction.currentBid;

    // Check eligibility & budget
    const eligibility = checkTeamEligibility(team, card.category, finalAmount);
    if (!eligibility.eligible) {
      setBidError(`Cannot sell to ${team.name}: ${eligibility.reason}`);
      return;
    }

    const remainingBudgetAfter = team.remainingBudget - finalAmount;

    setSaleConfirmationModal({
      team,
      amount: finalAmount,
      card,
      remainingBudgetAfter,
    });
  };

  // Confirm Sale in modal
  const handleConfirmSale = async () => {
    if (!saleConfirmationModal) return;

    const res = await auctionStore.sellCard({
      teamId: saleConfirmationModal.team.id,
      amount: saleConfirmationModal.amount,
    });

    if (res.success) {
      setSaleConfirmationModal(null);
      setSelectedTeamId('');
      setFeedback({
        type: 'success',
        message: `Card SOLD to ${saleConfirmationModal.team.name} for ${formatRupees(saleConfirmationModal.amount)}! Broadcasted to projector.`,
      });
      setTimeout(() => setFeedback(null), 4000);
    } else {
      setBidError(res.error || 'Sale transaction failed');
      setSaleConfirmationModal(null);
    }
  };

  // Mark Unsold (No Sale)
  const handleMarkUnsold = async () => {
    if (!card) return;
    const res = await auctionStore.markUnsold();
    if (res.success) {
      setFeedback({
        type: 'success',
        message: `Card marked as UNSOLD (No Sale).`,
      });
      setTimeout(() => setFeedback(null), 3000);
    } else {
      setBidError(res.error || 'Failed to mark card unsold');
    }
  };

  // Undo Last Sale
  const handleUndoLastSale = async () => {
    const res = await auctionStore.undoLastSale();
    if (res.success) {
      setFeedback({
        type: 'success',
        message: 'Last sale successfully reversed! Team budget and card restored.',
      });
      setTimeout(() => setFeedback(null), 3500);
    } else {
      setBidError(res.error || 'Failed to undo sale');
    }
  };

  // Filter eligible teams for winning team dropdown
  const eligibleTeams = teams.filter((t) => {
    if (t.isArchived) return false;
    if (!card) return true;
    const effectiveAmount = currentAuction.confirmedFinalBid || currentAuction.currentBid;
    return checkTeamEligibility(t, card.category, effectiveAmount).eligible;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner Alert Feedback */}
      {feedback && (
        <div
          className={`p-4 rounded-xl flex items-center gap-3 text-sm font-semibold animate-fade-in ${
            feedback.type === 'success'
              ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-500/30'
              : 'bg-rose-950/40 text-rose-300 border border-rose-500/30'
          }`}
        >
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{feedback.message}</span>
        </div>
      )}

      {bidError && (
        <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs font-semibold flex items-center justify-between animate-shake">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{bidError}</span>
          </div>
          <button onClick={() => setBidError(null)} className="text-rose-400 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Current Live Card Card & Timer Controls Header */}
      {currentAuction.status === 'CONCLUDED' && card && (
        <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-amber-200 text-sm font-semibold flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Clock className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <p className="font-bold">TIMER EXPIRED (00:00) · BIDDING CLOSED</p>
              <p className="text-xs text-amber-300/80 font-normal mt-0.5">
                The card is NOT sold automatically. Please review the final bid and confirm sale to the winning team in Sale &amp; Team Assignment, or mark as No Sale.
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="bg-[#10141a] border border-[#212836] rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-[#1f2633]">
          <div className="flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-widest text-[#9ca3af]">
              LIVE AUCTION FLOOR
            </span>
            {card && (
              <span className="px-3 py-1 rounded text-xs font-extrabold uppercase bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/30">
                {card.category} · {card.sector}
              </span>
            )}
          </div>

          {/* Timer Controls Bar */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#161a22] border border-[#263040]">
              <Clock className="w-4 h-4 text-[#d4af37]" />
              <span className={`font-mono-val font-black text-xl tabular-nums ${
                currentAuction.timerSeconds <= 10 ? 'text-rose-500 animate-pulse' : 'text-white'
              }`}>
                {formatTimer(currentAuction.timerSeconds)}
              </span>
              <span className="text-[10px] font-bold uppercase text-[#64748b] ml-1">
                {currentAuction.status}
              </span>
            </div>

            {/* Start / Pause / Resume / Reset */}
            {!currentAuction.timerIsRunning ? (
              <button
                onClick={() => auctionStore.timerControl('START')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>START</span>
              </button>
            ) : (
              <button
                onClick={() => auctionStore.timerControl('PAUSE')}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <Pause className="w-3.5 h-3.5 fill-current" />
                <span>PAUSE</span>
              </button>
            )}

            <button
              onClick={() => auctionStore.timerControl('RESET')}
              className="p-2 rounded-xl bg-[#181d26] hover:bg-[#252c38] text-[#9ca3af] hover:text-white border border-[#263040] transition-colors"
              title="Reset Timer to 60s"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={() => auctionStore.timerControl('EXTEND')}
              className="px-3 py-2 bg-[#181d26] hover:bg-[#252c38] text-amber-300 text-xs font-mono font-bold rounded-xl border border-[#263040] transition-colors"
              title="Add 20 Seconds Manual Extension"
            >
              +20S
            </button>
          </div>
        </div>

        {/* Card Title & Queue Load Controls */}
        <div className="mt-6 flex flex-wrap items-start justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-2xl sm:text-4xl font-extrabold text-white leading-tight">
                {card ? card.name : 'No Card Selected in Auction'}
              </h2>
              {card && onEditCurrentCard && (
                <button
                  onClick={() => onEditCurrentCard(card)}
                  className="px-3 py-1.5 bg-[#171c26] hover:bg-[#232b38] text-[#d4af37] hover:text-[#f3d16b] border border-[#d4af37]/40 hover:border-[#d4af37] text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                  title="Edit this card's title or problem statement"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>EDIT CARD</span>
                </button>
              )}
            </div>
            <p className="text-sm text-[#94a3b8] leading-relaxed">
              {card ? card.description : 'Load next card from queue to begin auction round.'}
            </p>
          </div>

          {/* Action Buttons: Card Bank Management & Load Next Card */}
          <div className="flex flex-wrap items-center gap-2.5">
            {onOpenCardBank && (
              <button
                id="btn-admin-card-bank-management"
                data-testid="admin-card-bank-btn"
                onClick={onOpenCardBank}
                className="px-4 py-2.5 bg-[#171c26] hover:bg-[#222a3a] text-[#d4af37] hover:text-white border border-[#d4af37]/60 hover:border-[#d4af37] text-xs font-black uppercase tracking-wider rounded-xl transition-all shadow-md shadow-[#d4af37]/15 flex items-center gap-2 cursor-pointer ring-1 ring-[#d4af37]/30"
                title="Open Card Bank Management (120 Cards across all 4 categories)"
              >
                <Layers className="w-4 h-4 text-[#d4af37]" />
                <span>CARD BANK MANAGEMENT ({cards.length})</span>
              </button>
            )}

            <button
              onClick={() => auctionStore.loadNextCard()}
              className="px-4 py-2.5 bg-[#d4af37] hover:bg-[#e6bf47] text-[#0a0c10] font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>LOAD NEXT CARD</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Card Bank Quick Repository Banner */}
      <div className="bg-[#0e1117] border border-[#232b3b] rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-[#d4af37]/15 text-[#d4af37] border border-[#d4af37]/30">
            <Layers className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-white">
                CARD BANK MANAGEMENT (120 CARDS)
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/40">
                Authoritative Repository
              </span>
            </div>
            <p className="text-[11px] text-[#8e95a2] mt-0.5">
              30 Stakeholder · 30 Challenge · 30 Constraint · 30 Impact. Search, filter, and edit card titles or problem statements.
            </p>
          </div>
        </div>

        {onOpenCardBank && (
          <button
            onClick={onOpenCardBank}
            className="px-3.5 py-1.5 rounded-xl bg-[#1b212d] hover:bg-[#d4af37] hover:text-[#0a0c10] text-[#d4af37] text-xs font-bold uppercase tracking-wider border border-[#d4af37]/40 hover:border-[#d4af37] transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>OPEN &amp; EDIT CARDS</span>
          </button>
        )}
      </div>

      {/* SCREENSHOT 2 REPRODUCTION: Current Bid, Confirmed Final Bid, Manual Controls, Sale & Assignment */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* LEFT COLUMN: A. Current Bid & B. Confirmed Final Bid & C. Manual Bid Controls */}
        <div className="space-y-6">
          {/* A. CURRENT BID & B. CONFIRMED FINAL BID PANELS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Current Accepted Bid Panel */}
            <div className="bg-[#11141b] border border-[#222836] rounded-2xl p-5 shadow-lg flex flex-col justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#9ca3af]">
                  CURRENT BID
                </span>
                <div className="font-mono-val text-3xl font-black text-[#d4af37] mt-1.5">
                  {formatRupees(currentAuction.currentBid)}
                </div>
                <p className="text-xs text-[#9ca3af] mt-0.5 font-medium">
                  {formatRupeesWords(currentAuction.currentBid)}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#1e2430] flex items-center justify-between text-[11px] text-[#64748b]">
                <span>Accepted Bids: <strong className="text-white font-mono">{currentAuction.bidCount}</strong></span>
                <span>Opening: ₹10 Lakh</span>
              </div>
            </div>

            {/* Confirmed Final Bid Panel */}
            <div className="bg-[#11141b] border border-[#222836] rounded-2xl p-5 shadow-lg flex flex-col justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#9ca3af]">
                  CONFIRMED FINAL BID
                </span>
                <div className="font-mono-val text-3xl font-black text-emerald-400 mt-1.5">
                  {currentAuction.confirmedFinalBid
                    ? formatRupees(currentAuction.confirmedFinalBid)
                    : formatRupees(currentAuction.currentBid)}
                </div>
                <p className="text-xs text-emerald-400/80 mt-0.5 font-medium">
                  {currentAuction.confirmedFinalBid
                    ? formatRupeesWords(currentAuction.confirmedFinalBid)
                    : 'Pending confirmation'}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#1e2430] flex items-center justify-between text-[11px]">
                <span className="text-[#64748b]">Status:</span>
                <span className={`font-mono font-bold uppercase px-2 py-0.5 rounded text-[10px] ${
                  currentAuction.confirmedFinalBidStatus === 'CONFIRMED'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                }`}>
                  {currentAuction.confirmedFinalBidStatus === 'CONFIRMED'
                    ? 'CONFIRMED'
                    : 'PENDING CONFIRMATION'}
                </span>
              </div>
            </div>
          </div>

          {/* C. MANUAL BID CONTROLS PANEL */}
          <div className="bg-[#11141b] border border-[#222836] rounded-2xl p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-[#1f2633] pb-3">
              <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white">
                Manual Bid Controls
              </h3>
              <span className="text-[11px] text-[#8e95a2] font-mono">
                Increments: ₹10L &lt; ₹1Cr | ₹20L &ge; ₹1Cr
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                ENTER BID AMOUNT (₹)
              </label>

              {/* Amount Input with Minus and Plus Controls */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={handleDecrementInput}
                  className="w-12 h-12 rounded-xl bg-[#171b24] hover:bg-[#202634] text-white border border-[#283244] flex items-center justify-center font-bold text-lg transition-colors cursor-pointer"
                  title="Decrement according to increment rules"
                >
                  <Minus className="w-5 h-5" />
                </button>

                <div className="flex-1 relative">
                  <input
                    type="number"
                    step="1000000"
                    value={manualBidInput}
                    onChange={(e) => {
                      setManualBidInput(Number(e.target.value));
                      setBidError(null);
                    }}
                    className="w-full bg-[#161a22] border border-[#283140] text-xl font-mono-val font-bold text-white px-4 py-2.5 rounded-xl outline-none focus:border-[#d4af37]"
                  />
                  <span className="absolute right-3.5 top-3 text-xs font-mono text-[#64748b]">
                    INR
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handleIncrementInput}
                  className="w-12 h-12 rounded-xl bg-[#171b24] hover:bg-[#202634] text-white border border-[#283244] flex items-center justify-center font-bold text-lg transition-colors cursor-pointer"
                  title="Increment according to increment rules"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>

              {/* Formatted readable amount equivalent */}
              <div className="mt-2 flex items-center justify-between text-xs text-[#8e95a2]">
                <span>Equivalent: <strong className="text-[#d4af37] font-semibold">{formatRupeesWords(manualBidInput)}</strong></span>
                <span>{formatRupees(manualBidInput)}</span>
              </div>
            </div>

            {/* Set As Final Bid Button */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleSetAsFinalBid}
                className="flex-1 py-3 px-4 bg-[#1a202c] hover:bg-[#252e3e] text-[#d4af37] border border-[#d4af37]/40 hover:border-[#d4af37] font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
              >
                <span>SET AS FINAL BID</span>
              </button>

              {/* DIRECT + BID BUTTON (Official unassigned admin bid) */}
              <button
                type="button"
                onClick={handleDirectPlusBid}
                disabled={!isBiddingOpen}
                className={`flex-1 py-3 px-4 font-black text-xs uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-2 ${
                  isBiddingOpen
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer shadow-emerald-950/40'
                    : 'bg-[#181d26] text-[#64748b] border border-[#232a36] cursor-not-allowed opacity-60'
                }`}
                title={!isBiddingOpen ? 'Bidding is currently closed or timer expired' : 'Immediately place official next accepted bid without selecting team'}
              >
                <Plus className="w-4 h-4" />
                <span>+ BID ({formatRupeesWords(nextMinBid)})</span>
              </button>
            </div>

            {/* Optional Team-Specific Bid Workflow */}
            <div className="pt-3 border-t border-[#1e2430]">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#8e95a2] block mb-2">
                Or Submit Bid on Behalf of Specific Team:
              </span>
              <div className="flex items-center gap-2">
                <select
                  value={teamBidSelectId}
                  onChange={(e) => setTeamBidSelectId(e.target.value)}
                  disabled={!isBiddingOpen}
                  className="flex-1 bg-[#161a22] border border-[#283140] text-xs text-white px-3 py-2.5 rounded-xl outline-none focus:border-[#d4af37] disabled:opacity-50"
                >
                  <option value="">Select Team for Bid...</option>
                  {eligibleTeams.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} (Rem: {formatRupeesWords(t.remainingBudget)})
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={handleTeamSpecificBid}
                  disabled={!isBiddingOpen || !teamBidSelectId}
                  className={`px-4 py-2.5 text-xs font-bold rounded-xl border transition-colors ${
                    isBiddingOpen && teamBidSelectId
                      ? 'bg-[#1b212c] hover:bg-[#262f3e] text-[#d4af37] border-[#d4af37]/40 cursor-pointer'
                      : 'bg-[#12151b] text-[#556070] border-[#1d222b] cursor-not-allowed opacity-60'
                  }`}
                >
                  Bid for Team
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: D. Sale & Team Assignment Panel */}
        <div className="bg-[#11141b] border border-[#222836] rounded-2xl p-6 shadow-xl flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-[#1f2633] pb-3">
              <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white">
                Sale &amp; Team Assignment
              </h3>
              <span className="text-[11px] text-emerald-400 font-mono font-semibold">
                Permanent Sale Finalization
              </span>
            </div>

            {/* Team Selector */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-2">
                SELECT WINNING TEAM
              </label>
              <select
                value={selectedTeamId}
                onChange={(e) => setSelectedTeamId(e.target.value)}
                className="w-full bg-[#161a22] border border-[#283140] text-sm text-white px-4 py-3 rounded-xl outline-none focus:border-[#d4af37]"
              >
                <option value="">Choose winning team...</option>
                {eligibleTeams.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} — Remaining: {formatRupeesWords(t.remainingBudget)} (Won: {t.acquiredCards.length}/4)
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-[#64748b] mt-1.5">
                Teams already owning this category or with insufficient budget are excluded automatically.
              </p>
            </div>

            {/* Sale Summary Preview */}
            {selectedTeamId && card && (
              <div className="bg-[#151922] border border-[#263040] rounded-xl p-4 text-xs space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-[#8e95a2]">Card:</span>
                  <span className="font-bold text-white">{card.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8e95a2]">Category:</span>
                  <span className="text-[#d4af37] font-bold">{card.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8e95a2]">Final Sale Amount:</span>
                  <span className="font-mono-val font-bold text-emerald-400">
                    {formatRupees(currentAuction.confirmedFinalBid || currentAuction.currentBid)}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons: SELL CARD, MARK AS UNSOLD, UNDO LAST SALE */}
          <div className="space-y-3 pt-4 border-t border-[#1f2633]">
            {/* SELL CARD BUTTON */}
            <button
              type="button"
              onClick={handleInitiateSellCard}
              disabled={!card || currentAuction.status === 'SOLD'}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-[#c89b3c] to-[#e6bd54] hover:from-[#d4af37] hover:to-[#f3c85f] text-[#0a0c10] font-black text-sm uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-[#d4af37]/15 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Award className="w-4 h-4" />
              <span>SELL CARD &amp; BROADCAST RESULT</span>
            </button>

            <div className="grid grid-cols-2 gap-3">
              {/* MARK AS UNSOLD BUTTON */}
              <button
                type="button"
                onClick={handleMarkUnsold}
                disabled={!card || currentAuction.status === 'SOLD'}
                className="py-2.5 px-3 bg-[#181d26] hover:bg-[#252c38] text-rose-400 border border-rose-500/30 hover:border-rose-500 font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer disabled:opacity-50"
              >
                MARK AS UNSOLD
              </button>

              {/* UNDO LAST SALE BUTTON */}
              <button
                type="button"
                onClick={handleUndoLastSale}
                className="py-2.5 px-3 bg-[#181d26] hover:bg-[#252c38] text-[#9ca3af] hover:text-white border border-[#283244] font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                title="Safely reverse the last confirmed sale and refund team budget"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>UNDO LAST SALE</span>
              </button>
            </div>

            {/* RESET AUCTION BUTTON */}
            <button
              type="button"
              onClick={onOpenResetModal || (() => setShowLocalResetModal(true))}
              className="w-full py-2.5 px-3 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 border border-rose-500/30 hover:border-rose-500/50 font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]"
              title="Administrator Reset: Clear auction progress, restore ₹10 Cr budgets, and restart cleanly"
            >
              <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
              <span>RESET AUCTION TO STARTING STATE</span>
            </button>
          </div>
        </div>
      </div>

      {/* Sale Confirmation Modal */}
      {saleConfirmationModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12161f] border-2 border-[#d4af37] rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl animate-fade-in space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-[#242c3b] text-[#d4af37]">
              <Award className="w-6 h-6" />
              <h3 className="font-display font-extrabold text-xl text-white">
                Confirm Official Final Sale
              </h3>
            </div>

            <p className="text-xs text-[#94a3b8] leading-relaxed">
              Review and confirm the sale transaction. This will deduct the exact amount from the winning team's budget, update their portfolio, mark the card as sold, and broadcast to the Auditorium Projector.
            </p>

            <div className="bg-[#0e1218] border border-[#212836] rounded-2xl p-5 space-y-3 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-[#8e95a2]">Strategy Card:</span>
                <span className="font-bold text-white text-right">{saleConfirmationModal.card.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8e95a2]">Category &amp; Sector:</span>
                <span className="text-[#d4af37]">{saleConfirmationModal.card.category} ({saleConfirmationModal.card.sector})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8e95a2]">Winning Team:</span>
                <span className="font-bold text-white">{saleConfirmationModal.team.name}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-[#1b212c]">
                <span className="text-[#8e95a2]">Final Sale Amount:</span>
                <span className="font-mono-val font-bold text-emerald-400 text-sm">
                  {formatRupees(saleConfirmationModal.amount)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8e95a2]">Remaining Budget After Sale:</span>
                <span className="font-mono-val font-bold text-[#d4af37]">
                  {formatRupees(saleConfirmationModal.remainingBudgetAfter)}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSaleConfirmationModal(null)}
                className="px-4 py-2 text-xs font-semibold text-[#8e95a2] hover:text-white cursor-pointer"
              >
                Cancel / Edit
              </button>
              <button
                type="button"
                onClick={handleConfirmSale}
                className="px-6 py-3 bg-[#d4af37] hover:bg-[#e6bf47] text-[#0a0c10] font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all cursor-pointer"
              >
                Confirm Sale Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Standalone Reset Auction Modal */}
      <ResetAuctionModal
        isOpen={showLocalResetModal}
        onClose={() => setShowLocalResetModal(false)}
        onSuccess={(msg) => {
          setFeedback({ type: 'success', message: msg });
          setTimeout(() => setFeedback(null), 5000);
        }}
      />
    </div>
  );
};
