/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CurrentAuctionState, Team } from '../types/auction';
import { formatRupees, formatRupeesWords, formatTimer } from '../utils/formatters';
import { checkTeamEligibility, getNextMinimumBid } from '../utils/auctionRules';
import { auctionStore } from '../services/auctionStore';
import { Header } from './Header';
import { AlertCircle, CheckCircle, Radio } from 'lucide-react';

interface OpenBidPanelProps {
  currentAuction: CurrentAuctionState;
  teams: Team[];
}

export const OpenBidPanel: React.FC<OpenBidPanelProps> = ({ currentAuction, teams }) => {
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const card = currentAuction.card;
  const isTimerExpired = currentAuction.timerSeconds <= 0 || currentAuction.status === 'CONCLUDED';
  const isAuctionActive = (currentAuction.status === 'ACTIVE' || currentAuction.status === 'READY') && !isTimerExpired;
  const nextMinBid = getNextMinimumBid(currentAuction.currentBid, currentAuction.bidCount);

  // Initial 30 teams (TEAM 1 to TEAM 30)
  const initialThirtyTeams = teams
    .filter((t) => !t.isArchived)
    .slice(0, 30);

  const handleTeamBidClick = async (team: Team) => {
    if (!isAuctionActive || !card || isTimerExpired) {
      setFeedback({
        type: 'error',
        message: isTimerExpired
          ? 'Auction timer has expired (00:00). Bids are no longer accepted.'
          : 'Auction is not currently active. Bidding disabled.',
      });
      return;
    }

    if (isSubmitting) return;

    setIsSubmitting(true);
    setFeedback(null);

    // Validate eligibility
    const eligibility = checkTeamEligibility(team, card.category, nextMinBid);
    if (!eligibility.eligible) {
      setFeedback({
        type: 'error',
        message: `${team.name}: ${eligibility.reason}`,
      });
      setIsSubmitting(false);
      return;
    }

    // Submit bid immediately without extra confirmation click
    const res = await auctionStore.submitBid({
      amount: nextMinBid,
      teamId: team.id,
      isUnassignedAdmin: false,
    });

    if (res.success) {
      setFeedback({
        type: 'success',
        message: `Accepted Bid: ₹${(nextMinBid / 100000).toFixed(0)} Lakh for ${team.name}!`,
      });
    } else {
      setFeedback({
        type: 'error',
        message: res.error || 'Failed to submit bid',
      });
    }

    setIsSubmitting(false);

    // Auto clear feedback after 3.5s
    setTimeout(() => {
      setFeedback((prev) => (prev?.message.includes(team.name) ? null : prev));
    }, 3500);
  };

  return (
    <div className="min-h-screen bg-[#080a0d] text-slate-100 flex flex-col">
      <Header currentRole="guest" />

      {/* Main Floor Bid Interface */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Top Header Bar: Current Live Card & Bid State */}
        <div className="bg-[#11141a] border border-[#212733] rounded-2xl p-5 lg:p-6 shadow-xl flex flex-wrap items-center justify-between gap-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-bold tracking-widest text-[#94a3b8] uppercase">
                AUCTION FLOOR OPEN BID PANEL
              </span>
              {card && (
                <span className="px-2.5 py-0.5 rounded text-[11px] font-bold bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/30 uppercase">
                  {card.category} · {card.sector}
                </span>
              )}
            </div>

            <h2 className="text-xl sm:text-2xl font-bold font-display text-white">
              {card ? card.name : 'No Card Currently in Auction'}
            </h2>
          </div>

          {/* Current Bid & Timer Indicators */}
          <div className="flex items-center gap-6">
            <div className="text-right">
              <p className="text-[11px] font-semibold text-[#8e95a2] uppercase tracking-wider">
                CURRENT BID
              </p>
              <p className="text-2xl font-extrabold font-mono-val text-[#d4af37]">
                {formatRupees(currentAuction.currentBid)}
              </p>
              <p className="text-xs text-[#8e95a2]">
                {formatRupeesWords(currentAuction.currentBid)}
              </p>
            </div>

            <div className="text-right pl-6 border-l border-[#242b38]">
              <p className="text-[11px] font-semibold text-[#8e95a2] uppercase tracking-wider">
                NEXT MIN BID
              </p>
              <p className="text-2xl font-extrabold font-mono-val text-emerald-400">
                {formatRupees(nextMinBid)}
              </p>
              <p className="text-xs text-emerald-400/80">
                {formatRupeesWords(nextMinBid)}
              </p>
            </div>

            <div className="text-center pl-6 border-l border-[#242b38]">
              <p className="text-[11px] font-semibold text-[#8e95a2] uppercase tracking-wider">
                TIMER
              </p>
              <p className={`text-2xl font-black font-mono-val tabular-nums ${
                currentAuction.timerSeconds <= 10 ? 'text-rose-500 animate-pulse' : 'text-white'
              }`}>
                {formatTimer(currentAuction.timerSeconds)}
              </p>
              <span className={`text-[10px] uppercase font-bold ${
                isTimerExpired ? 'text-rose-400 font-extrabold' : 'text-[#64748b]'
              }`}>
                {isTimerExpired ? 'EXPIRED (00:00)' : currentAuction.status}
              </span>
            </div>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`p-4 rounded-xl flex items-center gap-3 text-sm font-medium animate-fade-in ${
              feedback.type === 'success'
                ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-500/30'
                : 'bg-rose-950/40 text-rose-300 border border-rose-500/30'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}

        {/* 30 Team Buttons Grid */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-[#8e95a2]">
            <span>Click any team button to instantly place next bid of {formatRupeesWords(nextMinBid)}</span>
            <span>Initial Teams (TEAM 1 - TEAM 30)</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6 gap-3">
            {initialThirtyTeams.map((team) => {
              const eligibility = card
                ? checkTeamEligibility(team, card.category, nextMinBid)
                : { eligible: false, reason: 'No active card' };

              const isEligible = isAuctionActive && eligibility.eligible;

              return (
                <button
                  key={team.id}
                  onClick={() => handleTeamBidClick(team)}
                  disabled={!isEligible || isSubmitting}
                  className={`relative p-3.5 rounded-xl border text-left transition-all duration-150 flex flex-col justify-between min-h-[92px] ${
                    isEligible
                      ? 'bg-[#13171f] hover:bg-[#1c222c] active:scale-95 border-[#283140] hover:border-[#d4af37] text-white shadow-md cursor-pointer group'
                      : 'bg-[#0e1014] border-[#1a1e24] text-[#4b5563] cursor-not-allowed opacity-60'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className={`font-display text-sm font-bold tracking-wider ${
                      isEligible ? 'group-hover:text-[#d4af37]' : 'text-[#4b5563]'
                    }`}>
                      {team.name}
                    </span>
                    <span className="text-[10px] font-mono font-medium px-1.5 py-0.5 rounded bg-[#181d26] text-[#8e95a2]">
                      {team.acquiredCards.length}/4
                    </span>
                  </div>

                  <div className="mt-2 space-y-0.5">
                    <p className="text-[11px] font-mono-val text-[#9ca3af]">
                      Rem: {formatRupeesWords(team.remainingBudget)}
                    </p>
                    {!eligibility.eligible && card && (
                      <p className="text-[9px] font-medium text-rose-400/80 truncate" title={eligibility.reason}>
                        {eligibility.reason}
                      </p>
                    )}
                  </div>

                  {isEligible && (
                    <div className="mt-1 text-[10px] font-bold text-emerald-400 flex items-center justify-between">
                      <span>BID NOW</span>
                      <span>+{formatRupeesWords(nextMinBid)}</span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </main>
    </div>
  );
};
