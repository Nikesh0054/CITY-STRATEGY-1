/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Bid } from '../types/auction';
import { formatRupees, formatRupeesWords, formatDateTime } from '../utils/formatters';
import { Download } from 'lucide-react';

interface BidHistoryViewProps {
  bids: Bid[];
}

export const BidHistoryView: React.FC<BidHistoryViewProps> = ({ bids }) => {
  const downloadBidsCSV = () => {
    const headers = ['Bid ID', 'Card Name', 'Bidder', 'Amount (INR)', 'Type', 'Timestamp'];
    const rows = bids.map((b) => [
      b.id,
      `"${b.cardName.replace(/"/g, '""')}"`,
      b.isUnassignedAdmin ? 'Unassigned Admin' : b.bidderName,
      b.amount,
      b.isUnassignedAdmin ? 'OFFICIAL_DIRECT_BID' : 'TEAM_BID',
      new Date(b.timestamp).toISOString(),
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `csc_bid_history_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#11141b] border border-[#212734] rounded-2xl p-5 shadow-lg">
        <div>
          <h3 className="font-display font-bold text-base text-white">Authoritative Bid History</h3>
          <p className="text-xs text-[#8e95a2] mt-0.5">
            Total Accepted Bids Recorded: {bids.length}
          </p>
        </div>

        <button
          onClick={downloadBidsCSV}
          className="flex items-center gap-2 px-4 py-2 bg-[#1b212c] hover:bg-[#252e3e] text-[#d4af37] border border-[#d4af37]/40 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Export Bids CSV</span>
        </button>
      </div>

      <div className="bg-[#101319] border border-[#212733] rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#141821] border-b border-[#212733] text-[#8e95a2] uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3.5 px-4">Card</th>
                <th className="py-3.5 px-4">Bid Amount</th>
                <th className="py-3.5 px-4">Bidder Attribution</th>
                <th className="py-3.5 px-4">Bid Type</th>
                <th className="py-3.5 px-4">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b212b]">
              {bids.length > 0 ? (
                bids.map((b) => (
                  <tr key={b.id} className="hover:bg-[#151922] transition-colors">
                    <td className="py-3.5 px-4 font-display font-semibold text-white max-w-xs truncate">
                      {b.cardName}
                    </td>
                    <td className="py-3.5 px-4 font-mono-val font-bold text-[#d4af37]">
                      {formatRupees(b.amount)}
                      <span className="text-[10px] text-[#8e95a2] font-normal block">
                        {formatRupeesWords(b.amount)}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      {b.isUnassignedAdmin ? (
                        <span className="font-medium text-[#9ca3af] italic">
                          Administrator (Unassigned)
                        </span>
                      ) : (
                        <span className="font-bold text-white font-display">
                          {b.bidderName}
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      {b.isUnassignedAdmin ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-sky-500/15 text-sky-400 border border-sky-500/30">
                          OFFICIAL +BID
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                          TEAM BID
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-[#8e95a2]">
                      {formatDateTime(b.timestamp)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-[#64748b]">
                    No bids recorded yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
