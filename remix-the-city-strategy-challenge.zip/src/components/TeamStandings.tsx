/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Team } from '../types/auction';
import { formatRupees, formatRupeesWords } from '../utils/formatters';
import { Download, Award, CheckCircle } from 'lucide-react';

interface TeamStandingsProps {
  teams: Team[];
}

export const TeamStandings: React.FC<TeamStandingsProps> = ({ teams }) => {
  // Sort numerically: TEAM 1, TEAM 2, ... TEAM 30
  const sortedTeams = [...teams].sort((a, b) => {
    const numA = parseInt(a.name.replace(/\D/g, ''), 10) || 999;
    const numB = parseInt(b.name.replace(/\D/g, ''), 10) || 999;
    return numA - numB;
  });

  const downloadStandingsCSV = () => {
    const headers = [
      'Team Name',
      'Cards Won (out of 4)',
      'Stakeholder',
      'Challenge',
      'Constraint',
      'Impact',
      'Initial Budget (INR)',
      'Total Spent (INR)',
      'Remaining Budget (INR)',
    ];

    const rows = sortedTeams.map((t) => [
      t.name,
      t.acquiredCards.length,
      t.categoryProgress.STAKEHOLDER ? 'YES' : 'NO',
      t.categoryProgress.CHALLENGE ? 'YES' : 'NO',
      t.categoryProgress.CONSTRAINT ? 'YES' : 'NO',
      t.categoryProgress.IMPACT ? 'YES' : 'NO',
      t.initialBudget,
      t.totalSpent,
      t.remainingBudget,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `csc_team_standings_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#11141b] border border-[#212734] rounded-2xl p-5 shadow-lg">
        <div>
          <h3 className="font-display font-bold text-base text-white">Official Team Standings</h3>
          <p className="text-xs text-[#8e95a2] mt-0.5">
            Numerical team order (TEAM 1 to TEAM 30) with real-time portfolio progress
          </p>
        </div>

        <button
          onClick={downloadStandingsCSV}
          className="flex items-center gap-2 px-4 py-2 bg-[#1b212c] hover:bg-[#252e3e] text-[#d4af37] border border-[#d4af37]/40 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Export Standings CSV</span>
        </button>
      </div>

      {/* Standings Table */}
      <div className="bg-[#101319] border border-[#212733] rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#141821] border-b border-[#212733] text-[#8e95a2] uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3.5 px-4">Team</th>
                <th className="py-3.5 px-4 text-center">Cards Won</th>
                <th className="py-3.5 px-4 text-center">Stakeholder</th>
                <th className="py-3.5 px-4 text-center">Challenge</th>
                <th className="py-3.5 px-4 text-center">Constraint</th>
                <th className="py-3.5 px-4 text-center">Impact</th>
                <th className="py-3.5 px-4">Initial Budget</th>
                <th className="py-3.5 px-4">Total Spent</th>
                <th className="py-3.5 px-4">Remaining Budget</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b212b]">
              {sortedTeams.map((team) => (
                <tr key={team.id} className="hover:bg-[#151922] transition-colors">
                  <td className="py-3.5 px-4 font-display font-bold text-white">
                    {team.name}
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono font-bold">
                    <span className={`px-2.5 py-1 rounded text-xs ${
                      team.acquiredCards.length === 4
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                        : team.acquiredCards.length > 0
                        ? 'bg-[#d4af37]/20 text-[#f5d77f] border border-[#d4af37]/30'
                        : 'bg-[#181d26] text-[#64748b]'
                    }`}>
                      {team.acquiredCards.length}/4
                    </span>
                  </td>
                  {/* Category check indicators */}
                  <td className="py-3.5 px-4 text-center">
                    {team.categoryProgress.STAKEHOLDER ? (
                      <span className="inline-block w-3 h-3 rounded-full bg-emerald-400" title="Acquired" />
                    ) : (
                      <span className="inline-block w-2.5 h-2.5 rounded-full bg-[#202734]" />
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    {team.categoryProgress.CHALLENGE ? (
                      <span className="inline-block w-3 h-3 rounded-full bg-emerald-400" title="Acquired" />
                    ) : (
                      <span className="inline-block w-2.5 h-2.5 rounded-full bg-[#202734]" />
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    {team.categoryProgress.CONSTRAINT ? (
                      <span className="inline-block w-3 h-3 rounded-full bg-emerald-400" title="Acquired" />
                    ) : (
                      <span className="inline-block w-2.5 h-2.5 rounded-full bg-[#202734]" />
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    {team.categoryProgress.IMPACT ? (
                      <span className="inline-block w-3 h-3 rounded-full bg-emerald-400" title="Acquired" />
                    ) : (
                      <span className="inline-block w-2.5 h-2.5 rounded-full bg-[#202734]" />
                    )}
                  </td>
                  <td className="py-3.5 px-4 font-mono-val text-slate-400">
                    {formatRupeesWords(team.initialBudget)}
                  </td>
                  <td className="py-3.5 px-4 font-mono-val font-semibold text-amber-400">
                    {formatRupeesWords(team.totalSpent)}
                  </td>
                  <td className="py-3.5 px-4 font-mono-val font-bold text-emerald-400">
                    {formatRupeesWords(team.remainingBudget)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
