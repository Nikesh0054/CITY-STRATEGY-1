/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CSCState } from '../types/auction';
import { Header } from './Header';
import { AdminLiveAuction } from './AdminLiveAuction';
import { TeamsManagement } from './TeamsManagement';
import { CardBank } from './CardBank';
import { SalesRegister } from './SalesRegister';
import { TeamStandings } from './TeamStandings';
import { BidHistoryView } from './BidHistoryView';
import { AuditLogView } from './AuditLogView';
import {
  Gavel,
  Users,
  Layers,
  FileSpreadsheet,
  ListOrdered,
  History,
  ShieldCheck,
  RotateCcw,
  CheckCircle2,
} from 'lucide-react';
import { ResetAuctionModal } from './ResetAuctionModal';

interface AdminPortalProps {
  state: CSCState;
  onLogout: () => void;
  initialTab?: 'live' | 'teams' | 'cards' | 'sales' | 'standings' | 'bids' | 'audit';
}

export const AdminPortal: React.FC<AdminPortalProps> = ({ state, onLogout, initialTab }) => {
  const [activeTab, setActiveTab] = useState<
    'live' | 'teams' | 'cards' | 'sales' | 'standings' | 'bids' | 'audit'
  >(() => {
    if (initialTab) return initialTab;
    const urlTab = typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('tab') : null;
    if (urlTab === 'cards' || (typeof window !== 'undefined' && window.location.pathname.includes('card'))) return 'cards';
    if (urlTab === 'teams') return 'teams';
    if (urlTab === 'sales') return 'sales';
    if (urlTab === 'standings') return 'standings';
    if (urlTab === 'bids') return 'bids';
    if (urlTab === 'audit') return 'audit';
    return 'live';
  });

  // Keep activeTab in sync with initialTab prop changes
  React.useEffect(() => {
    if (initialTab && initialTab !== activeTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Sync activeTab with URL search params so browser refresh keeps the active tab
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      if (activeTab === 'live') {
        url.searchParams.delete('tab');
      } else {
        url.searchParams.set('tab', activeTab);
      }
      window.history.replaceState({}, '', url.toString());
    }
  }, [activeTab]);

  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const handleResetSuccess = (message: string) => {
    setSuccessToast(message);
    setActiveTab('live');
    setTimeout(() => {
      setSuccessToast(null);
    }, 6000);
  };

  return (
    <div className="min-h-screen bg-[#07090c] text-slate-100 flex flex-col selection:bg-amber-500/20">
      <Header currentRole="admin" onLogout={onLogout} activeTab={activeTab} onTabChange={(tab) => setActiveTab(tab as any)} />

      {/* Success Notification Toast */}
      {successToast && (
        <div className="bg-emerald-950/90 border-b border-emerald-500/40 text-emerald-200 px-4 py-3 text-xs font-medium flex items-center justify-between sticky top-[57px] z-50 animate-fade-in backdrop-blur-md">
          <div className="max-w-7xl mx-auto flex items-center gap-2.5 w-full">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successToast}</span>
          </div>
          <button
            onClick={() => setSuccessToast(null)}
            className="text-emerald-400 hover:text-white text-xs px-2 py-0.5 rounded cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Admin Navigation Tabs Bar */}
      <nav className="border-b border-[#1f2532] bg-[#0c0f14] px-4 sm:px-8 py-2 sticky top-[57px] z-30 shadow-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 overflow-x-auto py-1">
          <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => setActiveTab('live')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'live'
                ? 'bg-[#d4af37] text-[#0a0c10] shadow-md'
                : 'text-[#9ca3af] hover:text-white hover:bg-[#161a22]'
            }`}
          >
            <Gavel className="w-3.5 h-3.5" />
            <span>Live Auction</span>
          </button>

          <button
            onClick={() => setActiveTab('teams')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'teams'
                ? 'bg-[#d4af37] text-[#0a0c10] shadow-md'
                : 'text-[#9ca3af] hover:text-white hover:bg-[#161a22]'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Teams ({state.teams.length})</span>
          </button>

          {/* CARD BANK MANAGEMENT TAB: Prominently highlighted with golden badge & count */}
          <button
            id="nav-card-bank-management"
            data-testid="card-bank-management-tab"
            onClick={() => setActiveTab('cards')}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap border ${
              activeTab === 'cards'
                ? 'bg-[#d4af37] text-[#0a0c10] border-[#d4af37] shadow-lg shadow-[#d4af37]/30 ring-2 ring-[#d4af37]/50'
                : 'bg-[#151922] text-[#d4af37] border-[#d4af37]/60 hover:bg-[#202736] hover:border-[#d4af37] hover:text-white shadow-sm'
            }`}
          >
            <Layers className="w-4 h-4 text-[#d4af37]" />
            <span>CARD BANK MANAGEMENT ({state.cards.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('sales')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'sales'
                ? 'bg-[#d4af37] text-[#0a0c10] shadow-md'
                : 'text-[#9ca3af] hover:text-white hover:bg-[#161a22]'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Sales Register ({state.salesRegister.filter((s) => !s.isReversed).length})</span>
          </button>

          <button
            onClick={() => setActiveTab('standings')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'standings'
                ? 'bg-[#d4af37] text-[#0a0c10] shadow-md'
                : 'text-[#9ca3af] hover:text-white hover:bg-[#161a22]'
            }`}
          >
            <ListOrdered className="w-3.5 h-3.5" />
            <span>Standings</span>
          </button>

          <button
            onClick={() => setActiveTab('bids')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'bids'
                ? 'bg-[#d4af37] text-[#0a0c10] shadow-md'
                : 'text-[#9ca3af] hover:text-white hover:bg-[#161a22]'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Bid History ({state.bidHistory.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'audit'
                ? 'bg-[#d4af37] text-[#0a0c10] shadow-md'
                : 'text-[#9ca3af] hover:text-white hover:bg-[#161a22]'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Audit Trail</span>
          </button>
          </div>

          {/* Dedicated Administrator-Only RESET AUCTION Button */}
          <button
            type="button"
            onClick={() => setIsResetModalOpen(true)}
            className="px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 hover:text-rose-300 border border-rose-500/30 hover:border-rose-500 shadow-sm shrink-0 ml-auto active:scale-[0.98]"
            title="Administrator Reset: Clear auction progress and start fresh from Stakeholder Card #1"
          >
            <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
            <span>RESET AUCTION</span>
          </button>
        </div>
      </nav>

      {/* Tab Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'live' && (
          <AdminLiveAuction
            currentAuction={state.currentAuction}
            teams={state.teams}
            cards={state.cards}
            auctionQueue={state.auctionQueue}
            onOpenResetModal={() => setIsResetModalOpen(true)}
            onOpenCardBank={() => setActiveTab('cards')}
            onEditCurrentCard={(card) => {
              setEditingCardId(card.id);
              setActiveTab('cards');
            }}
          />
        )}

        {activeTab === 'teams' && (
          <TeamsManagement teams={state.teams} />
        )}

        {activeTab === 'cards' && (
          <CardBank
            cards={state.cards}
            currentCardId={state.currentAuction.cardId}
            initialEditingCardId={editingCardId}
            onClearInitialEditingCard={() => setEditingCardId(null)}
          />
        )}

        {activeTab === 'sales' && (
          <SalesRegister sales={state.salesRegister} />
        )}

        {activeTab === 'standings' && (
          <TeamStandings teams={state.teams} />
        )}

        {activeTab === 'bids' && (
          <BidHistoryView bids={state.bidHistory} />
        )}

        {activeTab === 'audit' && (
          <AuditLogView logs={state.auditLogs} />
        )}
      </main>

      {/* Reset Auction Confirmation Modal */}
      <ResetAuctionModal
        isOpen={isResetModalOpen}
        onClose={() => setIsResetModalOpen(false)}
        onSuccess={handleResetSuccess}
      />
    </div>
  );
};
