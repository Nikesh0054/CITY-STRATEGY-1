/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Team } from '../types/auction';
import { formatRupees, formatRupeesWords } from '../utils/formatters';
import { auctionStore } from '../services/auctionStore';
import {
  UserPlus,
  Key,
  Edit2,
  Trash2,
  Archive,
  Copy,
  Check,
  Search,
  AlertTriangle,
  X,
  ShieldAlert,
} from 'lucide-react';

interface TeamsManagementProps {
  teams: Team[];
}

export const TeamsManagement: React.FC<TeamsManagementProps> = ({ teams }) => {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamNotes, setNewTeamNotes] = useState('');
  const [createdCredential, setCreatedCredential] = useState<{
    teamName: string;
    loginId: string;
    password?: string;
  } | null>(null);

  const [editingTeam, setEditingTeam] = useState<Team | null>(null);
  const [editNotes, setEditNotes] = useState('');

  const [teamToDelete, setTeamToDelete] = useState<Team | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const copyToClipboard = (text: string, keyId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(keyId);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleAddTeam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamName.trim()) return;

    const res = auctionStore.addTeam({
      name: newTeamName.trim(),
      notes: newTeamNotes.trim(),
    });

    if (res.success && res.team) {
      setCreatedCredential({
        teamName: res.team.name,
        loginId: res.team.loginId,
        password: res.plainPassword,
      });
      setIsAddModalOpen(false);
      setNewTeamName('');
      setNewTeamNotes('');
      setStatusMessage({
        type: 'success',
        message: `Team "${res.team.name}" created successfully.`,
      });
    } else {
      setStatusMessage({
        type: 'error',
        message: res.error || 'Failed to create team',
      });
    }
  };

  const handleEditSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTeam) return;

    const res = auctionStore.editTeam(editingTeam.id, {
      notes: editNotes,
    });

    if (res.success) {
      setStatusMessage({
        type: 'success',
        message: `Team "${editingTeam.name}" updated successfully.`,
      });
      setEditingTeam(null);
    } else {
      setStatusMessage({
        type: 'error',
        message: res.error || 'Failed to update team',
      });
    }
  };

  const handleConfirmDeleteOrArchive = () => {
    if (!teamToDelete) return;

    const res = auctionStore.deleteOrArchiveTeam(teamToDelete.id);
    if (res.success) {
      setStatusMessage({
        type: 'success',
        message: res.action === 'ARCHIVED'
          ? `Team "${teamToDelete.name}" was safely ARCHIVED to preserve historical bid/purchase records.`
          : `Team "${teamToDelete.name}" was successfully deleted.`,
      });
      setTeamToDelete(null);
    } else {
      setStatusMessage({
        type: 'error',
        message: res.error || 'Operation failed',
      });
    }
  };

  const handleResetPassword = (team: Team) => {
    const res = auctionStore.resetTeamPassword(team.id);
    if (res.success && res.newPassword) {
      setCreatedCredential({
        teamName: team.name,
        loginId: team.loginId,
        password: res.newPassword,
      });
      setStatusMessage({
        type: 'success',
        message: `New password generated for ${team.name}.`,
      });
    }
  };

  const filteredTeams = teams.filter((t) =>
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.loginId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#11141b] border border-[#212734] rounded-2xl p-5 shadow-lg">
        <div className="flex items-center gap-4 flex-1 max-w-md">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-[#64748b] absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search teams by name or ID..."
              className="w-full bg-[#161a22] border border-[#283140] text-sm text-white pl-10 pr-4 py-2 rounded-xl placeholder:text-[#4b5563] outline-none focus:border-[#d4af37]"
            />
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#d4af37] hover:bg-[#e4be45] text-[#0a0c10] font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>ADD TEAM</span>
          </button>
        </div>
      </div>

      {/* Status banner */}
      {statusMessage && (
        <div
          className={`p-4 rounded-xl text-xs font-semibold flex items-center justify-between ${
            statusMessage.type === 'success'
              ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-500/30'
              : 'bg-rose-950/40 text-rose-300 border border-rose-500/30'
          }`}
        >
          <span>{statusMessage.message}</span>
          <button onClick={() => setStatusMessage(null)}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Credential Generated Modal (One-Time Credential Workflow) */}
      {createdCredential && (
        <div className="bg-[#131822] border-2 border-[#d4af37] rounded-2xl p-6 shadow-2xl space-y-4 animate-fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-[#d4af37]">
              <Key className="w-5 h-5" />
              <h4 className="font-display font-bold text-base uppercase tracking-wider">
                One-Time Credential Issued
              </h4>
            </div>
            <button
              onClick={() => setCreatedCredential(null)}
              className="text-[#64748b] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-xs text-[#94a3b8]">
            Copy these credentials securely and provide them to the team representative. Passwords are never exposed publicly.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#0d1016] p-4 rounded-xl border border-[#222938]">
            <div>
              <p className="text-[10px] font-bold uppercase text-[#64748b]">Login ID (Exact)</p>
              <p className="font-mono text-base font-bold text-white mt-0.5">
                {createdCredential.loginId}
              </p>
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase text-[#64748b]">Assigned Password</p>
              <div className="flex items-center justify-between mt-0.5">
                <p className="font-mono text-base font-bold text-emerald-400">
                  {createdCredential.password}
                </p>
                <button
                  onClick={() =>
                    copyToClipboard(
                      `Team: ${createdCredential.teamName}\nLogin ID: ${createdCredential.loginId}\nPassword: ${createdCredential.password}`,
                      'cred-all'
                    )
                  }
                  className="px-2.5 py-1 rounded bg-[#1c222e] hover:bg-[#283243] text-xs text-[#d4af37] flex items-center gap-1 font-medium border border-[#2b3547]"
                >
                  {copiedKey === 'cred-all' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'cred-all' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Teams Table */}
      <div className="bg-[#101319] border border-[#212733] rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#141821] border-b border-[#212733] text-[#8e95a2] uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3.5 px-4">Team Name</th>
                <th className="py-3.5 px-4">Login ID</th>
                <th className="py-3.5 px-4">Registered Google Email</th>
                <th className="py-3.5 px-4">Initial Budget</th>
                <th className="py-3.5 px-4">Total Spent</th>
                <th className="py-3.5 px-4">Remaining Budget</th>
                <th className="py-3.5 px-4">Acquired</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b212b]">
              {filteredTeams.map((team) => (
                <tr key={team.id} className="hover:bg-[#151922] transition-colors">
                  <td className="py-3.5 px-4 font-display font-bold text-white">
                    {team.name}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-[#9ca3af]">
                    {team.loginId}
                  </td>
                  <td className="py-3.5 px-4">
                    {team.registeredEmail ? (
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-xs text-white truncate max-w-[150px]">
                          {team.registeredEmail}
                        </span>
                        {team.emailVerified ? (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                            Verified
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                            Pending
                          </span>
                        )}
                      </div>
                    ) : (
                      <span className="text-[11px] text-[#64748b] italic">
                        Not linked
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 font-mono-val text-slate-300">
                    {formatRupeesWords(team.initialBudget)}
                  </td>
                  <td className="py-3.5 px-4 font-mono-val text-amber-400">
                    {formatRupeesWords(team.totalSpent)}
                  </td>
                  <td className="py-3.5 px-4 font-mono-val font-bold text-emerald-400">
                    {formatRupeesWords(team.remainingBudget)}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded font-mono font-medium bg-[#1a202b] text-[#9ca3af]">
                      {team.acquiredCards.length}/4
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    {team.isArchived ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-500/15 text-rose-400 border border-rose-500/30">
                        ARCHIVED
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                        ACTIVE
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right space-x-1">
                    <button
                      onClick={() => handleResetPassword(team)}
                      className="p-1.5 rounded hover:bg-[#202734] text-[#9ca3af] hover:text-[#d4af37]"
                      title="Reset Team Password"
                    >
                      <Key className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        setEditingTeam(team);
                        setEditNotes(team.notes || '');
                      }}
                      className="p-1.5 rounded hover:bg-[#202734] text-[#9ca3af] hover:text-white"
                      title="Edit Notes"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setTeamToDelete(team)}
                      className="p-1.5 rounded hover:bg-[#202734] text-[#9ca3af] hover:text-rose-400"
                      title="Delete / Archive Team"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Team Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12161f] border border-[#263042] rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl animate-fade-in">
            <div className="flex items-center justify-between pb-4 border-b border-[#212836]">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-[#d4af37]" />
                <h3 className="font-display font-bold text-lg text-white">Create New Team</h3>
              </div>
              <button onClick={() => setIsAddModalOpen(false)} className="text-[#64748b] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddTeam} className="mt-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                  Team Name (e.g., TEAM 31)
                </label>
                <input
                  type="text"
                  value={newTeamName}
                  onChange={(e) => setNewTeamName(e.target.value)}
                  placeholder="TEAM 31"
                  className="w-full bg-[#171b24] border border-[#2b3547] text-white px-3.5 py-2.5 rounded-xl text-sm outline-none focus:border-[#d4af37] uppercase font-bold"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                  Notes / Organization (Optional)
                </label>
                <textarea
                  value={newTeamNotes}
                  onChange={(e) => setNewTeamNotes(e.target.value)}
                  placeholder="Participant notes, contact details..."
                  className="w-full bg-[#171b24] border border-[#2b3547] text-white px-3.5 py-2 rounded-xl text-xs outline-none focus:border-[#d4af37] resize-none h-20"
                />
              </div>

              <div className="p-3 bg-[#171c26] rounded-xl text-[11px] text-[#8e95a2] space-y-1">
                <p>• Initial budget: ₹10.00 Crore (Standard)</p>
                <p>• A secure individual password will be generated automatically upon creation.</p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-[#8e95a2] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#d4af37] hover:bg-[#e6bf47] text-[#0a0c10] font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer"
                >
                  Create Team
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Team Modal */}
      {editingTeam && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12161f] border border-[#263042] rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl animate-fade-in">
            <div className="flex items-center justify-between pb-4 border-b border-[#212836]">
              <h3 className="font-display font-bold text-lg text-white">Edit {editingTeam.name}</h3>
              <button onClick={() => setEditingTeam(null)} className="text-[#64748b] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditSave} className="mt-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                  Notes
                </label>
                <textarea
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full bg-[#171b24] border border-[#2b3547] text-white px-3.5 py-2.5 rounded-xl text-xs outline-none focus:border-[#d4af37] resize-none h-24"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setEditingTeam(null)}
                  className="px-4 py-2 text-xs font-semibold text-[#8e95a2] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#d4af37] text-[#0a0c10] font-bold text-xs uppercase tracking-wider rounded-xl shadow-md cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete / Archive Confirmation Modal */}
      {teamToDelete && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12161f] border border-rose-500/40 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl animate-fade-in">
            <div className="flex items-center gap-3 text-rose-400 pb-3 border-b border-[#262c38]">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="font-display font-bold text-lg text-white">
                Delete or Archive {teamToDelete.name}
              </h3>
            </div>

            <p className="text-xs text-[#9ca3af] mt-4 leading-relaxed">
              If this team has participated in any bids or won cards, it will be <strong>safely archived</strong> rather than permanently deleted. This preserves the financial integrity and audit trail of the event.
            </p>

            <div className="flex items-center justify-end gap-3 pt-6">
              <button
                type="button"
                onClick={() => setTeamToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-[#8e95a2] hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteOrArchive}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer"
              >
                Confirm Action
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
