/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, Users, Radio, ExternalLink, LogOut, Layers } from 'lucide-react';

interface HeaderProps {
  currentRole?: 'admin' | 'team' | 'guest';
  teamName?: string;
  onLogout?: () => void;
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  teamName,
  onLogout,
  activeTab,
  onTabChange,
}) => {
  return (
    <header className="border-b border-[#22262e] bg-[#0e1115]/90 backdrop-blur-md sticky top-0 z-40 px-4 lg:px-8 py-3.5 flex items-center justify-between">
      {/* Title (NO CSC BRANDING OR LOGOS) */}
      <div className="flex items-center gap-3">
        <div className="w-2.5 h-2.5 rounded-full bg-[#d4af37] shadow-[0_0_8px_rgba(212,175,55,0.6)] animate-pulse" />
        <div>
          <a href="/" className="group flex items-center gap-2">
            <h1 className="font-display tracking-widest text-lg md:text-xl font-bold text-white group-hover:text-[#d4af37] transition-colors">
              THE CITY STRATEGY CHALLENGE
            </h1>
          </a>
          <p className="text-[11px] text-[#8e95a2] tracking-wider uppercase">
            Official Municipal Strategy & Infrastructure Auction
          </p>
        </div>
      </div>

      {/* Navigation / Portals */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Quick Links for Multi-Tab Access */}
        <a
          href="/?view=projector"
          target="_blank"
          rel="noopener noreferrer"
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#9ca3af] hover:text-[#d4af37] bg-[#161a20] hover:bg-[#1f242d] border border-[#2a303c] rounded-md transition-all shadow-sm"
          title="Open Projector Display in new tab"
        >
          <Radio className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Projector</span>
          <ExternalLink className="w-3 h-3 opacity-60" />
        </a>

        <a
          href="/bid-panel"
          target="_blank"
          rel="noopener noreferrer"
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#9ca3af] hover:text-[#d4af37] bg-[#161a20] hover:bg-[#1f242d] border border-[#2a303c] rounded-md transition-all shadow-sm"
          title="Open Floor Bid Panel in new tab"
        >
          <Users className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Open Bid Panel</span>
          <ExternalLink className="w-3 h-3 opacity-60" />
        </a>

        {/* Role indicator & Logout */}
        {currentRole === 'admin' && (
          <div className="flex items-center gap-2 pl-2 border-l border-[#262b35]">
            <button
              onClick={() => {
                if (onTabChange) {
                  onTabChange('cards');
                } else {
                  window.location.href = '/admin?tab=cards';
                }
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-[#d4af37] bg-[#d4af37]/15 hover:bg-[#d4af37]/25 border border-[#d4af37]/40 rounded-lg transition-all shadow-sm cursor-pointer uppercase tracking-wider"
              title="Open Card Bank Management (120 Cards)"
            >
              <Layers className="w-3.5 h-3.5" />
              <span className="hidden md:inline">CARD BANK MANAGEMENT</span>
              <span className="md:hidden">CARDS</span>
            </button>

            <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-[#d4af37]/15 text-[#d4af37] border border-[#d4af37]/30 rounded">
              <Shield className="w-3 h-3" />
              ADMIN
            </span>
            {onLogout && (
              <button
                onClick={onLogout}
                className="p-1.5 text-[#9ca3af] hover:text-rose-400 hover:bg-[#1f242d] rounded transition-colors cursor-pointer"
                title="Log out of Admin Portal"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        {currentRole === 'team' && teamName && (
          <div className="flex items-center gap-2 pl-2 border-l border-[#262b35]">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 rounded">
              <Users className="w-3 h-3" />
              {teamName}
            </span>
            {onLogout && (
              <button
                onClick={onLogout}
                className="p-1.5 text-[#9ca3af] hover:text-rose-400 hover:bg-[#1f242d] rounded transition-colors"
                title="Log out of Team Portal"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        {currentRole === 'guest' && (
          <div className="flex items-center gap-2">
            <a
              href="/team-login"
              className="px-3 py-1.5 text-xs font-medium text-[#d1d5db] hover:text-white bg-[#1a1f26] hover:bg-[#252c37] border border-[#2e3644] rounded-md transition-colors"
            >
              Team Login
            </a>
            <a
              href="/admin-login"
              className="px-3 py-1.5 text-xs font-medium text-[#d4af37] hover:text-[#f4d068] bg-[#d4af37]/10 hover:bg-[#d4af37]/20 border border-[#d4af37]/30 rounded-md transition-colors"
            >
              Admin Login
            </a>
          </div>
        )}
      </div>
    </header>
  );
};
