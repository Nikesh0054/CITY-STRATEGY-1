/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Shield, Lock, User, AlertCircle, ArrowRight } from 'lucide-react';

interface AdminLoginProps {
  onLoginSuccess: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    const u = username.trim().toUpperCase();

    // Authenticate admin
    if (u === 'ALLIANCEONE2026' && password === 'ANEKAL2026') {
      setIsLoading(false);
      onLoginSuccess();
    } else {
      setIsLoading(false);
      setError('Invalid administrator credentials. Access restricted.');
    }
  };

  return (
    <div className="min-h-screen bg-[#08090c] text-slate-100 flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#d4af37]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md bg-[#101318] border border-[#222833] rounded-3xl p-8 sm:p-10 shadow-2xl relative z-10">
        {/* Title & Branding (NO CSC BRANDING) */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-[#181d26] border border-[#2b3342] text-[#d4af37] mb-4">
            <Shield className="w-6 h-6" />
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-wider text-white">
            THE CITY STRATEGY CHALLENGE
          </h1>
          <p className="text-xs uppercase tracking-widest text-[#8e95a2] mt-1.5 font-medium">
            Administrator Portal Access
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5 animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-2">
              Administrator Username
            </label>
            <div className="relative">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="ALLIANCEONE2026"
                className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] text-white px-4 py-3 rounded-xl text-sm font-medium tracking-wide placeholder:text-[#4b5563] outline-none transition-all uppercase"
                autoFocus
              />
              <User className="w-4 h-4 text-[#64748b] absolute right-3.5 top-3.5" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-2">
              Password
            </label>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] text-white px-4 py-3 rounded-xl text-sm font-medium placeholder:text-[#4b5563] outline-none transition-all"
              />
              <Lock className="w-4 h-4 text-[#64748b] absolute right-3.5 top-3.5" />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 px-4 bg-gradient-to-r from-[#c89b3c] to-[#e6bd54] hover:from-[#d4af37] hover:to-[#f3c85f] active:scale-[0.99] text-[#0a0c10] font-bold text-sm tracking-wider uppercase rounded-xl transition-all shadow-lg shadow-[#d4af37]/15 flex items-center justify-center gap-2 cursor-pointer mt-2"
          >
            <span>{isLoading ? 'Verifying...' : 'Access Admin Dashboard'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-[#1e2430] text-center">
          <a
            href="/team-login"
            className="text-xs text-[#8e95a2] hover:text-[#d4af37] transition-colors"
          >
            Looking for Team Login? Go to Team Portal →
          </a>
        </div>
      </div>
    </div>
  );
};
