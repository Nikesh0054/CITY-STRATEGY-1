/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuditLogItem } from '../types/auction';
import { formatDateTime } from '../utils/formatters';
import { auctionStore } from '../services/auctionStore';
import { ShieldAlert, RotateCcw, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface AuditLogViewProps {
  logs: AuditLogItem[];
}

export const AuditLogView: React.FC<AuditLogViewProps> = ({ logs }) => {
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [resetConfirmationText, setResetConfirmationText] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleConfirmReset = () => {
    if (resetConfirmationText !== 'RESET EVENT') return;

    auctionStore.resetEvent();
    setIsResetModalOpen(false);
    setResetConfirmationText('');
    setFeedback('Event successfully reset to baseline. Initial budgets and cards restored.');
    setTimeout(() => setFeedback(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#11141b] border border-[#212734] rounded-2xl p-5 shadow-lg">
        <div>
          <h3 className="font-display font-bold text-base text-white">Immutable Event Audit Trail</h3>
          <p className="text-xs text-[#8e95a2] mt-0.5">
            System actions, bids, timer events, sales, and reversals logged chronologically
          </p>
        </div>

        <button
          onClick={() => setIsResetModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/40 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Reset Event</span>
        </button>
      </div>

      {feedback && (
        <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center gap-2.5">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Audit Log Table */}
      <div className="bg-[#101319] border border-[#212733] rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#141821] border-b border-[#212733] text-[#8e95a2] uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3.5 px-4">Action</th>
                <th className="py-3.5 px-4">Details</th>
                <th className="py-3.5 px-4">Actor</th>
                <th className="py-3.5 px-4">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b212b]">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-[#151922] transition-colors">
                  <td className="py-3 px-4 font-mono font-bold">
                    <span className={`px-2 py-0.5 rounded text-[10px] ${
                      log.action.includes('SALE')
                        ? 'bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/30'
                        : log.action.includes('BID')
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : log.action.includes('UNDO') || log.action.includes('RESET')
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        : 'bg-[#181e28] text-[#9ca3af]'
                    }`}>
                      {log.action}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-white font-medium">
                    {log.details}
                  </td>
                  <td className="py-3 px-4 text-[#8e95a2] font-mono text-[11px]">
                    {log.actor}
                  </td>
                  <td className="py-3 px-4 font-mono text-[#64748b] text-[11px]">
                    {formatDateTime(log.timestamp)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reset Modal with strict confirmation input */}
      {isResetModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12161f] border-2 border-rose-500 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-5 animate-fade-in">
            <div className="flex items-center gap-3 text-rose-400 pb-3 border-b border-[#242c3b]">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="font-display font-extrabold text-xl text-white">
                Emergency Event Reset
              </h3>
            </div>

            <p className="text-xs text-[#9ca3af] leading-relaxed">
              WARNING: This will reset all 30 teams back to ₹10 Crore, clear all acquired card portfolios, clear current bid states, and restore all 120 cards to AVAILABLE.
            </p>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                Type <span className="text-rose-400 font-mono font-bold">RESET EVENT</span> to confirm:
              </label>
              <input
                type="text"
                value={resetConfirmationText}
                onChange={(e) => setResetConfirmationText(e.target.value)}
                placeholder="RESET EVENT"
                className="w-full bg-[#161a22] border border-rose-500/50 text-white font-mono text-sm px-4 py-2.5 rounded-xl outline-none focus:border-rose-400"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={() => {
                  setIsResetModalOpen(false);
                  setResetConfirmationText('');
                }}
                className="px-4 py-2 text-xs font-semibold text-[#8e95a2] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={resetConfirmationText !== 'RESET EVENT'}
                onClick={handleConfirmReset}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all cursor-pointer"
              >
                Reset Event
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
