/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Lock,
  User,
  AlertCircle,
  ArrowRight,
  Mail,
  KeyRound,
  CheckCircle2,
  X,
  ShieldCheck,
  ShieldAlert,
  HelpCircle,
} from 'lucide-react';
import { Team } from '../types/auction';
import { auctionStore } from '../services/auctionStore';

interface TeamLoginProps {
  teams: Team[];
  onLoginSuccess: (team: Team) => void;
}

export const TeamLogin: React.FC<TeamLoginProps> = ({ teams, onLoginSuccess }) => {
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [successBanner, setSuccessBanner] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Forgot Password Modal State
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [forgotStep, setForgotStep] = useState<1 | 2>(1);
  const [forgotLoginId, setForgotLoginId] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotResetToken, setForgotResetToken] = useState('');
  const [forgotNewPassword, setForgotNewPassword] = useState('');
  const [forgotConfirmPassword, setForgotConfirmPassword] = useState('');
  const [forgotError, setForgotError] = useState<string | null>(null);
  const [forgotSuccess, setForgotSuccess] = useState<string | null>(null);
  const [forgotLoading, setForgotLoading] = useState(false);

  // Account Setup (Email Linking) Modal State
  const [isSetupModalOpen, setIsSetupModalOpen] = useState(false);
  const [setupStep, setSetupStep] = useState<1 | 2>(1);
  const [setupTeamId, setSetupTeamId] = useState('');
  const [setupPassword, setSetupPassword] = useState('');
  const [setupEmail, setSetupEmail] = useState('');
  const [setupCode, setSetupCode] = useState('');
  const [setupError, setSetupError] = useState<string | null>(null);
  const [setupSuccess, setSetupSuccess] = useState<string | null>(null);
  const [setupLoading, setSetupLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessBanner(null);
    setIsLoading(true);

    const rawId = (loginId || '').trim().toUpperCase();
    const cleanId = rawId.replace(/\s+/g, '');
    const cleanPassword = String(password ?? '').trim();

    if (!cleanId) {
      setError('Please enter your Team User ID (e.g., TEAM1).');
      setIsLoading(false);
      return;
    }

    if (!cleanPassword) {
      setError('Please enter your password.');
      setIsLoading(false);
      return;
    }

    // Attempt authoritative backend authentication first
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          loginId: cleanId,
          password: cleanPassword,
          portal: 'team',
        }),
      });
      const data = await response.json();
      if (response.ok && data.success && data.user) {
        const teamObj = teams.find((t) => t.id === data.user.teamId) || {
          id: data.user.teamId,
          name: data.user.name,
          loginId: data.user.loginId,
          plainPassword: cleanPassword,
          initialBudget: 100000000,
          totalSpent: 0,
          remainingBudget: 100000000,
          acquiredCards: [],
          categoryProgress: { STAKEHOLDER: false, CHALLENGE: false, CONSTRAINT: false, IMPACT: false },
          isArchived: false,
          createdAt: Date.now(),
        };
        setIsLoading(false);
        onLoginSuccess(teamObj as Team);
        return;
      } else if (response.status === 403) {
        setError(data.error || 'This team account has been archived.');
        setIsLoading(false);
        return;
      } else if (response.status === 401) {
        setError(data.error || 'Incorrect password. If you changed your password, please use your new custom password or use Forgot Password.');
        setIsLoading(false);
        return;
      }
    } catch {
      // Fallback to local store validation if backend network is unreachable
    }

    // Authenticate against teams in store
    const team = teams.find((t) => {
      const tLoginClean = (t.loginId || '').replace(/\s+/g, '').toUpperCase();
      const tNameClean = (t.name || '').replace(/\s+/g, '').toUpperCase();
      return tLoginClean === cleanId || tNameClean === cleanId;
    });

    if (!team) {
      setError('Team User ID not recognized. Please verify your team ID (e.g., TEAM1 through TEAM30).');
      setIsLoading(false);
      return;
    }

    if (team.isArchived) {
      setError('This team account has been archived.');
      setIsLoading(false);
      return;
    }

    // Check password strictly as string to preserve leading zeros
    if (String(team.plainPassword || '') !== cleanPassword) {
      setError('Incorrect password. If you set a custom password, please use it.');
      setIsLoading(false);
      return;
    }

    // Success
    setIsLoading(false);
    onLoginSuccess(team);
  };

  // --- FORGOT PASSWORD HANDLERS ---
  const handleForgotRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    setForgotSuccess(null);
    setForgotLoading(true);

    const cleanId = forgotLoginId.trim().toUpperCase().replace(/\s+/g, '');
    const cleanMail = forgotEmail.trim().toLowerCase();

    if (!cleanId || !cleanMail) {
      setForgotError('Please enter both your Team ID and registered Google email address.');
      setForgotLoading(false);
      return;
    }

    const res = await auctionStore.forgotPassword({
      loginId: cleanId,
      email: cleanMail,
    });

    setForgotLoading(false);

    if (res.success) {
      setForgotSuccess(res.message || 'Verification token dispatched.');
      if (res.resetToken) {
        setForgotResetToken(res.resetToken);
      }
      setForgotStep(2);
    } else {
      setForgotError(res.error || 'Unable to initiate password reset.');
    }
  };

  const handleForgotReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    setForgotSuccess(null);

    const cleanId = forgotLoginId.trim().toUpperCase().replace(/\s+/g, '');

    if (!forgotResetToken.trim()) {
      setForgotError('Password reset token is required.');
      return;
    }

    if (forgotNewPassword.length < 5) {
      setForgotError('New password must be at least 5 characters long.');
      return;
    }

    if (forgotNewPassword !== forgotConfirmPassword) {
      setForgotError('Passwords do not match. Please verify.');
      return;
    }

    setForgotLoading(true);

    const res = await auctionStore.resetPasswordWithToken({
      loginId: cleanId,
      resetToken: forgotResetToken.trim(),
      newPassword: forgotNewPassword,
    });

    setForgotLoading(false);

    if (res.success) {
      setIsForgotModalOpen(false);
      setSuccessBanner('Your password has been successfully reset! Please sign in with your new custom password.');
      setLoginId(forgotLoginId.trim().toUpperCase());
      setPassword(forgotNewPassword);
      // Reset forgot state
      setForgotStep(1);
      setForgotEmail('');
      setForgotResetToken('');
      setForgotNewPassword('');
      setForgotConfirmPassword('');
    } else {
      setForgotError(res.error || 'Password reset failed.');
    }
  };

  // --- ACCOUNT SETUP (LINK EMAIL) HANDLERS ---
  const handleSetupRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setSetupError(null);
    setSetupSuccess(null);

    const cleanId = setupTeamId.trim().toUpperCase().replace(/\s+/g, '');
    const team = teams.find((t) => {
      const tLogin = (t.loginId || '').replace(/\s+/g, '').toUpperCase();
      return tLogin === cleanId;
    });

    if (!team) {
      setSetupError('Team ID not recognized (e.g. TEAM1 through TEAM30).');
      return;
    }

    setSetupLoading(true);

    const res = await auctionStore.registerTeamEmail({
      teamId: team.id,
      email: setupEmail.trim().toLowerCase(),
      currentPassword: setupPassword,
    });

    setSetupLoading(false);

    if (res.success) {
      setSetupSuccess(res.message || 'Verification code sent to your Google email.');
      if (res.verificationCodeForDev) {
        setSetupCode(res.verificationCodeForDev);
      }
      setSetupStep(2);
    } else {
      setSetupError(res.error || 'Failed to register email.');
    }
  };

  const handleSetupVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setSetupError(null);
    setSetupSuccess(null);

    const cleanId = setupTeamId.trim().toUpperCase().replace(/\s+/g, '');
    const team = teams.find((t) => {
      const tLogin = (t.loginId || '').replace(/\s+/g, '').toUpperCase();
      return tLogin === cleanId;
    });

    if (!team) {
      setSetupError('Team ID not recognized.');
      return;
    }

    if (!setupCode.trim()) {
      setSetupError('Please enter the 6-digit verification code.');
      return;
    }

    setSetupLoading(true);

    const res = await auctionStore.verifyTeamEmail({
      teamId: team.id,
      code: setupCode.trim(),
    });

    setSetupLoading(false);

    if (res.success) {
      setIsSetupModalOpen(false);
      setSuccessBanner(`Google email ${setupEmail} successfully verified and linked to ${team.name}!`);
      setLoginId(setupTeamId.trim().toUpperCase());
      // Reset setup state
      setSetupStep(1);
      setSetupEmail('');
      setSetupPassword('');
      setSetupCode('');
    } else {
      setSetupError(res.error || 'Verification failed.');
    }
  };

  return (
    <div className="min-h-screen bg-[#08090c] text-slate-100 flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#d4af37]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md bg-[#101318] border border-[#222833] rounded-3xl p-8 sm:p-10 shadow-2xl relative z-10">
        {/* Title & Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-[#181d26] border border-[#2b3342] text-[#d4af37] mb-4">
            <User className="w-6 h-6" />
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-wider text-white">
            THE CITY STRATEGY CHALLENGE
          </h1>
          <p className="text-xs uppercase tracking-widest text-[#8e95a2] mt-1.5 font-medium">
            Team Participant Portal
          </p>
        </div>

        {/* Global Notifications */}
        {successBanner && (
          <div className="mb-5 p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2.5 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successBanner}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5 animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-2">
              Team User ID
            </label>
            <div className="relative">
              <input
                type="text"
                value={loginId}
                onChange={(e) => setLoginId(e.target.value)}
                placeholder="e.g. TEAM1"
                className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] text-white px-4 py-3 rounded-xl text-sm font-medium tracking-wide placeholder:text-[#4b5563] outline-none transition-all uppercase"
                autoFocus
              />
              <span className="absolute right-3.5 top-3.5 text-xs font-mono text-[#64748b]">
                EXACT ID
              </span>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-[#9ca3af]">
                Password
              </label>
              <button
                type="button"
                onClick={() => {
                  setIsForgotModalOpen(true);
                  setForgotLoginId(loginId);
                  setForgotError(null);
                  setForgotSuccess(null);
                  setForgotStep(1);
                }}
                className="text-xs text-[#d4af37] hover:underline cursor-pointer"
              >
                Forgot Password?
              </button>
            </div>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter team password"
                className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] text-white px-4 py-3 rounded-xl text-sm font-medium placeholder:text-[#4b5563] outline-none transition-all"
              />
              <Lock className="w-4 h-4 text-[#64748b] absolute right-3.5 top-3.5" />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 px-4 bg-gradient-to-r from-[#c89b3c] to-[#e6bd54] hover:from-[#d4af37] hover:to-[#f3c85f] active:scale-[0.99] text-[#0a0c10] font-bold text-sm tracking-wider uppercase rounded-xl transition-all shadow-lg shadow-[#d4af37]/15 flex items-center justify-center gap-2 cursor-pointer mt-2"
          >
            <span>{isLoading ? 'Authenticating...' : 'Sign In to Team Dashboard'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Account Setup Link */}
        <div className="mt-5 pt-4 border-t border-[#1e2430] flex flex-col items-center gap-2 text-center">
          <button
            type="button"
            onClick={() => {
              setIsSetupModalOpen(true);
              setSetupTeamId(loginId);
              setSetupError(null);
              setSetupSuccess(null);
              setSetupStep(1);
            }}
            className="text-xs text-[#d4af37] hover:underline flex items-center gap-1.5 cursor-pointer font-medium"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Account Setup: Link Verified Google Email</span>
          </button>

          <a
            href="/admin-login"
            className="text-xs text-[#8e95a2] hover:text-[#d4af37] transition-colors mt-2"
          >
            Are you an event administrator? Go to Admin Login →
          </a>
        </div>
      </div>

      {/* --- FORGOT PASSWORD MODAL --- */}
      {isForgotModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#10141b] border border-[#283244] rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl space-y-6 relative animate-fadeIn">
            <div className="flex items-center justify-between pb-4 border-b border-[#1f2635]">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#d4af37]/15 border border-[#d4af37]/30 text-[#d4af37]">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-white">
                    Password Recovery
                  </h3>
                  <p className="text-xs text-[#8e95a2]">
                    {forgotStep === 1 ? 'Step 1 of 2: Verify Identity' : 'Step 2 of 2: Set New Password'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsForgotModalOpen(false)}
                className="p-1.5 rounded-lg text-[#64748b] hover:text-white hover:bg-[#181d26] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {forgotError && (
              <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{forgotError}</span>
              </div>
            )}

            {forgotSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{forgotSuccess}</span>
              </div>
            )}

            {forgotStep === 1 ? (
              <form onSubmit={handleForgotRequest} className="space-y-4">
                <div className="text-xs text-[#94a3b8] leading-relaxed">
                  Enter your assigned Team ID and the verified Google email address associated with your team account.
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Team User ID
                  </label>
                  <input
                    type="text"
                    value={forgotLoginId}
                    onChange={(e) => setForgotLoginId(e.target.value)}
                    placeholder="e.g. TEAM1"
                    required
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs uppercase font-mono outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Registered Google Email Address
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="team@gmail.com"
                      required
                      className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs outline-none"
                    />
                    <Mail className="w-4 h-4 text-[#64748b] absolute right-3 top-2.5" />
                  </div>
                </div>

                <div className="bg-[#141822] border border-[#222a38] rounded-xl p-3 text-[11px] text-[#8e95a2] flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#d4af37] shrink-0" />
                  <span>Security rule: Password recovery is strictly restricted to accounts with a registered and verified Google email address.</span>
                </div>

                <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#1f2635]">
                  <button
                    type="button"
                    onClick={() => setIsForgotModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-[#2a3344] text-[#9ca3af] hover:text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="px-5 py-2 rounded-xl bg-[#d4af37] hover:bg-[#e4be42] text-[#0a0c10] text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    {forgotLoading ? 'Dispatched...' : 'Send Reset Token'}
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleForgotReset} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Reset Token / Code
                  </label>
                  <input
                    type="text"
                    value={forgotResetToken}
                    onChange={(e) => setForgotResetToken(e.target.value)}
                    placeholder="Enter reset token from email"
                    required
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs font-mono outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    New Custom Password
                  </label>
                  <input
                    type="password"
                    value={forgotNewPassword}
                    onChange={(e) => setForgotNewPassword(e.target.value)}
                    placeholder="At least 5 characters"
                    required
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    value={forgotConfirmPassword}
                    onChange={(e) => setForgotConfirmPassword(e.target.value)}
                    placeholder="Re-enter new password"
                    required
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs outline-none"
                  />
                </div>

                <div className="pt-2 flex items-center justify-between border-t border-[#1f2635]">
                  <button
                    type="button"
                    onClick={() => setForgotStep(1)}
                    className="text-xs text-[#8e95a2] hover:text-white"
                  >
                    ← Back
                  </button>

                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    {forgotLoading ? 'Updating...' : 'Set New Password'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* --- ACCOUNT SETUP / LINK EMAIL MODAL --- */}
      {isSetupModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#10141b] border border-[#283244] rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl space-y-6 relative animate-fadeIn">
            <div className="flex items-center justify-between pb-4 border-b border-[#1f2635]">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#d4af37]/15 border border-[#d4af37]/30 text-[#d4af37]">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-white">
                    Link Verified Google Email
                  </h3>
                  <p className="text-xs text-[#8e95a2]">
                    {setupStep === 1 ? 'Step 1: Register Email' : 'Step 2: Enter Verification Code'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsSetupModalOpen(false)}
                className="p-1.5 rounded-lg text-[#64748b] hover:text-white hover:bg-[#181d26] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {setupError && (
              <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{setupError}</span>
              </div>
            )}

            {setupSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{setupSuccess}</span>
              </div>
            )}

            {setupStep === 1 ? (
              <form onSubmit={handleSetupRegister} className="space-y-4">
                <div className="text-xs text-[#94a3b8] leading-relaxed">
                  Link an official Google email address to your team account to enable custom passwords and self-service password recovery.
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Team User ID
                  </label>
                  <input
                    type="text"
                    value={setupTeamId}
                    onChange={(e) => setSetupTeamId(e.target.value)}
                    placeholder="e.g. TEAM1"
                    required
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs uppercase font-mono outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Current Password
                  </label>
                  <input
                    type="password"
                    value={setupPassword}
                    onChange={(e) => setSetupPassword(e.target.value)}
                    placeholder="Assigned password (e.g. 00001)"
                    required
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Official Google Email Address
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      value={setupEmail}
                      onChange={(e) => setSetupEmail(e.target.value)}
                      placeholder="team-member@gmail.com"
                      required
                      className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs outline-none"
                    />
                    <Mail className="w-4 h-4 text-[#64748b] absolute right-3 top-2.5" />
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#1f2635]">
                  <button
                    type="button"
                    onClick={() => setIsSetupModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-[#2a3344] text-[#9ca3af] hover:text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={setupLoading}
                    className="px-5 py-2 rounded-xl bg-[#d4af37] hover:bg-[#e4be42] text-[#0a0c10] text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    {setupLoading ? 'Sending...' : 'Send Verification Code'}
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleSetupVerify} className="space-y-4">
                <div className="text-xs text-[#94a3b8] leading-relaxed">
                  Enter the 6-digit verification code sent to <strong className="text-white">{setupEmail}</strong>.
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    6-Digit Verification Code
                  </label>
                  <input
                    type="text"
                    value={setupCode}
                    onChange={(e) => setSetupCode(e.target.value)}
                    placeholder="e.g. 123456"
                    required
                    maxLength={6}
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-center text-lg font-mono tracking-widest outline-none"
                  />
                </div>

                <div className="pt-2 flex items-center justify-between border-t border-[#1f2635]">
                  <button
                    type="button"
                    onClick={() => setSetupStep(1)}
                    className="text-xs text-[#8e95a2] hover:text-white"
                  >
                    ← Back
                  </button>

                  <button
                    type="submit"
                    disabled={setupLoading}
                    className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    {setupLoading ? 'Verifying...' : 'Verify & Link Email'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
