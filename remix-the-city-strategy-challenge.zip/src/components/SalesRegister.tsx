/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SaleRecord } from '../types/auction';
import { formatRupees, formatRupeesWords, formatDateTime } from '../utils/formatters';
import { auctionStore } from '../services/auctionStore';
import { Download, RotateCcw, CheckCircle2 } from 'lucide-react';

interface SalesRegisterProps {
  sales: SaleRecord[];
}

export const SalesRegister: React.FC<SalesRegisterProps> = ({ sales }) => {
  const downloadSalesCSV = () => {
    const headers = ['Sale ID', 'Card Name', 'Category', 'Sector', 'Winning Team', 'Amount (INR)', 'Timestamp', 'Status'];
    const rows = sales.map((s) => [
      s.id,
      `"${s.cardName.replace(/"/g, '""')}"`,
      s.category,
      s.sector,
      s.winningTeamName,
      s.amount,
      new Date(s.timestamp).toISOString(),
      s.isReversed ? 'REVERSED' : 'CONFIRMED',
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `csc_sales_register_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#11141b] border border-[#212734] rounded-2xl p-5 shadow-lg">
        <div>
          <h3 className="font-display font-bold text-base text-white">Official Sales Register</h3>
          <p className="text-xs text-[#8e95a2] mt-0.5">
            Total Confirmed Sales: {sales.filter((s) => !s.isReversed).length}
          </p>
        </div>

        <button
          onClick={downloadSalesCSV}
          className="flex items-center gap-2 px-4 py-2 bg-[#1b212c] hover:bg-[#252e3e] text-[#d4af37] border border-[#d4af37]/40 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Export Sales CSV</span>
        </button>
      </div>

      {/* Table */}
      <div className="bg-[#101319] border border-[#212733] rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#141821] border-b border-[#212733] text-[#8e95a2] uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3.5 px-4">Card Name</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Sector</th>
                <th className="py-3.5 px-4">Winning Team</th>
                <th className="py-3.5 px-4">Final Sale Amount</th>
                <th className="py-3.5 px-4">Sale Time</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b212b]">
              {sales.length > 0 ? (
                sales.map((sale) => (
                  <tr key={sale.id} className="hover:bg-[#151922] transition-colors">
                    <td className="py-3.5 px-4 font-display font-bold text-white max-w-xs truncate">
                      {sale.cardName}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-[#d4af37]/15 text-[#d4af37] border border-[#d4af37]/30">
                        {sale.category}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-[#8e95a2]">
                      {sale.sector}
                    </td>
                    <td className="py-3.5 px-4 font-display font-bold text-white">
                      {sale.winningTeamName}
                    </td>
                    <td className="py-3.5 px-4 font-mono-val font-bold text-emerald-400">
                      {formatRupees(sale.amount)}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-[#8e95a2]">
                      {formatDateTime(sale.timestamp)}
                    </td>
                    <td className="py-3.5 px-4">
                      {sale.isReversed ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-500/15 text-rose-400 border border-rose-500/30">
                          REVERSED
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                          CONFIRMED
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      {!sale.isReversed && (
                        <button
                          onClick={() => auctionStore.undoLastSale(sale.id)}
                          className="px-2.5 py-1 text-[11px] font-semibold text-rose-400 hover:text-white bg-rose-950/30 hover:bg-rose-900/50 border border-rose-500/30 rounded-lg transition-colors cursor-pointer"
                          title="Undo this specific sale"
                        >
                          Undo
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-[#64748b]">
                    No sales confirmed yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
