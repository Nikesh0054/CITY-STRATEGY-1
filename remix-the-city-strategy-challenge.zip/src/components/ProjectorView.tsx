/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Maximize2, Minimize2, Radio, CheckCircle2, AlertCircle } from 'lucide-react';
import { CurrentAuctionState } from '../types/auction';
import { formatRupees, formatRupeesWords, formatTimer } from '../utils/formatters';

interface ProjectorViewProps {
  currentAuction: CurrentAuctionState;
}

export const ProjectorView: React.FC<ProjectorViewProps> = ({ currentAuction }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
      }
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const card = currentAuction.card;
  const isSold = currentAuction.status === 'SOLD' && currentAuction.completedSale;
  const isUnsold = currentAuction.status === 'UNSOLD';
  const completed = currentAuction.completedSale;

  return (
    <div className="min-h-screen bg-[#07090b] text-[#f1f5f9] flex flex-col justify-between selection:bg-amber-500/20">
      {/* Top Header */}
      <header className="px-8 lg:px-14 py-6 border-b border-[#1b1f26] bg-[#0c0f13]/80 backdrop-blur-md flex items-center justify-between">
        {/* Top-left: THE CITY STRATEGY CHALLENGE with NO "AUDITORIUM PROJECTOR" badge! */}
        <div className="flex items-center gap-4">
          <div className="w-3.5 h-3.5 rounded-full bg-[#d4af37] shadow-[0_0_12px_rgba(212,175,55,0.8)] animate-pulse" />
          <h1 className="font-display tracking-widest text-2xl lg:text-3xl font-bold text-white">
            THE CITY STRATEGY CHALLENGE
          </h1>
        </div>

        {/* Top-right: AUCTION FLOOR indicator and fullscreen button */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5 px-4 py-2 rounded-full bg-[#141820] border border-[#232a36] text-xs font-semibold tracking-wider text-[#94a3b8] uppercase">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>AUCTION FLOOR</span>
          </div>

          <button
            onClick={toggleFullscreen}
            className="p-2.5 rounded-lg bg-[#141820] hover:bg-[#1e2430] border border-[#232a36] text-[#94a3b8] hover:text-white transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col justify-center px-8 lg:px-16 py-8 max-w-7xl mx-auto w-full">
        {/* COMPLETED SALE SCREEN (Screenshot 1 fix: includes WON BY: TEAM N) */}
        {isSold && completed ? (
          <div className="w-full bg-gradient-to-b from-[#13171e] to-[#0c0f14] border border-[#d4af37]/40 rounded-3xl p-10 lg:p-14 shadow-[0_0_50px_rgba(212,175,55,0.12)] relative overflow-hidden animate-fade-in">
            {/* Background Accent glow */}
            <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-[#d4af37]/10 blur-3xl pointer-events-none" />

            {/* Status bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 pb-8 border-b border-[#232a38]">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-7 h-7 text-[#d4af37]" />
                <span className="font-mono-val font-semibold text-lg lg:text-xl tracking-wider text-[#d4af37] uppercase">
                  ROUND CONCLUDED · CARD SOLD
                </span>
              </div>
              <div className="px-4 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-mono text-sm uppercase tracking-wider font-semibold">
                READY FOR NEXT CARD
              </div>
            </div>

            {/* Card Category & Sector */}
            <div className="pt-8 flex flex-wrap gap-3">
              <span className="px-4 py-1.5 text-xs font-bold uppercase tracking-widest rounded-md bg-[#d4af37]/20 text-[#f5d77f] border border-[#d4af37]/40">
                {completed.category}
              </span>
              <span className="px-4 py-1.5 text-xs font-bold uppercase tracking-widest rounded-md bg-[#1e2530] text-[#94a3b8] border border-[#2c3444]">
                {completed.sector}
              </span>
            </div>

            {/* Card Full Name */}
            <h2 className="font-display text-4xl lg:text-6xl font-extrabold text-white mt-4 mb-8 leading-tight">
              {completed.cardName}
            </h2>

            {/* WINNING TEAM & FINAL SALE AMOUNT CALLOUTS */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-[#232a38]">
              {/* WINNING TEAM (Prominent, High Visibility for Auditorium from a distance!) */}
              <div className="bg-[#171c25] border-2 border-[#d4af37]/60 rounded-2xl p-6 lg:p-8 flex flex-col justify-center">
                <p className="text-sm font-semibold tracking-widest uppercase text-[#c89b3c] mb-1">
                  OFFICIAL WINNER
                </p>
                <div className="text-3xl lg:text-5xl font-black font-display tracking-wider text-white">
                  WON BY: <span className="text-[#d4af37]">{completed.winningTeamName}</span>
                </div>
              </div>

              {/* FINAL SALE AMOUNT */}
              <div className="bg-[#171c25] border border-[#2a3242] rounded-2xl p-6 lg:p-8 flex flex-col justify-center">
                <p className="text-sm font-semibold tracking-widest uppercase text-[#94a3b8] mb-1">
                  FINAL SALE AMOUNT
                </p>
                <div className="text-3xl lg:text-5xl font-black font-mono-val tracking-tight text-emerald-400">
                  {formatRupees(completed.amount)}
                </div>
                <p className="text-sm font-medium text-[#94a3b8] mt-1">
                  {formatRupeesWords(completed.amount)}
                </p>
              </div>
            </div>
          </div>
        ) : isUnsold && card ? (
          /* UNSOLD (NO SALE) SCREEN */
          <div className="w-full bg-[#111419] border border-rose-500/30 rounded-3xl p-10 lg:p-14 shadow-2xl animate-fade-in">
            <div className="flex items-center gap-3 pb-6 border-b border-[#202632]">
              <AlertCircle className="w-7 h-7 text-rose-400" />
              <span className="font-mono-val font-semibold text-lg lg:text-xl tracking-wider text-rose-400 uppercase">
                ROUND CONCLUDED · NO SALE (CARD PASSED)
              </span>
            </div>
            <div className="pt-6 flex gap-3">
              <span className="px-3 py-1 text-xs font-bold uppercase rounded bg-[#202632] text-slate-300">
                {card.category}
              </span>
              <span className="px-3 py-1 text-xs font-bold uppercase rounded bg-[#202632] text-slate-300">
                {card.sector}
              </span>
            </div>
            <h2 className="font-display text-4xl lg:text-5xl font-bold text-white mt-4 mb-4">
              {card.name}
            </h2>
            <p className="text-slate-400 text-lg max-w-3xl mb-8">
              {card.description}
            </p>
            <div className="p-4 rounded-xl bg-[#171b22] border border-[#2a313f] text-[#94a3b8] font-mono text-sm">
              Card remains in reserve. Awaiting next card selection by auction administrator.
            </div>
          </div>
        ) : card ? (
          /* ACTIVE / READY AUCTION SCREEN */
          <div className="w-full space-y-8 animate-fade-in">
            {/* Top Status & Sequence */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-[#11151c]/90 border border-[#202734] rounded-2xl px-6 py-4">
              <div className="flex items-center gap-3">
                <span className="px-3 py-1 rounded text-xs font-extrabold uppercase tracking-widest bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/40">
                  {card.category}
                </span>
                <span className="px-3 py-1 rounded text-xs font-bold uppercase tracking-widest bg-[#1b212b] text-[#94a3b8] border border-[#283242]">
                  {card.sector}
                </span>
              </div>

              {/* Status Badge */}
              <div className="flex items-center gap-2">
                {currentAuction.status === 'ACTIVE' && (
                  <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-mono text-xs font-bold tracking-wider animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    LIVE BIDDING ACTIVE
                  </span>
                )}
                {currentAuction.status === 'READY' && (
                  <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/40 font-mono text-xs font-bold tracking-wider">
                    READY TO COMMENCE
                  </span>
                )}
                {currentAuction.status === 'PAUSED' && (
                  <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 font-mono text-xs font-bold tracking-wider">
                    AUCTION PAUSED
                  </span>
                )}
                {currentAuction.status === 'CONCLUDED' && (
                  <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/40 font-mono text-xs font-bold tracking-wider">
                    TIME EXPIRED · AWAITING CONFIRMATION
                  </span>
                )}

                {currentAuction.timerHasExtended && (
                  <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold tracking-wider">
                    +20S EXTENSION
                  </span>
                )}
              </div>
            </div>

            {/* Card Card Title & Description */}
            <div className="bg-gradient-to-br from-[#12161e] to-[#0c0f14] border border-[#222a38] rounded-3xl p-8 lg:p-12 shadow-2xl">
              <h2 className="font-display text-4xl lg:text-6xl font-black text-white leading-tight">
                {card.name}
              </h2>
              <p className="text-lg lg:text-xl text-[#94a3b8] mt-4 max-w-4xl font-normal leading-relaxed">
                {card.description}
              </p>
            </div>

            {/* Large Timer and Current Bid Displays */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Large Timer */}
              <div className="bg-[#11151c] border border-[#222938] rounded-3xl p-8 lg:p-10 flex flex-col justify-center items-center text-center shadow-xl">
                <span className="text-xs font-bold tracking-widest text-[#64748b] uppercase mb-2">
                  COUNTDOWN TIMER
                </span>
                <div
                  className={`font-mono-val font-black tracking-tighter text-6xl lg:text-8xl tabular-nums ${
                    currentAuction.timerSeconds <= 10
                      ? 'text-rose-500 animate-pulse'
                      : currentAuction.timerSeconds <= 20
                      ? 'text-amber-400'
                      : 'text-white'
                  }`}
                >
                  {formatTimer(currentAuction.timerSeconds)}
                </div>
                <div className="mt-3 text-xs font-mono text-[#64748b] uppercase tracking-wider">
                  Initial 60s · One-time 20s extension at ≤10s
                </div>
              </div>

              {/* Large Current Bid */}
              <div className="bg-[#11151c] border border-[#222938] rounded-3xl p-8 lg:p-10 flex flex-col justify-center items-center text-center shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#d4af37]/5 rounded-bl-full pointer-events-none" />
                <span className="text-xs font-bold tracking-widest text-[#d4af37] uppercase mb-2">
                  CURRENT ACCEPTED BID
                </span>
                <div className="font-mono-val font-black tracking-tight text-5xl lg:text-7xl text-[#d4af37] tabular-nums">
                  {formatRupees(currentAuction.currentBid)}
                </div>
                <div className="mt-2 text-base lg:text-lg font-semibold text-[#94a3b8]">
                  {formatRupeesWords(currentAuction.currentBid)}
                </div>
                <div className="mt-2 text-xs font-mono text-[#64748b]">
                  {currentAuction.bidCount} accepted bid{currentAuction.bidCount !== 1 ? 's' : ''} recorded
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* NO CARD LOADED */
          <div className="text-center py-24 bg-[#11151c] border border-[#202734] rounded-3xl p-12">
            <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-[#1b222c] border border-[#283242] flex items-center justify-center text-[#d4af37]">
              <Radio className="w-8 h-8 animate-pulse" />
            </div>
            <h2 className="font-display text-3xl font-bold text-white mb-3">
              AUCTION FLOOR READY
            </h2>
            <p className="text-[#8892b0] max-w-md mx-auto">
              Awaiting administrator to select and load the initial strategy card. All connected terminals will update automatically.
            </p>
          </div>
        )}
      </main>

      {/* Footer Info */}
      <footer className="px-8 lg:px-14 py-4 border-t border-[#1b1f26] bg-[#0c0f13] text-xs text-[#64748b] flex flex-wrap justify-between items-center gap-4">
        <div className="flex items-center gap-4">
          <span>CATEGORY SEQUENCE: 1. STAKEHOLDER → 2. CHALLENGE → 3. CONSTRAINT → 4. IMPACT</span>
        </div>
        <div className="flex items-center gap-4 font-mono">
          <span>RULES: 1 CARD PER CATEGORY · MAX 4 PER TEAM</span>
        </div>
      </footer>
    </div>
  );
};
