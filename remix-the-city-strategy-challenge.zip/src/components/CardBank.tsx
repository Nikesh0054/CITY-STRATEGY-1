/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Card, Category, Sector, CardStatus } from '../types/auction';
import {
  Layers,
  Search,
  Filter,
  CheckCircle,
  Clock,
  Edit2,
  X,
  Save,
  AlertCircle,
  HelpCircle,
  Check,
  RotateCcw,
  Plus,
  Trash2,
  Archive,
  ArchiveRestore,
  LayoutGrid,
  List,
  AlertTriangle,
  Tag,
  Briefcase,
  PlayCircle,
  ShieldCheck,
} from 'lucide-react';
import { auctionStore } from '../services/auctionStore';

interface CardBankProps {
  cards: Card[];
  currentCardId: string | null;
  initialEditingCardId?: string | null;
  onClearInitialEditingCard?: () => void;
}

export const CardBank: React.FC<CardBankProps> = ({
  cards,
  currentCardId,
  initialEditingCardId,
  onClearInitialEditingCard,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Editing state
  const [editingCard, setEditingCard] = useState<Card | null>(null);
  const [editName, setEditName] = useState('');
  const [editCategory, setEditCategory] = useState<Category>('STAKEHOLDER');
  const [editSector, setEditSector] = useState<Sector>('MOBILITY');
  const [editDescription, setEditDescription] = useState('');
  const [isConfirmingSave, setIsConfirmingSave] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Add Card state
  const [isAddingCard, setIsAddingCard] = useState(false);
  const [newCardId, setNewCardId] = useState('');
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState<Category>('STAKEHOLDER');
  const [newSector, setNewSector] = useState<Sector>('MOBILITY');
  const [newDescription, setNewDescription] = useState('');
  const [isSubmittingAdd, setIsSubmittingAdd] = useState(false);

  // Delete modal state
  const [deletingCard, setDeletingCard] = useState<Card | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Feedback toast
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const categories: Category[] = ['STAKEHOLDER', 'CHALLENGE', 'CONSTRAINT', 'IMPACT'];
  const sectors: Sector[] = ['MOBILITY', 'WASTE MANAGEMENT', 'WATER MANAGEMENT'];

  const filteredCards = cards.filter((c) => {
    if (selectedCategory !== 'ALL' && c.category !== selectedCategory) return false;
    if (selectedSector !== 'ALL' && c.sector !== selectedSector) return false;
    if (selectedStatus !== 'ALL' && c.status !== selectedStatus) return false;
    if (search) {
      const q = search.toLowerCase();
      const matchName = c.name.toLowerCase().includes(q);
      const matchDesc = (c.description || '').toLowerCase().includes(q);
      const matchId = c.id.toLowerCase().includes(q);
      const matchSector = c.sector.toLowerCase().includes(q);
      if (!matchName && !matchDesc && !matchId && !matchSector) return false;
    }
    return true;
  });

  // Open Edit modal
  const handleOpenEdit = (card: Card) => {
    setEditingCard(card);
    setEditName(card.name);
    setEditCategory(card.category);
    setEditSector(card.sector);
    setEditDescription(card.description || '');
    setIsConfirmingSave(false);
    setFeedback(null);
  };

  const handleCloseEdit = () => {
    setEditingCard(null);
    setIsConfirmingSave(false);
  };

  useEffect(() => {
    if (initialEditingCardId) {
      const target = cards.find((c) => c.id === initialEditingCardId);
      if (target) {
        handleOpenEdit(target);
        onClearInitialEditingCard?.();
      }
    }
  }, [initialEditingCardId, cards]);

  // Save Card edits directly and reliably
  const handleSaveCard = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCard) return;

    if (!editName.trim()) {
      setFeedback({ type: 'error', message: 'Card title/name cannot be empty.' });
      return;
    }

    setIsSaving(true);
    setFeedback(null);

    const result = await auctionStore.editCard(editingCard.id, {
      name: editName.trim(),
      category: editCategory,
      sector: editSector,
      description: editDescription.trim(),
    });

    setIsSaving(false);

    if (result.success) {
      setFeedback({
        type: 'success',
        message: `Card ${editingCard.id} ("${editName.trim()}") saved successfully and synchronized across all active displays.`,
      });
      setIsConfirmingSave(false);
      setTimeout(() => {
        setEditingCard(null);
      }, 1000);
    } else {
      setFeedback({
        type: 'error',
        message: result.error || 'Failed to save card modifications.',
      });
    }
  };

  // Add Card
  const handleOpenAdd = () => {
    setIsAddingCard(true);
    setNewCardId('');
    setNewName('');
    setNewCategory('STAKEHOLDER');
    setNewSector('MOBILITY');
    setNewDescription('');
    setFeedback(null);
  };

  const handleSaveNewCard = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) {
      setFeedback({ type: 'error', message: 'Card title/name is required.' });
      return;
    }

    setIsSubmittingAdd(true);
    setFeedback(null);

    const result = await auctionStore.addCard({
      id: newCardId.trim() || undefined,
      name: newName.trim(),
      category: newCategory,
      sector: newSector,
      description: newDescription.trim(),
    });

    setIsSubmittingAdd(false);

    if (result.success && result.card) {
      setFeedback({
        type: 'success',
        message: `New card ${result.card.id} ("${result.card.name}") successfully added to the ${result.card.category} bank.`,
      });
      setTimeout(() => {
        setIsAddingCard(false);
      }, 1200);
    } else {
      setFeedback({
        type: 'error',
        message: result.error || 'Failed to create new card.',
      });
    }
  };

  // Archive / Unarchive
  const handleToggleArchive = async (card: Card) => {
    const isCurrentlyArchived = card.status === 'ARCHIVED';
    const res = await auctionStore.archiveCard(card.id, !isCurrentlyArchived);
    if (res.success) {
      setFeedback({
        type: 'success',
        message: `Card ${card.id} ${isCurrentlyArchived ? 'restored to Available queue' : 'archived from active queue'}.`,
      });
    } else {
      setFeedback({
        type: 'error',
        message: res.error || 'Failed to update card archive status.',
      });
    }
  };

  // Delete Card
  const handleConfirmDelete = async () => {
    if (!deletingCard) return;
    setIsDeleting(true);
    const res = await auctionStore.deleteCard(deletingCard.id);
    setIsDeleting(false);

    if (res.success) {
      setFeedback({
        type: 'success',
        message: `Card ${deletingCard.id} successfully removed from the bank.`,
      });
      setDeletingCard(null);
    } else {
      setFeedback({
        type: 'error',
        message: res.error || 'Failed to delete card.',
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Feedback */}
      {feedback && (
        <div
          className={`p-4 rounded-2xl border text-xs font-medium flex items-center justify-between gap-3 shadow-lg transition-all animate-fadeIn ${
            feedback.type === 'success'
              ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/80 border-rose-500/40 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {feedback.type === 'success' ? (
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
          <button
            onClick={() => setFeedback(null)}
            className="text-xs opacity-75 hover:opacity-100 px-2 py-0.5 rounded cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Overview Banner */}
      <div className="bg-[#10141b] border border-[#212734] rounded-2xl p-5 sm:p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#d4af37]/15 border border-[#d4af37]/30 text-[#d4af37]">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-xl font-bold text-white tracking-wide">
                  Bank Card Management
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/30">
                  {cards.length} Total Cards
                </span>
              </div>
              <p className="text-xs text-[#8e95a2] mt-0.5">
                Authoritative 120-card strategy repository. View, edit titles, modify problem statements, change categories, or add cards.
              </p>
            </div>
          </div>

          {/* Category Breakdown Badges */}
          <div className="flex flex-wrap items-center gap-2 mt-4">
            {categories.map((cat) => {
              const count = cards.filter((c) => c.category === cat).length;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(selectedCategory === cat ? 'ALL' : cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider border transition-all cursor-pointer flex items-center gap-1.5 ${
                    selectedCategory === cat
                      ? 'bg-[#d4af37] text-[#0a0c10] border-[#d4af37] shadow-md shadow-[#d4af37]/20'
                      : 'bg-[#151922] border-[#252c3c] text-[#9ca3af] hover:text-white hover:border-[#384259]'
                  }`}
                >
                  <span>{cat}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded-md font-mono text-[10px] ${
                      selectedCategory === cat ? 'bg-black/20 text-[#0a0c10]' : 'bg-[#1e2433] text-white'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2.5 rounded-xl bg-[#d4af37] hover:bg-[#e4be42] text-[#0a0c10] text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 shadow-lg shadow-[#d4af37]/20 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add New Card</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#11141b] border border-[#212734] rounded-2xl p-4 shadow-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5 flex-1">
          {/* Search */}
          <div className="relative min-w-[260px] flex-1 max-w-md">
            <Search className="w-4 h-4 text-[#64748b] absolute left-3.5 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search card name, ID, sector, or problem statement..."
              className="w-full bg-[#161a22] border border-[#283140] text-xs text-white pl-9 pr-3 py-2 rounded-xl placeholder:text-[#4b5563] outline-none focus:border-[#d4af37]"
            />
          </div>

          {/* Sector Filter */}
          <select
            value={selectedSector}
            onChange={(e) => setSelectedSector(e.target.value)}
            className="bg-[#161a22] border border-[#283140] text-xs text-[#9ca3af] px-3 py-2 rounded-xl outline-none focus:border-[#d4af37]"
          >
            <option value="ALL">All Sectors ({sectors.length})</option>
            {sectors.map((sec) => (
              <option key={sec} value={sec}>
                {sec}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-[#161a22] border border-[#283140] text-xs text-[#9ca3af] px-3 py-2 rounded-xl outline-none focus:border-[#d4af37]"
          >
            <option value="ALL">All Statuses</option>
            <option value="AVAILABLE">Available</option>
            <option value="IN_AUCTION">In Auction</option>
            <option value="SOLD">Sold</option>
            <option value="UNSOLD">Unsold (No Sale)</option>
            <option value="ARCHIVED">Archived</option>
          </select>

          {(search || selectedCategory !== 'ALL' || selectedSector !== 'ALL' || selectedStatus !== 'ALL') && (
            <button
              onClick={() => {
                setSearch('');
                setSelectedCategory('ALL');
                setSelectedSector('ALL');
                setSelectedStatus('ALL');
              }}
              className="text-xs text-[#d4af37] hover:underline flex items-center gap-1 cursor-pointer px-2"
            >
              <RotateCcw className="w-3 h-3" />
              Reset Filters
            </button>
          )}
        </div>

        {/* View mode toggle and counter */}
        <div className="flex items-center gap-3">
          <div className="bg-[#161a22] border border-[#283140] p-1 rounded-xl flex items-center gap-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                viewMode === 'grid' ? 'bg-[#d4af37] text-black' : 'text-[#64748b] hover:text-white'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                viewMode === 'table' ? 'bg-[#d4af37] text-black' : 'text-[#64748b] hover:text-white'
              }`}
              title="Table View"
            >
              <List className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="text-xs font-mono text-[#8e95a2]">
            Showing <strong className="text-white">{filteredCards.length}</strong> of {cards.length}
          </div>
        </div>
      </div>

      {/* GRID VIEW */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCards.map((c) => {
            const isCurrent = c.id === currentCardId;

            return (
              <div
                key={c.id}
                className={`p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 ${
                  isCurrent
                    ? 'bg-[#151c27] border-[#d4af37] shadow-lg shadow-[#d4af37]/15 ring-1 ring-[#d4af37]'
                    : c.status === 'SOLD'
                    ? 'bg-[#101318] border-[#1e242e] opacity-90'
                    : c.status === 'ARCHIVED'
                    ? 'bg-[#0f1117] border-[#1e222d] opacity-60'
                    : 'bg-[#11141b] border-[#222834] hover:border-[#2f384a]'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase bg-[#d4af37]/15 text-[#d4af37] border border-[#d4af37]/30">
                        {c.category}
                      </span>
                      <span className="text-xs font-mono font-bold text-white bg-[#191f2b] px-2 py-0.5 rounded border border-[#2b3547]">
                        #{c.id}
                      </span>
                    </div>

                    {c.status === 'SOLD' ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                        SOLD
                      </span>
                    ) : c.status === 'IN_AUCTION' ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-500/15 text-amber-400 border border-amber-500/30 animate-pulse">
                        LIVE IN AUCTION
                      </span>
                    ) : c.status === 'ARCHIVED' ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-zinc-600/20 text-zinc-400 border border-zinc-600/30">
                        ARCHIVED
                      </span>
                    ) : c.status === 'UNSOLD' ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-500/15 text-rose-400 border border-rose-500/30">
                        UNSOLD
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-500/15 text-slate-400 border border-slate-500/30">
                        AVAILABLE
                      </span>
                    )}
                  </div>

                  <p className="text-[11px] font-bold uppercase tracking-wider text-[#94a3b8] flex items-center gap-1.5">
                    <Tag className="w-3 h-3 text-[#d4af37]" />
                    <span>{c.sector}</span>
                  </p>

                  <h4 className="font-display text-base font-bold text-white leading-snug">
                    {c.name}
                  </h4>

                  <p className="text-xs text-[#8e95a2] leading-relaxed line-clamp-3">
                    {c.description || <span className="italic text-[#555d6e]">No problem statement description provided.</span>}
                  </p>
                </div>

                <div className="pt-3 border-t border-[#1c222c] flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleOpenEdit(c)}
                      className="px-3 py-1.5 bg-[#171c26] hover:bg-[#202735] hover:text-[#d4af37] text-white text-xs font-semibold rounded-lg border border-[#2b3547] transition-colors flex items-center gap-1.5 cursor-pointer"
                      title={`Edit card ${c.id}`}
                    >
                      <Edit2 className="w-3.5 h-3.5 text-[#d4af37]" />
                      <span>Edit</span>
                    </button>

                    <button
                      onClick={() => handleToggleArchive(c)}
                      disabled={isCurrent}
                      className={`p-1.5 rounded-lg border text-xs transition-colors cursor-pointer ${
                        c.status === 'ARCHIVED'
                          ? 'border-zinc-700 bg-zinc-800 text-zinc-300 hover:text-white'
                          : 'border-[#283140] bg-[#161a22] text-[#8e95a2] hover:text-white'
                      } ${isCurrent ? 'opacity-30 cursor-not-allowed' : ''}`}
                      title={c.status === 'ARCHIVED' ? 'Restore card to Available' : 'Archive card from auction queue'}
                    >
                      {c.status === 'ARCHIVED' ? (
                        <ArchiveRestore className="w-3.5 h-3.5" />
                      ) : (
                        <Archive className="w-3.5 h-3.5" />
                      )}
                    </button>

                    <button
                      onClick={() => setDeletingCard(c)}
                      disabled={isCurrent}
                      className={`p-1.5 rounded-lg border border-[#283140] bg-[#161a22] text-[#8e95a2] hover:text-rose-400 hover:border-rose-500/40 text-xs transition-colors cursor-pointer ${
                        isCurrent ? 'opacity-30 cursor-not-allowed' : ''
                      }`}
                      title="Delete card"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {c.status === 'AVAILABLE' && (
                    <button
                      onClick={() => auctionStore.loadCard(c.id)}
                      className="px-3 py-1.5 bg-[#1a202c] hover:bg-[#d4af37] hover:text-[#0a0c10] text-[#9ca3af] text-xs font-bold rounded-lg border border-[#2a3344] transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <PlayCircle className="w-3 h-3" />
                      <span>Load in Auction</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TABLE VIEW */}
      {viewMode === 'table' && (
        <div className="bg-[#10141b] border border-[#212734] rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#212734] bg-[#0c0e14] text-[11px] font-bold uppercase tracking-wider text-[#64748b]">
                  <th className="py-3.5 px-4">Card ID</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">Sector</th>
                  <th className="py-3.5 px-4">Card Title</th>
                  <th className="py-3.5 px-4">Description / Problem Statement</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#181d26] text-xs">
                {filteredCards.map((c) => {
                  const isCurrent = c.id === currentCardId;

                  return (
                    <tr
                      key={c.id}
                      className={`hover:bg-[#151922] transition-colors ${
                        isCurrent ? 'bg-[#151e2b]' : ''
                      }`}
                    >
                      <td className="py-3 px-4 font-mono font-bold text-white whitespace-nowrap">
                        #{c.id}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-[#d4af37]/15 text-[#d4af37] border border-[#d4af37]/30">
                          {c.category}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-[#94a3b8] font-medium whitespace-nowrap">
                        {c.sector}
                      </td>
                      <td className="py-3 px-4 font-bold text-white max-w-xs">
                        <div className="line-clamp-1">{c.name}</div>
                      </td>
                      <td className="py-3 px-4 text-[#8e95a2] max-w-md">
                        <div className="line-clamp-2">
                          {c.description || <span className="italic text-[#4b5563]">None</span>}
                        </div>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {c.status === 'SOLD' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                            SOLD
                          </span>
                        ) : c.status === 'IN_AUCTION' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-500/15 text-amber-400 border border-amber-500/30">
                            IN AUCTION
                          </span>
                        ) : c.status === 'ARCHIVED' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-zinc-600/20 text-zinc-400 border border-zinc-600/30">
                            ARCHIVED
                          </span>
                        ) : c.status === 'UNSOLD' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-500/15 text-rose-400 border border-rose-500/30">
                            UNSOLD
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-500/15 text-slate-400 border border-slate-500/30">
                            AVAILABLE
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEdit(c)}
                            className="p-1.5 bg-[#171c26] hover:bg-[#222a3a] text-white hover:text-[#d4af37] rounded-lg border border-[#2b3547] transition-colors cursor-pointer"
                            title="Edit Card"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleToggleArchive(c)}
                            disabled={isCurrent}
                            className={`p-1.5 rounded-lg border border-[#2b3547] bg-[#171c26] text-[#8e95a2] hover:text-white transition-colors cursor-pointer ${
                              isCurrent ? 'opacity-30 cursor-not-allowed' : ''
                            }`}
                            title={c.status === 'ARCHIVED' ? 'Restore card' : 'Archive card'}
                          >
                            {c.status === 'ARCHIVED' ? (
                              <ArchiveRestore className="w-3.5 h-3.5" />
                            ) : (
                              <Archive className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <button
                            onClick={() => setDeletingCard(c)}
                            disabled={isCurrent}
                            className={`p-1.5 rounded-lg border border-[#2b3547] bg-[#171c26] text-[#8e95a2] hover:text-rose-400 transition-colors cursor-pointer ${
                              isCurrent ? 'opacity-30 cursor-not-allowed' : ''
                            }`}
                            title="Delete Card"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {filteredCards.length === 0 && (
        <div className="py-16 text-center bg-[#101318] border border-dashed border-[#232a38] rounded-2xl p-8">
          <Layers className="w-10 h-10 text-[#4b5563] mx-auto mb-3" />
          <h3 className="text-white font-medium text-base">No Matching Cards</h3>
          <p className="text-xs text-[#8e95a2] max-w-sm mx-auto mt-1">
            Try adjusting your search criteria or resetting the category and sector filters.
          </p>
        </div>
      )}

      {/* EDIT CARD MODAL */}
      {editingCard && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#10141b] border border-[#283244] rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6 relative animate-fadeIn max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-[#1f2635]">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#d4af37]/15 border border-[#d4af37]/30 text-[#d4af37]">
                  <Edit2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-white">
                    Edit Bank Card
                  </h3>
                  <p className="text-xs font-mono text-[#8e95a2]">
                    Card ID: <strong className="text-white">#{editingCard.id}</strong> (Original ID Preserved)
                  </p>
                </div>
              </div>

              <button
                onClick={handleCloseEdit}
                className="p-1.5 rounded-lg text-[#64748b] hover:text-white hover:bg-[#181d26] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Warnings based on card state */}
            {editingCard.id === currentCardId && (
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2.5">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
                <span>
                  <strong>Active Auction Notice:</strong> This card is currently loaded in the live auction. Updates will immediately reflect on the Projector and Team Bid panels without resetting timer or bids.
                </span>
              </div>
            )}

            {editingCard.status === 'SOLD' && (
              <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 shrink-0 text-blue-400" />
                <span>
                  <strong>Sold Card Notice:</strong> This card was already purchased. Editing details will update displays across team portfolios and sales reports while preserving financial prices and team assignments.
                </span>
              </div>
            )}

            <form onSubmit={handleSaveCard} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                  Card Title / Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => {
                    setEditName(e.target.value);
                    setIsConfirmingSave(false);
                  }}
                  className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-sm font-semibold outline-none"
                  placeholder="Enter strategic card title..."
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Category
                  </label>
                  <select
                    value={editCategory}
                    onChange={(e) => {
                      setEditCategory(e.target.value as Category);
                      setIsConfirmingSave(false);
                    }}
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3 py-2.5 rounded-xl text-xs outline-none"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Sector
                  </label>
                  <select
                    value={editSector}
                    onChange={(e) => {
                      setEditSector(e.target.value as Sector);
                      setIsConfirmingSave(false);
                    }}
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3 py-2.5 rounded-xl text-xs outline-none"
                  >
                    {sectors.map((sec) => (
                      <option key={sec} value={sec}>
                        {sec}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                  Strategic Description / Problem Statement
                </label>
                <textarea
                  value={editDescription}
                  onChange={(e) => {
                    setEditDescription(e.target.value);
                    setIsConfirmingSave(false);
                  }}
                  rows={4}
                  className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs leading-relaxed outline-none"
                  placeholder="Enter detailed card problem statement and strategic scope..."
                />
              </div>

              <div className="bg-[#141822] border border-[#222a38] rounded-xl p-3 text-[11px] text-[#8e95a2] flex items-center justify-between">
                <span>Current Status: <strong className="text-white">{editingCard.status}</strong></span>
                <span className="text-[#64748b]">Preserves original ID ({editingCard.id})</span>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#1f2635]">
                <button
                  type="button"
                  onClick={handleCloseEdit}
                  disabled={isSaving}
                  className="px-4 py-2.5 rounded-xl border border-[#2a3344] text-[#9ca3af] hover:text-white hover:bg-[#171c26] text-xs font-semibold transition-colors cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer bg-[#d4af37] hover:bg-[#e4be42] text-[#0a0c10] shadow-lg shadow-[#d4af37]/20 disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>
                    {isSaving ? 'Saving Changes...' : 'Save Changes'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD NEW CARD MODAL */}
      {isAddingCard && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#10141b] border border-[#283244] rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6 relative animate-fadeIn max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-[#1f2635]">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#d4af37]/15 border border-[#d4af37]/30 text-[#d4af37]">
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-white">
                    Add New Strategy Card
                  </h3>
                  <p className="text-xs text-[#8e95a2]">
                    Create a new card to append to the auction card repository.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsAddingCard(false)}
                className="p-1.5 rounded-lg text-[#64748b] hover:text-white hover:bg-[#181d26] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewCard} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                  Card ID <span className="text-[#64748b] font-normal">(Optional — auto-generated if blank)</span>
                </label>
                <input
                  type="text"
                  value={newCardId}
                  onChange={(e) => setNewCardId(e.target.value)}
                  placeholder="e.g. STK-31 (leave empty for automatic numbering)"
                  className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs font-mono outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                  Card Title / Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Urban Mobility Command Center"
                  className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-sm font-semibold outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Category <span className="text-rose-400">*</span>
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as Category)}
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3 py-2.5 rounded-xl text-xs outline-none"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                    Sector <span className="text-rose-400">*</span>
                  </label>
                  <select
                    value={newSector}
                    onChange={(e) => setNewSector(e.target.value as Sector)}
                    className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3 py-2.5 rounded-xl text-xs outline-none"
                  >
                    {sectors.map((sec) => (
                      <option key={sec} value={sec}>
                        {sec}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#9ca3af] mb-1.5">
                  Problem Statement / Strategic Description
                </label>
                <textarea
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  rows={4}
                  placeholder="Enter strategic context, requirements, and constraints..."
                  className="w-full bg-[#161a22] border border-[#283140] focus:border-[#d4af37] text-white px-3.5 py-2.5 rounded-xl text-xs leading-relaxed outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#1f2635]">
                <button
                  type="button"
                  onClick={() => setIsAddingCard(false)}
                  disabled={isSubmittingAdd}
                  className="px-4 py-2.5 rounded-xl border border-[#2a3344] text-[#9ca3af] hover:text-white hover:bg-[#171c26] text-xs font-semibold transition-colors cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSubmittingAdd}
                  className="px-5 py-2.5 rounded-xl bg-[#d4af37] hover:bg-[#e4be42] text-[#0a0c10] text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-[#d4af37]/20"
                >
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                  <span>{isSubmittingAdd ? 'Adding...' : 'Create Card'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deletingCard && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#10141b] border border-rose-500/30 rounded-3xl max-w-md w-full p-6 sm:p-7 shadow-2xl space-y-5 animate-fadeIn">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-400">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-display text-lg font-bold text-white">
                  Delete Bank Card
                </h3>
                <p className="text-xs font-mono text-[#8e95a2]">
                  #{deletingCard.id} — {deletingCard.name}
                </p>
              </div>
            </div>

            {deletingCard.status === 'SOLD' ? (
              <div className="p-3.5 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>
                  <strong>Deletion Blocked:</strong> This card has already been sold to a team. To protect financial records and audit integrity, you cannot delete it. Consider archiving it instead.
                </span>
              </div>
            ) : deletingCard.id === currentCardId ? (
              <div className="p-3.5 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>
                  <strong>Deletion Blocked:</strong> This card is currently loaded in the active auction.
                </span>
              </div>
            ) : (
              <p className="text-xs text-[#9ca3af] leading-relaxed">
                Are you sure you want to permanently delete card <strong className="text-white">#{deletingCard.id}</strong> ("{deletingCard.name}")? This action cannot be undone.
              </p>
            )}

            <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#1f2635]">
              <button
                type="button"
                onClick={() => setDeletingCard(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl border border-[#2a3344] text-[#9ca3af] hover:text-white hover:bg-[#171c26] text-xs font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>

              {deletingCard.status !== 'SOLD' && deletingCard.id !== currentCardId && (
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  disabled={isDeleting}
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-rose-600/20"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{isDeleting ? 'Deleting...' : 'Delete Card'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
