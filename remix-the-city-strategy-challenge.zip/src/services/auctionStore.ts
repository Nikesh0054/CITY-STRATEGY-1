/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  AuctionStatus,
  Bid,
  Card,
  Category,
  Sector,
  CSCState,
  CurrentAuctionState,
  SaleRecord,
  Team,
} from '../types/auction';
import {
  buildInitialCards,
  buildInitialTeams,
  generateSmartQueue,
} from '../data/initialData';
import {
  checkTeamEligibility,
  EXTENSION_DURATION_SECONDS,
  EXTENSION_THRESHOLD_SECONDS,
  getNextMinimumBid,
  INITIAL_TIMER_SECONDS,
  OPENING_BID,
  validateBidAmount,
} from '../utils/auctionRules';

const STORAGE_KEY = 'csc_live_state_v2';
const SYNC_CHANNEL_NAME = 'csc_auction_sync_v2';

/**
 * Creates default initial state
 */
export function createDefaultState(): CSCState {
  const cards = buildInitialCards();
  const teams = buildInitialTeams();
  const queue = generateSmartQueue(cards);

  const initialCurrent: CurrentAuctionState = {
    cardId: queue.length > 0 ? queue[0] : null,
    card: queue.length > 0 ? cards.find((c) => c.id === queue[0]) || null : null,
    status: 'READY',
    currentBid: OPENING_BID,
    currentBidder: null,
    confirmedFinalBid: null,
    confirmedFinalBidStatus: 'NONE',
    bidCount: 0,
    timerSeconds: INITIAL_TIMER_SECONDS,
    timerDuration: INITIAL_TIMER_SECONDS,
    timerIsRunning: false,
    timerHasExtended: false,
    timerDeadline: null,
    auctionAttemptId: `att-${Date.now()}-1`,
    completedSale: null,
  };

  if (initialCurrent.card) {
    initialCurrent.card.status = 'IN_AUCTION';
  }

  return {
    version: 1,
    currentAuction: initialCurrent,
    teams,
    cards,
    auctionQueue: queue,
    bidHistory: [],
    salesRegister: [],
    auditLogs: [
      {
        id: `log-${Date.now()}-init`,
        action: 'SYSTEM_INITIALIZATION',
        details: 'The City Strategy Challenge initialized with 30 teams and 120 cards.',
        actor: 'SYSTEM',
        timestamp: Date.now(),
      },
    ],
    lastUpdated: Date.now(),
  };
}

class AuctionStore {
  private state: CSCState;
  private listeners: Set<(state: CSCState) => void> = new Set();
  private broadcastChannel: BroadcastChannel | null = null;
  private timerInterval: any = null;
  private sseEventSource: EventSource | null = null;

  constructor() {
    this.state = this.loadFromStorage() || createDefaultState();
    this.syncInitialTeamsCredentials(this.state);
    this.initBroadcastChannel();
    this.initSSE();
    this.fetchInitialState();
    this.startTimerTicker();
  }

  private async fetchInitialState() {
    if (typeof window === 'undefined') return;
    try {
      const res = await fetch('/api/auction/state');
      if (res.ok) {
        const data = await res.json();
        if (data && data.state) {
          this.state = data.state;
          this.saveToStorage(this.state);
          this.notify();
        }
      }
    } catch (e) {
      // offline fallback to local state
    }
  }

  private syncInitialTeamsCredentials(state: CSCState) {
    if (!state || !Array.isArray(state.teams)) return;
    let changed = false;
    for (let i = 1; i <= 30; i++) {
      const team = state.teams.find((t) => t.id === `team-${i}`);
      const expectedLoginId = `TEAM${i}`;
      const expectedPassword = i.toString().padStart(5, '0');
      if (team) {
        if (team.loginId !== expectedLoginId || team.plainPassword !== expectedPassword) {
          team.loginId = expectedLoginId;
          team.plainPassword = expectedPassword;
          changed = true;
        }
      }
    }
    if (changed) {
      this.saveToStorage(state);
    }
  }

  private loadFromStorage(): CSCState | null {
    if (typeof window === 'undefined') return null;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as CSCState;
        if (parsed && parsed.currentAuction && Array.isArray(parsed.teams)) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read from local storage:', e);
    }
    return null;
  }

  private saveToStorage(state: CSCState) {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('Could not save to local storage:', e);
    }
  }

  private initBroadcastChannel() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      this.broadcastChannel = new BroadcastChannel(SYNC_CHANNEL_NAME);
      this.broadcastChannel.onmessage = (event) => {
        if (event.data && event.data.type === 'STATE_SYNC' && event.data.payload) {
          const incoming = event.data.payload as CSCState;
          if (incoming.lastUpdated > this.state.lastUpdated) {
            this.state = incoming;
            this.saveToStorage(incoming);
            this.notify();
          }
        }
      };
    }
  }

  private initSSE() {
    if (typeof window === 'undefined') return;
    try {
      // Connect to server-sent events for multi-device sync
      this.sseEventSource = new EventSource('/api/auction/events');
      this.sseEventSource.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          if (data && data.state) {
            this.state = data.state;
            this.saveToStorage(this.state);
            this.notify();
          }
        } catch (err) {
          // ignore heartbeat parse errors
        }
      };
      this.sseEventSource.onerror = () => {
        // SSE will automatically retry
      };
    } catch (err) {
      // SSE optional if backend is running in static-first mode
    }
  }

  private startTimerTicker() {
    if (typeof window === 'undefined') return;
    if (this.timerInterval) clearInterval(this.timerInterval);

    this.timerInterval = setInterval(() => {
      const auction = this.state.currentAuction;
      if (auction.timerIsRunning && auction.status === 'ACTIVE' && auction.timerDeadline) {
        const now = Date.now();
        const rem = Math.max(0, Math.ceil((auction.timerDeadline - now) / 1000));
        
        if (rem !== auction.timerSeconds) {
          auction.timerSeconds = rem;
          if (rem <= 0) {
            auction.timerSeconds = 0;
            auction.timerIsRunning = false;
            auction.status = 'CONCLUDED';
            auction.timerDeadline = null;
          }
          this.commitState(this.state, false);
        }
      }
    }, 200);
  }

  public getState(): CSCState {
    return this.state;
  }

  public subscribe(callback: (state: CSCState) => void): () => void {
    this.listeners.add(callback);
    callback(this.state);
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notify() {
    for (const listener of this.listeners) {
      try {
        listener(this.state);
      } catch (e) {
        console.error('Listener notification error:', e);
      }
    }
  }

  private commitState(nextState: CSCState, broadcastAcrossClients: boolean = true) {
    nextState.lastUpdated = Date.now();
    this.state = { ...nextState };
    this.saveToStorage(this.state);
    this.notify();

    if (broadcastAcrossClients) {
      if (this.broadcastChannel) {
        this.broadcastChannel.postMessage({
          type: 'STATE_SYNC',
          payload: this.state,
        });
      }
      // Sync to backend if endpoint available
      this.syncToBackend(this.state);
    }
  }

  private async syncToBackend(state: CSCState) {
    try {
      await fetch('/api/auction/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(state),
      });
    } catch (e) {
      // Silently continue if backend is purely dev server
    }
  }

  private async callBackend(endpoint: string, body?: any): Promise<{ success: boolean; data?: any; error?: string }> {
    if (typeof window === 'undefined') return { success: false, error: 'No window' };
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: body ? JSON.stringify(body) : undefined,
      });
      const data = await res.json();
      if (res.ok && data.state) {
        this.state = data.state;
        this.saveToStorage(this.state);
        this.notify();
        return { success: true, data };
      }
      return { success: false, error: data?.error || 'Server error' };
    } catch (e: any) {
      return { success: false, error: 'Network error' };
    }
  }

  // --- ACTIONS ---

  /**
   * Loads a specific card or next card from queue
   */
  public async loadCard(cardId: string): Promise<{ success: boolean; error?: string }> {
    const apiRes = await this.callBackend('/api/auction/load-card', { cardId });
    if (apiRes.success) return { success: true };
    if (apiRes.error && apiRes.error !== 'Network error') return { success: false, error: apiRes.error };

    const card = this.state.cards.find((c) => c.id === cardId);
    if (!card) return { success: false, error: 'Card not found' };

    // Reset current auction attempt
    const attemptId = `att-${Date.now()}-${card.id}`;
    const nextState = { ...this.state };

    // Mark previous card if needed
    if (nextState.currentAuction.cardId && nextState.currentAuction.cardId !== cardId) {
      const prev = nextState.cards.find((c) => c.id === nextState.currentAuction.cardId);
      if (prev && prev.status === 'IN_AUCTION') {
        prev.status = 'AVAILABLE';
      }
    }

    card.status = 'IN_AUCTION';

    nextState.currentAuction = {
      cardId: card.id,
      card: { ...card },
      status: 'READY',
      currentBid: OPENING_BID,
      currentBidder: null,
      confirmedFinalBid: null,
      confirmedFinalBidStatus: 'NONE',
      bidCount: 0,
      timerSeconds: INITIAL_TIMER_SECONDS,
      timerDuration: INITIAL_TIMER_SECONDS,
      timerIsRunning: false,
      timerHasExtended: false,
      timerDeadline: null,
      auctionAttemptId: attemptId,
      completedSale: null,
    };

    nextState.auditLogs.unshift({
      id: `log-${Date.now()}`,
      action: 'LOAD_CARD',
      details: `Card loaded: "${card.name}" (${card.category} - ${card.sector})`,
      actor: 'ADMINISTRATOR',
      timestamp: Date.now(),
    });

    this.commitState(nextState);
    return { success: true };
  }

  /**
   * Load next card in queue
   */
  public async loadNextCard(): Promise<{ success: boolean; error?: string }> {
    const queue = this.state.auctionQueue;
    const currentCardId = this.state.currentAuction.cardId;
    
    // Find next available in queue
    let nextCardId: string | null = null;
    const currentIndex = currentCardId ? queue.indexOf(currentCardId) : -1;

    for (let i = currentIndex + 1; i < queue.length; i++) {
      const c = this.state.cards.find((card) => card.id === queue[i]);
      if (c && c.status === 'AVAILABLE') {
        nextCardId = c.id;
        break;
      }
    }

    if (!nextCardId) {
      // Search from beginning for any available card
      const fallback = this.state.cards.find((c) => c.status === 'AVAILABLE');
      if (fallback) nextCardId = fallback.id;
    }

    if (nextCardId) {
      return this.loadCard(nextCardId);
    }

    return { success: false, error: 'No more available cards in queue' };
  }

  /**
   * Timer control: start, pause, resume, reset, extend
   */
  public async timerControl(action: 'START' | 'PAUSE' | 'RESUME' | 'RESET' | 'EXTEND'): Promise<{ success: boolean; error?: string }> {
    const apiRes = await this.callBackend('/api/auction/timer', { action });
    if (apiRes.success) return { success: true };
    if (apiRes.error && apiRes.error !== 'Network error') return { success: false, error: apiRes.error };

    const nextState = { ...this.state };
    const auction = nextState.currentAuction;

    if (!auction.card) {
      return { success: false, error: 'No card loaded to run timer' };
    }

    const now = Date.now();

    if (action === 'START') {
      const duration = auction.timerSeconds > 0 ? auction.timerSeconds : INITIAL_TIMER_SECONDS;
      auction.timerSeconds = duration;
      auction.timerIsRunning = true;
      auction.status = 'ACTIVE';
      auction.timerDeadline = now + duration * 1000;
    } else if (action === 'PAUSE') {
      if (auction.timerDeadline) {
        auction.timerSeconds = Math.max(0, Math.ceil((auction.timerDeadline - now) / 1000));
      }
      auction.timerIsRunning = false;
      auction.status = 'PAUSED';
      auction.timerDeadline = null;
    } else if (action === 'RESUME') {
      const duration = auction.timerSeconds > 0 ? auction.timerSeconds : INITIAL_TIMER_SECONDS;
      auction.timerSeconds = duration;
      auction.timerIsRunning = true;
      auction.status = 'ACTIVE';
      auction.timerDeadline = now + duration * 1000;
    } else if (action === 'RESET') {
      auction.timerIsRunning = false;
      auction.timerSeconds = INITIAL_TIMER_SECONDS;
      auction.timerDuration = INITIAL_TIMER_SECONDS;
      auction.timerHasExtended = false;
      auction.timerDeadline = null;
      auction.status = 'READY';
    } else if (action === 'EXTEND') {
      auction.timerSeconds += EXTENSION_DURATION_SECONDS;
      if (auction.timerDeadline) {
        auction.timerDeadline += EXTENSION_DURATION_SECONDS * 1000;
      }
    }

    this.commitState(nextState);
    return { success: true };
  }

  /**
   * Submit an official bid
   */
  public async submitBid(params: {
    amount?: number;
    teamId?: string | null;
    isUnassignedAdmin?: boolean;
  }): Promise<{ success: boolean; error?: string }> {
    const apiRes = await this.callBackend('/api/auction/bid', params);
    if (apiRes.success) return { success: true };
    if (apiRes.error && apiRes.error !== 'Network error') return { success: false, error: apiRes.error };

    const nextState = { ...this.state };
    const auction = nextState.currentAuction;

    if (!auction.card) {
      return { success: false, error: 'Cannot bid: No card loaded in auction' };
    }

    if (auction.status === 'SOLD' || auction.status === 'UNSOLD') {
      return { success: false, error: 'Auction round has concluded' };
    }

    const now = Date.now();
    if (auction.status === 'CONCLUDED' || (auction.timerIsRunning && auction.timerDeadline && now >= auction.timerDeadline)) {
      auction.timerSeconds = 0;
      auction.timerIsRunning = false;
      auction.status = 'CONCLUDED';
      auction.timerDeadline = null;
      this.commitState(nextState);
      return { success: false, error: 'Auction timer has expired (00:00). Bids closed.' };
    }

    // Auto-calculate amount if not provided
    const nextMin = getNextMinimumBid(auction.currentBid, auction.bidCount);
    const amount = params.amount || nextMin;

    const validation = validateBidAmount(amount, auction.currentBid, auction.bidCount);
    if (!validation.valid) {
      return { success: false, error: validation.error };
    }

    let bidderName = 'Administrator (Unassigned)';
    let bidderId: string | null = null;
    const isUnassigned = !!params.isUnassignedAdmin || !params.teamId;

    if (!isUnassigned && params.teamId) {
      const team = nextState.teams.find((t) => t.id === params.teamId);
      if (!team) {
        return { success: false, error: 'Selected team not found' };
      }
      const eligibility = checkTeamEligibility(team, auction.card.category, amount);
      if (!eligibility.eligible) {
        return { success: false, error: eligibility.reason };
      }
      bidderId = team.id;
      bidderName = team.name;
    }

    // Auto-start 60s countdown if placed from READY state
    if (auction.status === 'READY') {
      auction.status = 'ACTIVE';
      auction.timerIsRunning = true;
      auction.timerSeconds = INITIAL_TIMER_SECONDS;
      auction.timerDeadline = now + INITIAL_TIMER_SECONDS * 1000;
    }

    const bidRecord: Bid = {
      id: `bid-${now}-${Math.random().toString(36).substring(2, 6)}`,
      auctionAttemptId: auction.auctionAttemptId,
      cardId: auction.card.id,
      cardName: auction.card.name,
      amount,
      bidderId,
      bidderName: isUnassigned ? null : bidderName,
      isUnassignedAdmin: isUnassigned,
      timestamp: now,
    };

    auction.currentBid = amount;
    auction.bidCount += 1;
    auction.currentBidder = {
      id: bidderId,
      name: bidderName,
      isUnassignedAdmin: isUnassigned,
    };

    nextState.bidHistory.unshift(bidRecord);

    // Timer check: if active and <= 10 seconds remaining, trigger one-time 20-second extension (timer reset to 20s)
    if (auction.timerIsRunning && !auction.timerHasExtended && auction.timerDeadline) {
      const rem = Math.max(0, Math.ceil((auction.timerDeadline - now) / 1000));
      if (rem <= EXTENSION_THRESHOLD_SECONDS && rem > 0) {
        auction.timerHasExtended = true;
        auction.timerSeconds = EXTENSION_DURATION_SECONDS;
        auction.timerDeadline = now + EXTENSION_DURATION_SECONDS * 1000;
        nextState.auditLogs.unshift({
          id: `log-${now}-ext`,
          action: 'TIMER_EXTENSION',
          details: `One-time 20-second extension triggered (timer reset to 20s) by bid of ₹${amount.toLocaleString('en-IN')} with ${rem}s remaining`,
          actor: 'SYSTEM',
          timestamp: now,
        });
      }
    }

    nextState.auditLogs.unshift({
      id: `log-${now}-bid`,
      action: 'ACCEPTED_BID',
      details: `Accepted bid of ₹${amount.toLocaleString('en-IN')} by ${bidderName}`,
      actor: isUnassigned ? 'ADMINISTRATOR' : bidderName,
      timestamp: now,
    });

    this.commitState(nextState);
    return { success: true };
  }

  /**
   * Set confirmed final bid amount
   */
  public async setConfirmedFinalBid(amount: number): Promise<{ success: boolean; error?: string }> {
    const apiRes = await this.callBackend('/api/auction/set-final-bid', { amount });
    if (apiRes.success) return { success: true };
    if (apiRes.error && apiRes.error !== 'Network error') return { success: false, error: apiRes.error };

    const nextState = { ...this.state };
    const auction = nextState.currentAuction;

    if (!auction.card) {
      return { success: false, error: 'No card loaded' };
    }

    if (isNaN(amount) || amount < OPENING_BID) {
      return { success: false, error: `Final bid must be at least ₹10 Lakh.` };
    }

    auction.confirmedFinalBid = amount;
    auction.confirmedFinalBidStatus = 'CONFIRMED';

    nextState.auditLogs.unshift({
      id: `log-${Date.now()}-finbid`,
      action: 'SET_FINAL_BID',
      details: `Confirmed final bid set to ₹${amount.toLocaleString('en-IN')}`,
      actor: 'ADMINISTRATOR',
      timestamp: Date.now(),
    });

    this.commitState(nextState);
    return { success: true };
  }

  /**
   * Complete Sale & Team Assignment
   */
  public async sellCard(params: {
    teamId: string;
    amount: number;
  }): Promise<{ success: boolean; error?: string }> {
    const apiRes = await this.callBackend('/api/auction/sell', params);
    if (apiRes.success) return { success: true };
    if (apiRes.error && apiRes.error !== 'Network error') return { success: false, error: apiRes.error };

    const nextState = { ...this.state };
    const auction = nextState.currentAuction;

    if (!auction.card) {
      return { success: false, error: 'No card loaded in auction' };
    }

    if (auction.status === 'SOLD') {
      return { success: false, error: 'This card has already been sold' };
    }

    const card = nextState.cards.find((c) => c.id === auction.card!.id);
    if (!card || card.status === 'SOLD') {
      return { success: false, error: 'Card is no longer available for sale' };
    }

    const team = nextState.teams.find((t) => t.id === params.teamId);
    if (!team) {
      return { success: false, error: 'Please select a valid winning team' };
    }

    const amount = Math.round(params.amount);
    if (amount < OPENING_BID) {
      return { success: false, error: 'Sale amount cannot be less than opening bid' };
    }

    // Verify team eligibility & budget
    const eligibility = checkTeamEligibility(team, card.category, amount);
    if (!eligibility.eligible) {
      return { success: false, error: eligibility.reason };
    }

    const now = Date.now();
    const saleId = `sale-${now}-${team.id}`;

    // 1. Deduct amount from team budget exactly once
    team.remainingBudget -= amount;
    team.totalSpent += amount;

    // 2. Add card to acquired-card portfolio
    const acquiredEntry = {
      cardId: card.id,
      cardName: card.name,
      category: card.category,
      sector: card.sector,
      amount,
      timestamp: now,
      attemptId: auction.auctionAttemptId,
    };
    team.acquiredCards.push(acquiredEntry);
    team.categoryProgress[card.category] = true;

    // 3. Mark card as sold in catalog
    card.status = 'SOLD';

    // 4. Record permanent sale record
    const saleRecord: SaleRecord = {
      id: saleId,
      auctionAttemptId: auction.auctionAttemptId,
      cardId: card.id,
      cardName: card.name,
      category: card.category,
      sector: card.sector,
      winningTeamId: team.id,
      winningTeamName: team.name,
      amount,
      timestamp: now,
      isReversed: false,
    };
    nextState.salesRegister.unshift(saleRecord);

    // 5. Update auction state & completedSale (authoritative for Projector display)
    auction.status = 'SOLD';
    auction.timerIsRunning = false;
    auction.timerDeadline = null;
    auction.completedSale = {
      cardId: card.id,
      cardName: card.name,
      category: card.category,
      sector: card.sector,
      winningTeamId: team.id,
      winningTeamName: team.name,
      amount,
      timestamp: now,
      attemptId: auction.auctionAttemptId,
    };

    nextState.auditLogs.unshift({
      id: `log-${now}-sale`,
      action: 'SALE_CONFIRMED',
      details: `Card "${card.name}" SOLD to ${team.name} for ₹${amount.toLocaleString('en-IN')}. Remaining budget: ₹${team.remainingBudget.toLocaleString('en-IN')}`,
      actor: 'ADMINISTRATOR',
      timestamp: now,
    });

    this.commitState(nextState);
    return { success: true };
  }

  /**
   * Mark card as UNSOLD
   */
  public async markUnsold(): Promise<{ success: boolean; error?: string }> {
    const apiRes = await this.callBackend('/api/auction/no-sale');
    if (apiRes.success) return { success: true };
    if (apiRes.error && apiRes.error !== 'Network error') return { success: false, error: apiRes.error };

    const nextState = { ...this.state };
    const auction = nextState.currentAuction;

    if (!auction.card) {
      return { success: false, error: 'No card loaded' };
    }

    const card = nextState.cards.find((c) => c.id === auction.card!.id);
    if (card) {
      card.status = 'UNSOLD';
    }

    auction.status = 'UNSOLD';
    auction.timerIsRunning = false;
    auction.timerDeadline = null;
    auction.completedSale = null;

    nextState.auditLogs.unshift({
      id: `log-${Date.now()}-unsold`,
      action: 'MARK_UNSOLD',
      details: `Card "${auction.card.name}" marked as UNSOLD (No Sale)`,
      actor: 'ADMINISTRATOR',
      timestamp: Date.now(),
    });

    this.commitState(nextState);
    return { success: true };
  }

  /**
   * Undo Last Sale
   */
  public async undoLastSale(targetSaleId?: string): Promise<{ success: boolean; error?: string }> {
    const apiRes = await this.callBackend('/api/auction/undo-sale', { saleId: targetSaleId });
    if (apiRes.success) return { success: true };
    if (apiRes.error && apiRes.error !== 'Network error') return { success: false, error: apiRes.error };

    const nextState = { ...this.state };
    
    // Find active sale to undo
    const saleToUndo = targetSaleId 
      ? nextState.salesRegister.find((s) => s.id === targetSaleId && !s.isReversed)
      : nextState.salesRegister.find((s) => !s.isReversed);

    if (!saleToUndo) {
      return { success: false, error: 'No eligible sale found to reverse' };
    }

    const team = nextState.teams.find((t) => t.id === saleToUndo.winningTeamId);
    if (!team) {
      return { success: false, error: 'Associated team not found' };
    }

    const card = nextState.cards.find((c) => c.id === saleToUndo.cardId);

    // 1. Restore team budget exactly once
    team.remainingBudget += saleToUndo.amount;
    team.totalSpent = Math.max(0, team.totalSpent - saleToUndo.amount);

    // 2. Remove acquired card from team portfolio
    team.acquiredCards = team.acquiredCards.filter((ac) => ac.cardId !== saleToUndo.cardId);
    
    // Recalculate category progress
    const remainingInCat = team.acquiredCards.some((ac) => ac.category === saleToUndo.category);
    team.categoryProgress[saleToUndo.category] = remainingInCat;

    // 3. Restore card status
    if (card) {
      card.status = 'AVAILABLE';
    }

    // 4. Mark sale record as reversed
    saleToUndo.isReversed = true;
    saleToUndo.reversedAt = Date.now();

    // 5. If current auction was showing this sale, revert it
    if (nextState.currentAuction.completedSale && nextState.currentAuction.completedSale.cardId === saleToUndo.cardId) {
      nextState.currentAuction.status = 'READY';
      nextState.currentAuction.completedSale = null;
    }

    nextState.auditLogs.unshift({
      id: `log-${Date.now()}-undo`,
      action: 'UNDO_SALE',
      details: `Reversed sale of "${saleToUndo.cardName}" to ${saleToUndo.winningTeamName} (₹${saleToUndo.amount.toLocaleString('en-IN')}). Budget restored.`,
      actor: 'ADMINISTRATOR',
      timestamp: Date.now(),
    });

    this.commitState(nextState);
    return { success: true };
  }

  // --- TEAM MANAGEMENT ---

  /**
   * Add a new team
   */
  public addTeam(params: {
    name: string;
    loginId?: string;
    initialBudget?: number;
    notes?: string;
  }): { success: boolean; team?: Team; plainPassword?: string; error?: string } {
    const nextState = { ...this.state };
    const name = params.name.trim().toUpperCase();
    const loginId = (params.loginId || name).trim().toUpperCase();

    if (!name) {
      return { success: false, error: 'Team name is required' };
    }

    // Check duplicate
    if (nextState.teams.some((t) => t.loginId.toUpperCase() === loginId)) {
      return { success: false, error: `A team with Login ID "${loginId}" already exists` };
    }

    const teamNum = nextState.teams.length + 1;
    const generatedPassword = `CityTeam${teamNum.toString().padStart(2, '0')}!${Math.floor(100 + Math.random() * 900)}`;
    const budget = params.initialBudget || 100_000_000;

    const newTeam: Team = {
      id: `team-${Date.now()}-${teamNum}`,
      name,
      loginId,
      plainPassword: generatedPassword,
      initialBudget: budget,
      totalSpent: 0,
      remainingBudget: budget,
      acquiredCards: [],
      categoryProgress: {
        STAKEHOLDER: false,
        CHALLENGE: false,
        CONSTRAINT: false,
        IMPACT: false,
      },
      isArchived: false,
      notes: params.notes || '',
      createdAt: Date.now(),
    };

    nextState.teams.push(newTeam);

    nextState.auditLogs.unshift({
      id: `log-${Date.now()}-addteam`,
      action: 'ADD_TEAM',
      details: `Added new team "${newTeam.name}" (Login: ${newTeam.loginId}) with initial budget ₹${(budget / 10000000).toFixed(2)} Cr`,
      actor: 'ADMINISTRATOR',
      timestamp: Date.now(),
    });

    this.commitState(nextState);
    return { success: true, team: newTeam, plainPassword: generatedPassword };
  }

  /**
   * Edit team details
   */
  public editTeam(teamId: string, updates: { name?: string; notes?: string }): { success: boolean; error?: string } {
    const nextState = { ...this.state };
    const team = nextState.teams.find((t) => t.id === teamId);
    if (!team) return { success: false, error: 'Team not found' };

    if (updates.name) {
      team.name = updates.name.trim().toUpperCase();
      team.loginId = team.name;
    }
    if (updates.notes !== undefined) {
      team.notes = updates.notes;
    }

    nextState.auditLogs.unshift({
      id: `log-${Date.now()}-editteam`,
      action: 'EDIT_TEAM',
      details: `Updated team details for "${team.name}"`,
      actor: 'ADMINISTRATOR',
      timestamp: Date.now(),
    });

    this.commitState(nextState);
    return { success: true };
  }

  /**
   * Delete or safe archive team
   */
  public deleteOrArchiveTeam(teamId: string): { success: boolean; action: 'DELETED' | 'ARCHIVED'; error?: string } {
    const nextState = { ...this.state };
    const teamIndex = nextState.teams.findIndex((t) => t.id === teamId);
    if (teamIndex === -1) return { success: false, action: 'DELETED', error: 'Team not found' };

    const team = nextState.teams[teamIndex];

    // Check if team has transaction history (bids or sales)
    const hasSales = nextState.salesRegister.some((s) => s.winningTeamId === teamId);
    const hasBids = nextState.bidHistory.some((b) => b.bidderId === teamId);

    if (hasSales || hasBids || team.acquiredCards.length > 0) {
      // Safe Archive to preserve audit trail and financial integrity
      team.isArchived = true;
      nextState.auditLogs.unshift({
        id: `log-${Date.now()}-archteam`,
        action: 'ARCHIVE_TEAM',
        details: `Safely archived team "${team.name}" to preserve audit trail of bids and purchases.`,
        actor: 'ADMINISTRATOR',
        timestamp: Date.now(),
      });
      this.commitState(nextState);
      return { success: true, action: 'ARCHIVED' };
    }

    // Safe deletion if no history
    nextState.teams.splice(teamIndex, 1);
    nextState.auditLogs.unshift({
      id: `log-${Date.now()}-delteam`,
      action: 'DELETE_TEAM',
      details: `Deleted team "${team.name}" (no prior auction history).`,
      actor: 'ADMINISTRATOR',
      timestamp: Date.now(),
    });

    this.commitState(nextState);
    return { success: true, action: 'DELETED' };
  }

  /**
   * Reset password for team
   */
  public resetTeamPassword(teamId: string): { success: boolean; newPassword?: string; error?: string } {
    const nextState = { ...this.state };
    const team = nextState.teams.find((t) => t.id === teamId);
    if (!team) return { success: false, error: 'Team not found' };

    const newPassword = `CityTeam${Math.floor(10 + Math.random() * 90)}!${Math.floor(100 + Math.random() * 900)}`;
    team.plainPassword = newPassword;

    nextState.auditLogs.unshift({
      id: `log-${Date.now()}-resetpwd`,
      action: 'RESET_PASSWORD',
      details: `Generated new secure password for team "${team.name}"`,
      actor: 'ADMINISTRATOR',
      timestamp: Date.now(),
    });

    this.commitState(nextState);
    return { success: true, newPassword };
  }

  // --- BANK CARD MANAGEMENT ---
  /**
   * Edit card details in bank
   */
  public async editCard(
    cardId: string,
    updates: { name: string; category?: Category; sector?: Sector; description?: string },
    adminSecret: string = 'ANEKAL2026'
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await fetch('/api/cards/edit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminSecret,
          Authorization: `Bearer ${adminSecret}`,
        },
        body: JSON.stringify({ cardId, ...updates }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.state) {
          this.state = data.state;
          this.saveToStorage(this.state);
          this.notify();
        }
        return { success: true };
      }
      return { success: false, error: data.error || 'Failed to edit card' };
    } catch (e: any) {
      // Local fallback
      const nextState = { ...this.state };
      const card = nextState.cards.find((c) => c.id === cardId);
      if (!card) return { success: false, error: 'Card not found' };
      const oldName = card.name;
      card.name = updates.name.trim();
      if (updates.description !== undefined) card.description = updates.description.trim();
      if (updates.category) card.category = updates.category;
      if (updates.sector) card.sector = updates.sector;

      if (nextState.currentAuction && nextState.currentAuction.cardId === cardId && nextState.currentAuction.card) {
        nextState.currentAuction.card.name = card.name;
        nextState.currentAuction.card.description = card.description;
        nextState.currentAuction.card.category = card.category;
        nextState.currentAuction.card.sector = card.sector;
      }

      if (Array.isArray(nextState.salesRegister)) {
        nextState.salesRegister.forEach((s) => {
          if (s.cardId === cardId) {
            s.cardName = card.name;
            s.category = card.category;
            s.sector = card.sector;
          }
        });
      }

      if (Array.isArray(nextState.teams)) {
        nextState.teams.forEach((t) => {
          if (Array.isArray(t.acquiredCards)) {
            t.acquiredCards.forEach((ac) => {
              if (ac.cardId === cardId) {
                ac.cardName = card.name;
                ac.category = card.category;
                ac.sector = card.sector;
              }
            });
          }
        });
      }

      nextState.auditLogs.unshift({
        id: `log-${Date.now()}-editcard-local`,
        action: 'EDIT_CARD',
        details: `Card "${card.id}" updated from "${oldName}" to "${card.name}" (${card.category} - ${card.sector}).`,
        actor: 'ADMINISTRATOR',
        timestamp: Date.now(),
      });

      this.commitState(nextState);
      return { success: true };
    }
  }

  /**
   * Add new card to bank
   */
  public async addCard(
    cardData: {
      id?: string;
      name: string;
      category: Category;
      sector: Sector;
      description: string;
    },
    adminSecret: string = 'ANEKAL2026'
  ): Promise<{ success: boolean; card?: Card; error?: string }> {
    try {
      const res = await fetch('/api/cards/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminSecret,
          Authorization: `Bearer ${adminSecret}`,
        },
        body: JSON.stringify(cardData),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.state) {
          this.state = data.state;
          this.saveToStorage(this.state);
          this.notify();
        }
        return { success: true, card: data.card };
      }
      return { success: false, error: data.error || 'Failed to add card' };
    } catch (e: any) {
      // Local fallback
      const nextState = { ...this.state };
      let finalId = (cardData.id || '').trim().toUpperCase();
      if (!finalId) {
        const prefixMap: Record<string, string> = {
          STAKEHOLDER: 'STK',
          CHALLENGE: 'CHL',
          CONSTRAINT: 'CST',
          IMPACT: 'IMP',
        };
        const prefix = prefixMap[cardData.category] || 'CRD';
        let maxNum = 0;
        nextState.cards.forEach((c) => {
          if (c.id && c.id.startsWith(prefix)) {
            const parts = c.id.split('-');
            const n = parseInt(parts[1] || '0', 10);
            if (!isNaN(n) && n > maxNum) maxNum = n;
          }
        });
        finalId = `${prefix}-${String(maxNum + 1).padStart(2, '0')}`;
      }

      if (nextState.cards.some((c) => c.id === finalId)) {
        return { success: false, error: `Card ID "${finalId}" already exists.` };
      }

      const newCard: Card = {
        id: finalId,
        name: cardData.name.trim(),
        category: cardData.category,
        sector: cardData.sector,
        description: (cardData.description || '').trim(),
        status: 'AVAILABLE',
        queueOrder: nextState.cards.length + 1,
      };

      nextState.cards.push(newCard);
      nextState.auctionQueue.push(finalId);
      this.commitState(nextState);
      return { success: true, card: newCard };
    }
  }

  /**
   * Archive or unarchive card
   */
  public async archiveCard(
    cardId: string,
    isArchived: boolean = true,
    adminSecret: string = 'ANEKAL2026'
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await fetch('/api/cards/archive', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminSecret,
          Authorization: `Bearer ${adminSecret}`,
        },
        body: JSON.stringify({ cardId, isArchived }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.state) {
          this.state = data.state;
          this.saveToStorage(this.state);
          this.notify();
        }
        return { success: true };
      }
      return { success: false, error: data.error || 'Failed to archive card' };
    } catch (e: any) {
      const nextState = { ...this.state };
      const card = nextState.cards.find((c) => c.id === cardId);
      if (!card) return { success: false, error: 'Card not found' };
      card.status = isArchived ? 'ARCHIVED' : 'AVAILABLE';
      if (isArchived) {
        nextState.auctionQueue = nextState.auctionQueue.filter((id) => id !== cardId);
      } else if (!nextState.auctionQueue.includes(cardId)) {
        nextState.auctionQueue.push(cardId);
      }
      this.commitState(nextState);
      return { success: true };
    }
  }

  /**
   * Delete card (strictly safe)
   */
  public async deleteCard(
    cardId: string,
    adminSecret: string = 'ANEKAL2026'
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await fetch('/api/cards/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminSecret,
          Authorization: `Bearer ${adminSecret}`,
        },
        body: JSON.stringify({ cardId }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.state) {
          this.state = data.state;
          this.saveToStorage(this.state);
          this.notify();
        }
        return { success: true };
      }
      return { success: false, error: data.error || 'Failed to delete card' };
    } catch (e: any) {
      const nextState = { ...this.state };
      const card = nextState.cards.find((c) => c.id === cardId);
      if (!card) return { success: false, error: 'Card not found' };
      if (card.status === 'SOLD') {
        return { success: false, error: 'Cannot delete card that has already been purchased.' };
      }
      nextState.cards = nextState.cards.filter((c) => c.id !== cardId);
      nextState.auctionQueue = nextState.auctionQueue.filter((id) => id !== cardId);
      this.commitState(nextState);
      return { success: true };
    }
  }

  /**
   * Register Google Email for team
   */
  public async registerTeamEmail(params: {
    teamId: string;
    email: string;
    currentPassword: string;
  }): Promise<{ success: boolean; message?: string; verificationCodeForDev?: string; error?: string }> {
    try {
      const res = await fetch('/api/team/register-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.state) {
          this.state = data.state;
          this.saveToStorage(this.state);
          this.notify();
        }
        return {
          success: true,
          message: data.message,
          verificationCodeForDev: data.verificationCodeForDev,
        };
      }
      return { success: false, error: data.error || 'Failed to register email' };
    } catch (e: any) {
      return { success: false, error: e.message || 'Network error' };
    }
  }

  /**
   * Verify Google Email with 6-digit code
   */
  public async verifyTeamEmail(params: {
    teamId: string;
    code: string;
  }): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await fetch('/api/team/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.state) {
          this.state = data.state;
          this.saveToStorage(this.state);
          this.notify();
        }
        return { success: true, message: data.message };
      }
      return { success: false, error: data.error || 'Verification failed' };
    } catch (e: any) {
      return { success: false, error: e.message || 'Network error' };
    }
  }

  /**
   * Request password reset token
   */
  public async forgotPassword(params: {
    loginId: string;
    email: string;
  }): Promise<{ success: boolean; message?: string; resetToken?: string; error?: string }> {
    try {
      const res = await fetch('/api/team/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        return { success: true, message: data.message, resetToken: data.resetToken };
      }
      return { success: false, error: data.error || 'Failed to process password reset' };
    } catch (e: any) {
      return { success: false, error: e.message || 'Network error' };
    }
  }

  /**
   * Reset team password with token
   */
  public async resetPasswordWithToken(params: {
    loginId: string;
    resetToken: string;
    newPassword: string;
  }): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await fetch('/api/team/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.state) {
          this.state = data.state;
          this.saveToStorage(this.state);
          this.notify();
        }
        return { success: true, message: data.message };
      }
      return { success: false, error: data.error || 'Failed to reset password' };
    } catch (e: any) {
      return { success: false, error: e.message || 'Network error' };
    }
  }

  /**
   * Change team password from Team Dashboard
   */
  public async changeTeamPassword(params: {
    teamId: string;
    currentPassword: string;
    newPassword: string;
  }): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await fetch('/api/team/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.state) {
          this.state = data.state;
          this.saveToStorage(this.state);
          this.notify();
        }
        return { success: true, message: data.message };
      }
      return { success: false, error: data.error || 'Failed to update password' };
    } catch (e: any) {
      return { success: false, error: e.message || 'Network error' };
    }
  }

  // --- EVENT RESET ---
  public async resetAuction(adminSecret: string = 'ANEKAL2026'): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await fetch('/api/auction/reset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminSecret,
          'Authorization': `Bearer ${adminSecret}`,
        },
        body: JSON.stringify({
          adminPassword: adminSecret,
          adminUser: 'ALLIANCEONE2026',
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        if (data.state) {
          this.state = data.state;
          this.saveToStorage(this.state);
          this.notify();
          this.broadcastChannel?.postMessage({
            type: 'STATE_UPDATE',
            state: this.state,
          });
        }
        return { success: true, message: data.message };
      }
      return { success: false, error: data.error || 'Failed to reset auction' };
    } catch (e: any) {
      // Local fallback reset if backend is offline
      const nextState = { ...this.state };
      
      // 1. Archive prior bids & sales history
      if (!Array.isArray((nextState as any).eventArchives)) {
        (nextState as any).eventArchives = [];
      }
      if (nextState.bidHistory.length > 0 || nextState.salesRegister.length > 0) {
        (nextState as any).eventArchives.unshift({
          archivedAt: Date.now(),
          bidCount: nextState.bidHistory.length,
          saleCount: nextState.salesRegister.length,
          bidHistory: [...nextState.bidHistory],
          salesRegister: [...nextState.salesRegister],
        });
      }
      nextState.bidHistory = [];
      nextState.salesRegister = [];

      // 2. Restore cards to available
      nextState.cards.forEach((c) => {
        c.status = 'AVAILABLE';
      });

      // 3. Restore teams
      nextState.teams.forEach((t) => {
        const base = t.initialBudget || 100_000_000;
        t.remainingBudget = base;
        t.totalSpent = 0;
        t.acquiredCards = [];
        t.categoryProgress = {
          STAKEHOLDER: false,
          CHALLENGE: false,
          CONSTRAINT: false,
          IMPACT: false,
        };
      });

      // 4. Regenerate queue
      nextState.auctionQueue = generateSmartQueue(nextState.cards);
      const firstId = nextState.auctionQueue.length > 0 ? nextState.auctionQueue[0] : null;
      const firstCard = firstId ? nextState.cards.find((c) => c.id === firstId) : null;
      if (firstCard) {
        firstCard.status = 'IN_AUCTION';
      }

      // 5. Setup fresh auction
      nextState.currentAuction = {
        cardId: firstId,
        card: firstCard ? { ...firstCard } : null,
        status: 'READY',
        currentBid: OPENING_BID,
        currentBidder: null,
        confirmedFinalBid: null,
        confirmedFinalBidStatus: 'NONE',
        bidCount: 0,
        timerSeconds: INITIAL_TIMER_SECONDS,
        timerDuration: INITIAL_TIMER_SECONDS,
        timerIsRunning: false,
        timerHasExtended: false,
        timerDeadline: null,
        auctionAttemptId: `att-${Date.now()}-${firstId || 'local'}`,
        completedSale: null,
      };

      nextState.auditLogs.unshift({
        id: `log-${Date.now()}-reset`,
        action: 'RESET_AUCTION',
        details: 'Auction reset to fresh starting state by administrator. All card statuses, bids, sales, team portfolios, and ₹10 Cr budgets reset.',
        actor: 'ADMINISTRATOR',
        timestamp: Date.now(),
      });

      this.commitState(nextState);
      return { success: true, message: 'Auction successfully reset to starting baseline.' };
    }
  }

  public resetEvent(): { success: boolean } {
    this.resetAuction();
    return { success: true };
  }
}

export const auctionStore = new AuctionStore();
