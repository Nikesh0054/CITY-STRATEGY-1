/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Card, Category, Sector, Team } from '../types/auction';

// 120 Real Strategy Cards: 30 per Category (10 Mobility, 10 Waste Management, 10 Water Management)
const rawCardsData: Array<{ name: string; category: Category; sector: Sector; description: string }> = [
  // --- STAKEHOLDER CARDS (30) ---
  // Mobility (10)
  { name: 'Metropolitan Transit Authority', category: 'STAKEHOLDER', sector: 'MOBILITY', description: 'Governing body overseeing regional commuter rail, bus rapid transit, and multi-modal transit networks.' },
  { name: 'Suburban Commuter Union', category: 'STAKEHOLDER', sector: 'MOBILITY', description: 'Advocacy group representing daily long-distance commuters demanding affordable last-mile connectivity.' },
  { name: 'Electric Bus Fleet Operators', category: 'STAKEHOLDER', sector: 'MOBILITY', description: 'Private and concessionaire operators running zero-emission electric bus transit lines.' },
  { name: 'Urban Cyclists & Pedestrian League', category: 'STAKEHOLDER', sector: 'MOBILITY', description: 'Grassroots civil coalition pushing for protected micro-mobility lanes and walkable streets.' },
  { name: 'Commercial Freight Logistics Guild', category: 'STAKEHOLDER', sector: 'MOBILITY', description: 'Association of heavy freight, parcel delivery, and port drayage fleet managers.' },
  { name: 'Shared Micro-Mobility Consortium', category: 'STAKEHOLDER', sector: 'MOBILITY', description: 'Consortium of dockless e-bike, scooter, and shared light-electric mobility tech platforms.' },
  { name: 'Traffic Safety & Enforcement Bureau', category: 'STAKEHOLDER', sector: 'MOBILITY', description: 'Law enforcement and municipal traffic management agency responsible for Vision Zero compliance.' },
  { name: 'App-Based Ride-Hail Alliance', category: 'STAKEHOLDER', sector: 'MOBILITY', description: 'On-demand mobility drivers and platform operators lobbying for multi-modal curbside access.' },
  { name: 'Paratransit & Accessibility Council', category: 'STAKEHOLDER', sector: 'MOBILITY', description: 'Specialized transit committee protecting universal access for disabled and elderly citizens.' },
  { name: 'Airport & Intercity Railway Authority', category: 'STAKEHOLDER', sector: 'MOBILITY', description: 'High-speed rail and intermodal terminal authority connecting metropolitan hubs to national corridors.' },

  // Waste Management (10)
  { name: 'Municipal Solid Waste Board', category: 'STAKEHOLDER', sector: 'WASTE MANAGEMENT', description: 'City department directing centralized curbside pickup, transfer stations, and sanitary landfill operations.' },
  { name: 'Informal Waste Collectors Syndicate', category: 'STAKEHOLDER', sector: 'WASTE MANAGEMENT', description: 'Community network of ragpickers, scrap dealers, and informal circular economy workers.' },
  { name: 'Industrial Hazardous Waste Regulators', category: 'STAKEHOLDER', sector: 'WASTE MANAGEMENT', description: 'State pollution control bureau auditing chemical, metallurgical, and e-waste treatment plants.' },
  { name: 'Commercial Packaging & Retail Federation', category: 'STAKEHOLDER', sector: 'WASTE MANAGEMENT', description: 'Alliance of FMCG retailers and packaging manufacturers bound by Extended Producer Responsibility.' },
  { name: 'Biochemical & Medical Waste Operators', category: 'STAKEHOLDER', sector: 'WASTE MANAGEMENT', description: 'Specialized healthcare logistics operators handling pathological, biomedical, and pharmaceutical waste.' },
  { name: 'Civic Composting & Organic Cooperatives', category: 'STAKEHOLDER', sector: 'WASTE MANAGEMENT', description: 'Neighborhood decentralized composting facilities processing organic wet waste into farm compost.' },
  { name: 'Recycling Processing Technology Council', category: 'STAKEHOLDER', sector: 'WASTE MANAGEMENT', description: 'Automated sorting, optical scanner, and mechanical material recovery facility (MRF) operators.' },
  { name: 'Construction & Demolition Debris Recyclers', category: 'STAKEHOLDER', sector: 'WASTE MANAGEMENT', description: 'Heavy civil recyclers processing concrete rubble and masonry into structural aggregate.' },
  { name: 'Resident Welfare Association Federations', category: 'STAKEHOLDER', sector: 'WASTE MANAGEMENT', description: 'Apex federation of residential housing societies enforcing source segregation mandates.' },
  { name: 'Landfill Remediation Engineers Alliance', category: 'STAKEHOLDER', sector: 'WASTE MANAGEMENT', description: 'Biomining and landfill methane recapture engineering teams restoring legacy dump sites.' },

  // Water Management (10)
  { name: 'Metropolitan Water Supply & Sewerage Board', category: 'STAKEHOLDER', sector: 'WATER MANAGEMENT', description: 'Public utility delivering bulk potable water, pressurized mains, and sewage network operations.' },
  { name: 'Groundwater Survey & Protection Agency', category: 'STAKEHOLDER', sector: 'WATER MANAGEMENT', description: 'Hydrogeological board monitoring aquifer drawdowns, borewell permits, and subterranean salinity.' },
  { name: 'River Basin Ecology Conservation Trust', category: 'STAKEHOLDER', sector: 'WATER MANAGEMENT', description: 'Riverfront conservation trust protecting upstream riparian buffers and seasonal wetland ecosystems.' },
  { name: 'Industrial Effluent Treatment Association', category: 'STAKEHOLDER', sector: 'WATER MANAGEMENT', description: 'Collective of manufacturing industrial parks operating Common Effluent Treatment Plants (CETPs).' },
  { name: 'Agricultural Irrigation Canal Federation', category: 'STAKEHOLDER', sector: 'WATER MANAGEMENT', description: 'Peri-urban farming cooperative managing water sharing between urban reservoirs and irrigation canals.' },
  { name: 'Stormwater & Flood Mitigation Command', category: 'STAKEHOLDER', sector: 'WATER MANAGEMENT', description: 'Emergency civil defense engineering group maintaining sluice gates, storm channels, and retention ponds.' },
  { name: 'Commercial Water Tanker Operators Syndicate', category: 'STAKEHOLDER', sector: 'WATER MANAGEMENT', description: 'Private tanker fleet distributing emergency non-revenue water to underserved residential corridors.' },
  { name: 'Slum & Informal Settlement Water Collectives', category: 'STAKEHOLDER', sector: 'WATER MANAGEMENT', description: 'Community leaders managing public water kiosks, shared standpipes, and community sanitation blocks.' },
  { name: 'Desalination & Advanced Filtration Consortium', category: 'STAKEHOLDER', sector: 'WATER MANAGEMENT', description: 'Deep-tech water infrastructure consortium building reverse-osmosis and brackish water plants.' },
  { name: 'Rainwater Harvesting Advisory Council', category: 'STAKEHOLDER', sector: 'WATER MANAGEMENT', description: 'Civil engineering council auditing percolation pits and rooftop recharge compliance in commercial complexes.' },

  // --- CHALLENGE CARDS (30) ---
  // Mobility (10)
  { name: 'Severe Arterial Gridlock & Bottlenecks', category: 'CHALLENGE', sector: 'MOBILITY', description: 'Peak-hour vehicle saturation causing average surface travel speeds to drop below 9 km/h.' },
  { name: 'Critical First & Last Mile Deficits', category: 'CHALLENGE', sector: 'MOBILITY', description: 'Commuters isolated from mass rapid transit hubs due to unsafe sidewalks and missing feeder services.' },
  { name: 'High Particulate Emission from Diesel Fleets', category: 'CHALLENGE', sector: 'MOBILITY', description: 'Dangerous PM2.5 and NOx concentrations along major transport corridors exceeding health guidelines.' },
  { name: 'Fragmented Multi-Agency Ticketing Systems', category: 'CHALLENGE', sector: 'MOBILITY', description: 'Incompatible ticketing formats preventing seamless single-card journeys between metro, bus, and rail.' },
  { name: 'Unregulated Curbside Commercial Parking Chaos', category: 'CHALLENGE', sector: 'MOBILITY', description: 'Illegal street parking consuming 40% of carriageway width on key business arterial avenues.' },
  { name: 'Vulnerable Road User Fatality Rate', category: 'CHALLENGE', sector: 'MOBILITY', description: 'Disproportionately high pedestrian and two-wheeler collision rates at uncontrolled grade intersections.' },
  { name: 'Severe EV Charging Grid Deficits', category: 'CHALLENGE', sector: 'MOBILITY', description: 'Insufficient grid distribution capacity and lack of public fast-charging points for commercial fleets.' },
  { name: 'Aging Rolling Stock & Frequent Signal Failures', category: 'CHALLENGE', sector: 'MOBILITY', description: 'Legacy mechanical signaling causing frequent system shutdowns on prime suburban train corridors.' },
  { name: 'Suburban Job-Housing Spatial Mismatch', category: 'CHALLENGE', sector: 'MOBILITY', description: 'Sprawling residential suburbs lacking localized jobs, forcing 90-minute cross-city commutes.' },
  { name: 'Freight Logistics Urban Sprawl Congestion', category: 'CHALLENGE', sector: 'MOBILITY', description: 'Uncoordinated overnight heavy trucking choking intra-city roads and outer ring highway bypasses.' },

  // Waste Management (10)
  { name: 'Rampant Open Burning of Mixed Municipal Waste', category: 'CHALLENGE', sector: 'WASTE MANAGEMENT', description: 'Illegal burning of trash piles in vacant plots creating toxic dioxins and respiratory hazards.' },
  { name: 'Catastrophic Landfill Slope Instability & Fires', category: 'CHALLENGE', sector: 'WASTE MANAGEMENT', description: 'Overloaded legacy dumpsites suffering spontaneous subsurface fires and catastrophic structural collapses.' },
  { name: 'Low Source-Segregation Compliance in High-Rises', category: 'CHALLENGE', sector: 'WASTE MANAGEMENT', description: 'Over 65% of apartment buildings disposing unsegregated wet and dry waste into shared chutes.' },
  { name: 'Widespread Microplastic Infiltration in Food Chains', category: 'CHALLENGE', sector: 'WASTE MANAGEMENT', description: 'Secondary degradation of single-use polymers contaminating local soil and water runoff.' },
  { name: 'Informal E-Waste Acid Leaching Operations', category: 'CHALLENGE', sector: 'WASTE MANAGEMENT', description: 'Unregulated backyard electronic recycling releasing lead, mercury, and cyanide into urban streams.' },
  { name: 'Overwhelming Wet Organic Food Waste Influx', category: 'CHALLENGE', sector: 'WASTE MANAGEMENT', description: 'Perishable wet waste rotting in transfer bays, overwhelming centralized digestion infrastructure.' },
  { name: 'Hazardous Biomedical Waste Cross-Contamination', category: 'CHALLENGE', sector: 'WASTE MANAGEMENT', description: 'Untreated infectious sharps and pathogen-laden clinical supplies dumped in municipal bins.' },
  { name: 'Illegal Dumping of Construction Concrete Slag', category: 'CHALLENGE', sector: 'WASTE MANAGEMENT', description: 'Midnight dumping of construction rubble obstructing stormwater drains and lake beds.' },
  { name: 'Severe Occupational Hazards for Sanitation Workers', category: 'CHALLENGE', sector: 'WASTE MANAGEMENT', description: 'Sanitation personnel operating without adequate protective gear, leading to chronic respiratory illnesses.' },
  { name: 'Deficit of Local Material Recovery Facilities', category: 'CHALLENGE', sector: 'WASTE MANAGEMENT', description: 'Lack of automated sorting centers forcing recyclables into long-haul inter-state transport.' },

  // Water Management (10)
  { name: 'Critical Subterranean Aquifer Depletion', category: 'CHALLENGE', sector: 'WATER MANAGEMENT', description: 'Deep groundwater water table declining by 3 meters annually due to unmetered commercial extraction.' },
  { name: 'Catastrophic Flash Flooding During Monsoons', category: 'CHALLENGE', sector: 'WATER MANAGEMENT', description: 'Encroached wetlands and concretized catchments inundating arterial expressways and residential basements.' },
  { name: 'High Non-Revenue Water Loss from Pipe Ruptures', category: 'CHALLENGE', sector: 'WATER MANAGEMENT', description: 'Corroded cast-iron mains leaking over 42% of treated potable drinking water into surrounding soil.' },
  { name: 'Raw Industrial Sewage Discharge into Sacred Rivers', category: 'CHALLENGE', sector: 'WATER MANAGEMENT', description: 'Untreated heavy metal and organic sewage contaminating surface water bodies beyond bathing standards.' },
  { name: 'Extreme Summer Water Tanker Price Gouging', category: 'CHALLENGE', sector: 'WATER MANAGEMENT', description: 'Private groundwater cartels tripling delivery tariffs during peak pre-monsoon heatwaves.' },
  { name: 'Severe Saline Water Intrusion in Coastal Wells', category: 'CHALLENGE', sector: 'WATER MANAGEMENT', description: 'Over-pumping in coastal aquifers drawing seawater kilometers inland, ruining borewell drinking water.' },
  { name: 'Eutrophication & Toxic Foam on Urban Lakes', category: 'CHALLENGE', sector: 'WATER MANAGEMENT', description: 'Excess phosphate and detergent inflows triggering explosive algae blooms and flammable toxic lake foam.' },
  { name: 'Intermittent Potable Water Supply Schedules', category: 'CHALLENGE', sector: 'WATER MANAGEMENT', description: 'Citizens receiving municipal tap water for only 2 hours every four days, creating storage stress.' },
  { name: 'Contamination of Drinking Mains from Storm Drains', category: 'CHALLENGE', sector: 'WATER MANAGEMENT', description: 'Negative suction pressure sucking raw sewage into ruptured adjacent drinking supply pipes.' },
  { name: 'Encroachment of Primary Stormwater Canal Arteries', category: 'CHALLENGE', sector: 'WATER MANAGEMENT', description: 'Illegal real estate construction narrowing 30-meter drainage floodways down to 4-meter culverts.' },

  // --- CONSTRAINT CARDS (30) ---
  // Mobility (10)
  { name: 'Exorbitant Land Acquisition Costs for Corridors', category: 'CONSTRAINT', sector: 'MOBILITY', description: 'Eminent domain land acquisition costs consuming up to 60% of total transit expansion capital.' },
  { name: 'Rigid Curfew & Night-Time Construction Limits', category: 'CONSTRAINT', sector: 'MOBILITY', description: 'Stringent residential acoustic ordinances prohibiting heavy machinery operation after 10 PM.' },
  { name: 'Complex Subsurface Utility Line Relocation', category: 'CONSTRAINT', sector: 'MOBILITY', description: 'Unmapped high-voltage power cables, optical fiber, and gas mains obstructing tunnel boring paths.' },
  { name: 'Sovereign Debt Ceilings on Public Infrastructure', category: 'CONSTRAINT', sector: 'MOBILITY', description: 'Statutory municipal borrowing limits blocking issuance of municipal transit bond tranches.' },
  { name: 'Strict Historic Heritage Preservation Easements', category: 'CONSTRAINT', sector: 'MOBILITY', description: 'Archaeological protection buffers prohibiting elevated viaducts within 300 meters of historical monuments.' },
  { name: 'Grid Capacity Caps on Rapid EV Sub-Stations', category: 'CONSTRAINT', sector: 'MOBILITY', description: 'Regional electrical grid unable to supply megawatt-level power at bus depots without new thermal feeds.' },
  { name: 'Public Backlash Over Congestion Pricing Schemes', category: 'CONSTRAINT', sector: 'MOBILITY', description: 'Intense voter resistance and litigation halting implementation of dynamic peak cordon pricing.' },
  { name: 'Long Supply Chain Lead Times for Rail Rolling Stock', category: 'CONSTRAINT', sector: 'MOBILITY', description: 'Global component bottlenecks delaying delivery of automated metro train coaches by 36 months.' },
  { name: 'Complex Interstate Transit Jurisdiction Boundaries', category: 'CONSTRAINT', sector: 'MOBILITY', description: 'Differing motor vehicle tax regimes and permits stalling cross-border bus rapid transit corridors.' },
  { name: 'Monsoon Suspension of Road Surface Works', category: 'CONSTRAINT', sector: 'MOBILITY', description: 'Heavy seasonal precipitation forcing complete stoppage of bituminous road paving for 4 months.' },

  // Waste Management (10)
  { name: 'Extreme NIMBY Resistance to Waste Facility Siting', category: 'CONSTRAINT', sector: 'WASTE MANAGEMENT', description: 'Local communities blocking land acquisition for waste-to-energy and composting facilities.' },
  { name: 'Strict Statutory Bans on Landfill Open Expansion', category: 'CONSTRAINT', sector: 'WASTE MANAGEMENT', description: 'Judicial environmental injunctions shutting down legacy dumping without alternative sites ready.' },
  { name: 'Absence of Verified Secondary Recycled Markets', category: 'CONSTRAINT', sector: 'WASTE MANAGEMENT', description: 'Low market pricing for recycled plastic pellets making mechanical recovery economically unviable.' },
  { name: 'High Moisture Content in Tropical Organic Waste', category: 'CONSTRAINT', sector: 'WASTE MANAGEMENT', description: 'Wet monsoon food waste with over 80% moisture lowering calorific value in incineration boilers.' },
  { name: 'Bureaucratic Delays in Extended Producer Subsidies', category: 'CONSTRAINT', sector: 'WASTE MANAGEMENT', description: 'Centralized EPR portal delays in disbursing recycling credit disbursements to collection centers.' },
  { name: 'Labor Union Resistance to Automated Fleet Tracking', category: 'CONSTRAINT', sector: 'WASTE MANAGEMENT', description: 'Sanitation vehicle driver unions opposing biometric punch-in and telematics GPS route tracking.' },
  { name: 'Lack of Segregated High-Density Storage Warehouses', category: 'CONSTRAINT', sector: 'WASTE MANAGEMENT', description: 'Exorbitant industrial warehouse rents preventing long-term holding of hazardous electronic scrap.' },
  { name: 'Strict Thermal Emission Standards on Incinerators', category: 'CONSTRAINT', sector: 'WASTE MANAGEMENT', description: 'Stringent national dioxin and furan emission caps requiring capital-intensive flue gas scrubbers.' },
  { name: 'Severe Spatial Scarcity in Dense Inner City Wards', category: 'CONSTRAINT', sector: 'WASTE MANAGEMENT', description: 'Zero vacant land parcels available for setting up decentralized ward-level transfer stations.' },
  { name: 'High Capital Capex for Biomining Legacy Dumps', category: 'CONSTRAINT', sector: 'WASTE MANAGEMENT', description: 'Multi-million rupee upfront costs required for trommel screens and bio-remediation enzymes.' },

  // Water Management (10)
  { name: 'Complex Inter-State River Water Sharing Treaties', category: 'CONSTRAINT', sector: 'WATER MANAGEMENT', description: 'Tribunal caps limiting the volume of surface water that can be pumped across state boundaries.' },
  { name: 'Heavy Topographical Pumping Elevation Energy Bills', category: 'CONSTRAINT', sector: 'WATER MANAGEMENT', description: 'City situated 600 meters above river source, consuming 45% of municipal budget on lift pump power.' },
  { name: 'Extensive Concretization of Natural Aquifer Catchments', category: 'CONSTRAINT', sector: 'WATER MANAGEMENT', description: 'Impervious urban concrete cover preventing natural monsoon percolation into underlying bedrock.' },
  { name: 'High Capex Requirements for Desalination Plants', category: 'CONSTRAINT', sector: 'WATER MANAGEMENT', description: 'Capital intensive marine intake pipelines and energy-heavy brine reject management overheads.' },
  { name: 'Absence of Digital Bulk Water Metering Systems', category: 'CONSTRAINT', sector: 'WATER MANAGEMENT', description: 'Unmetered shared tap connections preventing volumetric pricing and leak detection algorithms.' },
  { name: 'Severe Contamination of Urban Groundwater Veins', category: 'CONSTRAINT', sector: 'WATER MANAGEMENT', description: 'Industrial fluoride, nitrate, and heavy metal plumes rendering shallow wells biologically unsafe.' },
  { name: 'Judicial Moratoriums on Construction in Lake Buffer Zones', category: 'CONSTRAINT', sector: 'WATER MANAGEMENT', description: 'Green tribunal orders halting all pipeline laying within 75 meters of declared wetland edges.' },
  { name: 'Seasonal Reliance on Unpredictable Monsoon Rains', category: 'CONSTRAINT', sector: 'WATER MANAGEMENT', description: 'Extreme climate variability swinging between multi-year drought and catastrophic single-day downpours.' },
  { name: 'Public Aversion to Treated Wastewater Potable Reuse', category: 'CONSTRAINT', sector: 'WATER MANAGEMENT', description: 'Cultural resistance prohibiting direct potable reuse of tertiary-treated sewage effluent.' },
  { name: 'Prohibitive Costs of Digging Up Dense City Streets', category: 'CONSTRAINT', sector: 'WATER MANAGEMENT', description: 'High road reinstatement charges making replacement of leaking subterranean cast-iron pipes infeasible.' },

  // --- IMPACT CARDS (30) ---
  // Mobility (10)
  { name: '35% Modal Shift to Low-Emission Mass Transit', category: 'IMPACT', sector: 'MOBILITY', description: 'Massive transition from personal vehicles to integrated transit, freeing up 200,000 passenger road hours.' },
  { name: '50% Cut in Corridor Particulate Air Pollution', category: 'IMPACT', sector: 'MOBILITY', description: 'Fleet electrification leading to measurable reductions in PM2.5 and childhood asthma admissions.' },
  { name: 'Zero Pedestrian Fatalities on Vision-Zero Boulevards', category: 'IMPACT', sector: 'MOBILITY', description: 'Traffic-calmed streets and grade-separated crossings achieving zero pedestrian fatalities in audited zones.' },
  { name: '90% Population Within 500m of Rapid Transit', category: 'IMPACT', sector: 'MOBILITY', description: 'Equitable transit-oriented zoning bringing high-capacity mass transit within walking distance for all wards.' },
  { name: 'Full Inter-Modal Single-Card Transit Integration', category: 'IMPACT', sector: 'MOBILITY', description: 'Unified open-mobility mobility ticketing cutting passenger interchange wait times by 65%.' },
  { name: 'Economic Revival of Pedestrianized Market Quarters', category: 'IMPACT', sector: 'MOBILITY', description: 'Car-free commercial avenues experiencing 45% growth in footfalls and retail sales volume.' },
  { name: 'Decarbonization of Commercial Intra-City Logistics', category: 'IMPACT', sector: 'MOBILITY', description: 'Overnight electric cargo hubs eliminating 1,500 heavy diesel truck trips from inner city streets.' },
  { name: 'Dynamic Curbside Monetization & Revenue Generation', category: 'IMPACT', sector: 'MOBILITY', description: 'Smart parking sensor networks transforming congested curbs into self-funding municipal infrastructure.' },
  { name: 'Expanded Paratransit Coverage for Marginalized Zones', category: 'IMPACT', sector: 'MOBILITY', description: 'On-demand accessible shuttle networks delivering dignity and transit access to low-income suburbs.' },
  { name: 'Resilient Evacuation Transit Grid During Emergencies', category: 'IMPACT', sector: 'MOBILITY', description: 'Intelligent traffic signal priority routing emergency services in under 7 minutes during severe crises.' },

  // Waste Management (10)
  { name: '80% Diversion of Organic Waste from Open Landfills', category: 'IMPACT', sector: 'WASTE MANAGEMENT', description: 'Decentralized biomethanation generating renewable bio-CNG and nutrient-rich organic farm fertilizers.' },
  { name: 'Extinction of Subsurface Landfill Fires & Methane Leak', category: 'IMPACT', sector: 'WASTE MANAGEMENT', description: 'Complete capping and biomining of dump mounds eliminating toxic smoke and 50,000 tons of CO2e.' },
  { name: 'Formalized Dignity & Healthcare for 15,000 Waste Pickers', category: 'IMPACT', sector: 'WASTE MANAGEMENT', description: 'Micro-enterprises providing safety gear, fair minimum wages, and insurance to frontline recyclers.' },
  { name: '95% Segregation Compliance Across Commercial Districts', category: 'IMPACT', sector: 'WASTE MANAGEMENT', description: 'Strict source separation resulting in ultra-clean recyclables commanding top-tier resale values.' },
  { name: 'Zero Industrial Hazardous Slag Discharge into Waterways', category: 'IMPACT', sector: 'WASTE MANAGEMENT', description: 'Closed-loop toxic effluent recycling eliminating hazardous heavy metal discharge from manufacturing.' },
  { name: 'High-Strength Upcycled Aggregate for Municipal Paving', category: 'IMPACT', sector: 'WASTE MANAGEMENT', description: '100% of construction and demolition rubble crushed into high-grade paver blocks and road sub-bases.' },
  { name: 'Closed-Loop Circular Economy for Rigid Plastics', category: 'IMPACT', sector: 'WASTE MANAGEMENT', description: 'Packaging manufacturers sourcing 60% food-grade post-consumer resin from verified local MRFs.' },
  { name: 'Elimination of Chronic Open-Air Street Garbage Dumps', category: 'IMPACT', sector: 'WASTE MANAGEMENT', description: 'Mechanized collection transforming former open trash dumping sites into vibrant pocket gardens.' },
  { name: 'Self-Sustaining Waste-to-Energy Green Micro-Grids', category: 'IMPACT', sector: 'WASTE MANAGEMENT', description: 'Advanced thermal processing supplying clean baseload electrical power to municipal wastewater plants.' },
  { name: 'Radical Reduction of Microplastic Infiltration into Bay', category: 'IMPACT', sector: 'WASTE MANAGEMENT', description: 'Advanced storm-drain trash traps capturing 400 tons of plastic debris before it reaches the sea.' },

  // Water Management (10)
  { name: '24/7 Continuous Pressurized Potable Tap Water Access', category: 'IMPACT', sector: 'WATER MANAGEMENT', description: 'Elimination of intermittent water rationing, providing clean drinkable tap water to all households.' },
  { name: 'Reduction of Non-Revenue Water Losses Below 12%', category: 'IMPACT', sector: 'WATER MANAGEMENT', description: 'Acoustic leak detection and smart telemetry saving 120 million liters of treated drinking water daily.' },
  { name: 'Restoration of Natural Sponginess & Zero Flash Floods', category: 'IMPACT', sector: 'WATER MANAGEMENT', description: 'Wetland re-engineering absorbing 100mm/hr cloudbursts with zero flooding in low-lying residential sectors.' },
  { name: 'Complete Recharge & Stabilization of Water Table', category: 'IMPACT', sector: 'WATER MANAGEMENT', description: 'City-wide injection wells raising deep groundwater aquifers by an average of 4.5 meters in 3 years.' },
  { name: 'Revival of Urban Lakes into Vibrant Ecological Parks', category: 'IMPACT', sector: 'WATER MANAGEMENT', description: 'Bioremediation transforming putrid foam-covered lakes into biodiverse public recreation bird reserves.' },
  { name: 'Affordable Public Water Security Ending Tanker Exploitation', category: 'IMPACT', sector: 'WATER MANAGEMENT', description: 'Municipal sensor kiosks delivering subsidized water, breaking the monopoly of private tanker cartels.' },
  { name: '100% Tertiary Treatment & Industrial Water Recycling', category: 'IMPACT', sector: 'WATER MANAGEMENT', description: 'Power plants and industrial zones running exclusively on recycled wastewater, saving river reserves.' },
  { name: 'Zero Water-Borne Epidemics in Dense Urban Clusters', category: 'IMPACT', sector: 'WATER MANAGEMENT', description: 'Ultraviolet disinfection and positive-pressure distribution eliminating typhoid and cholera outbreaks.' },
  { name: 'Desalination Supply Guaranteeing Drought Immunity', category: 'IMPACT', sector: 'WATER MANAGEMENT', description: 'Energy-efficient desalination providing an unbreakable base water supply irrespective of monsoon deficits.' },
  { name: 'Democratic Participatory Ward-Level Water Budgets', category: 'IMPACT', sector: 'WATER MANAGEMENT', description: 'Citizen-led water committees auditing monthly water consumption and equitable pressure distribution.' },
];

/**
 * Builds the initial 120 cards with unique sequential IDs
 */
export function buildInitialCards(): Card[] {
  return rawCardsData.map((raw, idx) => ({
    id: `card-${(idx + 1).toString().padStart(3, '0')}`,
    name: raw.name,
    category: raw.category,
    sector: raw.sector,
    description: raw.description,
    status: 'AVAILABLE',
    queueOrder: idx + 1,
  }));
}

/**
 * Generates an initial sequence respecting the strict category sequence:
 * Stakeholder -> Challenge -> Constraint -> Impact
 * 
 * Within each category:
 * - Shuffles cards within their category
 * - Mixes sectors (Mobility, Waste Management, Water Management)
 * - Avoids consecutive cards from the same sector whenever possible
 */
export function generateSmartQueue(cards: Card[]): string[] {
  const categoryOrder: Category[] = ['STAKEHOLDER', 'CHALLENGE', 'CONSTRAINT', 'IMPACT'];
  const finalQueue: string[] = [];

  for (const cat of categoryOrder) {
    const catCards = cards.filter((c) => c.category === cat && c.status === 'AVAILABLE');
    
    // Group by sector
    const mobility = catCards.filter((c) => c.sector === 'MOBILITY');
    const waste = catCards.filter((c) => c.sector === 'WASTE MANAGEMENT');
    const water = catCards.filter((c) => c.sector === 'WATER MANAGEMENT');

    // Shuffle each sector bucket
    const shuffleArray = <T>(arr: T[]): T[] => {
      const copy = [...arr];
      for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
      }
      return copy;
    };

    const sMob = shuffleArray(mobility);
    const sWaste = shuffleArray(waste);
    const sWater = shuffleArray(water);

    // Interleave sectors to avoid consecutive same sector
    const interleaved: Card[] = [];
    const maxLen = Math.max(sMob.length, sWaste.length, sWater.length);

    for (let i = 0; i < maxLen; i++) {
      if (i < sMob.length) interleaved.push(sMob[i]);
      if (i < sWaste.length) interleaved.push(sWaste[i]);
      if (i < sWater.length) interleaved.push(sWater[i]);
    }

    // Append to final queue
    for (const card of interleaved) {
      finalQueue.push(card.id);
    }
  }

  return finalQueue;
}

// Generate the initial 30 teams: TEAM 1 through TEAM 30
export function buildInitialTeams(): Team[] {
  const teams: Team[] = [];
  const baseBudget = 100_000_000; // ₹10 Crore

  for (let i = 1; i <= 30; i++) {
    // Team User ID: TEAM1 through TEAM30 (no spaces)
    // Password: 5-character numeric string with leading zeros ("00001" to "00030")
    const defaultPassword = i.toString().padStart(5, '0');
    teams.push({
      id: `team-${i}`,
      name: `TEAM ${i}`,
      loginId: `TEAM${i}`,
      plainPassword: defaultPassword,
      initialBudget: baseBudget,
      totalSpent: 0,
      remainingBudget: baseBudget,
      acquiredCards: [],
      categoryProgress: {
        STAKEHOLDER: false,
        CHALLENGE: false,
        CONSTRAINT: false,
        IMPACT: false,
      },
      isArchived: false,
      createdAt: Date.now(),
      notes: `Official tournament participant ${i}`,
    });
  }

  return teams;
}
