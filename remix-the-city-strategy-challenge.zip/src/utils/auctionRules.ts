/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Category, Team } from '../types/auction';

export const CATEGORY_SEQUENCE: Category[] = [
  'STAKEHOLDER',
  'CHALLENGE',
  'CONSTRAINT',
  'IMPACT',
];

export const OPENING_BID = 1_000_000; // ₹10 Lakh
export const INITIAL_TIMER_SECONDS = 60;
export const EXTENSION_THRESHOLD_SECONDS = 10;
export const EXTENSION_DURATION_SECONDS = 20;

/**
 * Calculates the next minimum bid according to the official rules:
 * - Opening bid: ₹10 lakh
 * - Below ₹1 crore: ₹10 lakh increments
 * - At or above ₹1 crore: ₹20 lakh increments
 * - At exactly ₹1 crore: next is ₹1.20 crore
 */
export function getNextMinimumBid(currentBid: number, bidCount?: number): number {
  if (bidCount === 0) {
    return OPENING_BID;
  }
  if (!currentBid || currentBid < OPENING_BID) {
    return OPENING_BID;
  }
  if (currentBid < 10_000_000) {
    return currentBid + 1_000_000;
  }
  return currentBid + 2_000_000;
}

/**
 * Calculates the decrement according to official rules (used by minus button)
 */
export function getPreviousBid(amount: number, floorAmount: number = OPENING_BID): number {
  if (amount <= floorAmount) {
    return floorAmount;
  }
  let step = 1_000_000;
  if (amount > 10_000_000) {
    step = 2_000_000;
  } else if (amount === 10_000_000) {
    step = 1_000_000;
  }
  const result = amount - step;
  return Math.max(floorAmount, result);
}

/**
 * Validates if an entered bid amount is valid
 */
export function validateBidAmount(amount: number, currentBid: number, bidCount?: number): { valid: boolean; error?: string } {
  if (isNaN(amount) || amount <= 0) {
    return { valid: false, error: 'Please enter a valid positive amount.' };
  }
  if (amount < OPENING_BID) {
    return { valid: false, error: 'Bid amount cannot be below opening bid of ₹10 Lakh.' };
  }
  if (bidCount === 0) {
    if (amount < OPENING_BID) {
      return { valid: false, error: 'Opening bid must be at least ₹10 Lakh.' };
    }
  } else if (currentBid > 0 && amount <= currentBid) {
    return { valid: false, error: `Bid amount must be strictly greater than current bid (₹${currentBid.toLocaleString('en-IN')}).` };
  }
  // Validate increments
  if (amount < 10_000_000) {
    if (amount % 1_000_000 !== 0) {
      return { valid: false, error: 'Amounts below ₹1 Crore must be in increments of ₹10 Lakh.' };
    }
  } else {
    // 1 Crore and above
    const overOneCrore = amount - 10_000_000;
    if (overOneCrore % 2_000_000 !== 0) {
      return { valid: false, error: 'Amounts of ₹1 Crore and above must be in increments of ₹20 Lakh.' };
    }
  }

  return { valid: true };
}

/**
 * Checks if a team is eligible to purchase a card in a given category
 */
export function checkTeamEligibility(
  team: Team,
  category: Category,
  requiredAmount?: number
): { eligible: boolean; reason?: string } {
  if (team.isArchived) {
    return { eligible: false, reason: 'Team is archived/inactive' };
  }

  // Check 4 categories filled
  const totalWon = team.acquiredCards?.length || 0;
  if (totalWon >= 4) {
    return { eligible: false, reason: 'Team has already acquired all 4 categories' };
  }

  // Check category already acquired
  if (team.categoryProgress && team.categoryProgress[category]) {
    return { eligible: false, reason: `Team already owns a ${category} card` };
  }

  // Check budget if requiredAmount provided
  if (requiredAmount !== undefined && requiredAmount > 0) {
    if (team.remainingBudget < requiredAmount) {
      return { eligible: false, reason: `Insufficient budget (Remaining: ₹${(team.remainingBudget / 100000).toFixed(1)}L, Required: ₹${(requiredAmount / 100000).toFixed(1)}L)` };
    }
  }

  return { eligible: true };
}
