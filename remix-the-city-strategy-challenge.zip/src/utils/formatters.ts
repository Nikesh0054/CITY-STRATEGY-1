/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Format numbers using Indian numbering system (lakhs & crores)
 * e.g., 1000000 -> "₹10,00,000"
 */
export function formatRupees(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined) {
    return '₹0';
  }

  const isNegative = amount < 0;
  const absAmount = Math.abs(Math.round(amount));
  const s = absAmount.toString();
  
  if (s.length <= 3) {
    return (isNegative ? '-₹' : '₹') + s;
  }
  
  const lastThree = s.substring(s.length - 3);
  const otherNumbers = s.substring(0, s.length - 3);
  const formattedOther = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  
  return (isNegative ? '-₹' : '₹') + formattedOther + ',' + lastThree;
}

/**
 * Formats amount into clean Indian spoken denominations (e.g., ₹10.00 Lakh, ₹1.20 Crore)
 */
export function formatRupeesWords(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined || amount === 0) {
    return '₹0';
  }

  const isNegative = amount < 0;
  const abs = Math.abs(amount);

  if (abs >= 10_000_000) {
    const crores = abs / 10_000_000;
    const formatted = crores % 1 === 0 ? crores.toFixed(0) : crores.toFixed(2);
    return `${isNegative ? '-' : ''}₹${formatted} Crore`;
  }

  if (abs >= 100_000) {
    const lakhs = abs / 100_000;
    const formatted = lakhs % 1 === 0 ? lakhs.toFixed(0) : lakhs.toFixed(2);
    return `${isNegative ? '-' : ''}₹${formatted} Lakh`;
  }

  if (abs >= 1_000) {
    const thousands = abs / 1_000;
    const formatted = thousands % 1 === 0 ? thousands.toFixed(0) : thousands.toFixed(1);
    return `${isNegative ? '-' : ''}₹${formatted} Thousand`;
  }

  return formatRupees(amount);
}

/**
 * Seconds to MM:SS string
 */
export function formatTimer(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds));
  const mins = Math.floor(s / 60);
  const remSecs = s % 60;
  return `${mins.toString().padStart(2, '0')}:${remSecs.toString().padStart(2, '0')}`;
}

/**
 * Timestamp to formatted time
 */
export function formatTime(timestamp: number): string {
  if (!timestamp) return '--:--';
  const d = new Date(timestamp);
  return d.toLocaleTimeString('en-IN', {
    hour12: true,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

/**
 * Timestamp to formatted date & time
 */
export function formatDateTime(timestamp: number): string {
  if (!timestamp) return '--';
  const d = new Date(timestamp);
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour12: true,
    hour: '2-digit',
    minute: '2-digit',
  });
}
