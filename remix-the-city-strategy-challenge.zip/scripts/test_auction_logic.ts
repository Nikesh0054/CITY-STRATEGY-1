/**
 * Automated test verification script for The City Strategy Challenge
 */

import { getNextMinimumBid, getPreviousBid, validateBidAmount, checkTeamEligibility, OPENING_BID } from '../src/utils/auctionRules';
import { createDefaultState } from '../src/services/auctionStore';

console.log('--- STARTING VERIFICATION TESTS ---');

// Test 1: Increment rules
let passCount = 0;
let testCount = 0;

function assert(condition: boolean, msg: string) {
  testCount++;
  if (condition) {
    console.log(`[PASS] ${msg}`);
    passCount++;
  } else {
    console.error(`[FAIL] ${msg}`);
    process.exit(1);
  }
}

// 1. Opening bid
assert(getNextMinimumBid(0) === 1_000_000, 'Opening bid is ₹10 Lakh');
assert(getNextMinimumBid(1_000_000) === 2_000_000, '₹10L + ₹10L increment = ₹20L');
assert(getNextMinimumBid(9_000_000) === 10_000_000, '₹90L + ₹10L increment = ₹1 Cr');
assert(getNextMinimumBid(10_000_000) === 12_000_000, 'At exactly ₹1 Cr, next increment is ₹20L -> ₹1.20 Cr');
assert(getNextMinimumBid(12_000_000) === 14_000_000, '₹1.20 Cr + ₹20L increment = ₹1.40 Cr');

// 2. Decrement rules
assert(getPreviousBid(12_000_000) === 10_000_000, '₹1.20 Cr - ₹20L = ₹1 Cr');
assert(getPreviousBid(10_000_000) === 9_000_000, '₹1 Cr - ₹10L = ₹90 Lakh');
assert(getPreviousBid(1_000_000) === 1_000_000, 'Cannot decrement below opening bid');

// 3. Bid amount validation
assert(validateBidAmount(1_000_000, 0).valid, 'Valid opening bid');
assert(!validateBidAmount(1_500_000, 0).valid, 'Invalid intermediate increment below 1 Cr');
assert(validateBidAmount(12_000_000, 10_000_000).valid, 'Valid ₹1.20 Cr bid over ₹1.00 Cr');
assert(!validateBidAmount(11_000_000, 10_000_000).valid, 'Invalid ₹1.10 Cr bid (must be 20L step at >= 1 Cr)');

// 4. Default State & Initial Teams
const state = createDefaultState();
assert(state.teams.length === 30, 'Contains 30 initial teams');
assert(state.cards.length === 120, 'Contains 120 authentic strategy cards');
assert(state.teams[0].initialBudget === 100_000_000, 'TEAM 1 has ₹10.00 Cr starting budget');
assert(state.teams[0].remainingBudget === 100_000_000, 'TEAM 1 has ₹10.00 Cr remaining budget');
assert(state.teams[0].totalSpent === 0, 'TEAM 1 has 0 expenditure');

// 5. Team Category Eligibility
const team1 = state.teams[0];
const el1 = checkTeamEligibility(team1, 'STAKEHOLDER', 1_000_000);
assert(el1.eligible, 'Team 1 is initially eligible for STAKEHOLDER');

// Simulate acquisition
team1.acquiredCards.push({
  cardId: 'card-001',
  cardName: 'Metropolitan Transit Authority',
  category: 'STAKEHOLDER',
  sector: 'MOBILITY',
  amount: 6_000_000, // ₹60 Lakh
  timestamp: Date.now(),
  attemptId: 'att-1',
});
team1.categoryProgress.STAKEHOLDER = true;
team1.totalSpent += 6_000_000;
team1.remainingBudget -= 6_000_000;

assert(team1.remainingBudget === 94_000_000, 'Budget after ₹60L purchase is ₹9.40 Cr');
assert(team1.totalSpent === 6_000_000, 'Total spent after purchase is ₹60L');

const el2 = checkTeamEligibility(team1, 'STAKEHOLDER', 1_000_000);
assert(!el2.eligible && Boolean(el2.reason?.includes('already owns')), 'Cannot buy second card in same category');

const el3 = checkTeamEligibility(team1, 'CHALLENGE', 1_000_000);
assert(el3.eligible, 'Eligible for CHALLENGE category');

// Test 6: Reversal / Undo calculation
team1.remainingBudget += 6_000_000;
team1.totalSpent -= 6_000_000;
team1.acquiredCards.pop();
team1.categoryProgress.STAKEHOLDER = false;

assert(team1.remainingBudget === 100_000_000, 'Budget restored to ₹10 Cr after undo');
assert(team1.totalSpent === 0, 'Total spent restored to 0 after undo');
assert(Boolean(checkTeamEligibility(team1, 'STAKEHOLDER', 1_000_000).eligible), 'STAKEHOLDER category re-eligible after undo');

// Test 7: Verify all 30 team credentials (TEAM1 - TEAM30, 00001 - 00030)
for (let i = 1; i <= 30; i++) {
  const team = state.teams.find((t) => t.id === `team-${i}`);
  assert(team !== undefined, `Team ${i} exists`);
  assert(team?.loginId === `TEAM${i}`, `Team ${i} user ID is TEAM${i}`);
  const expectedPassword = i.toString().padStart(5, '0');
  assert(team?.plainPassword === expectedPassword, `Team ${i} password is "${expectedPassword}" (5-char string with leading zeros)`);
}

// Test leading zero preservation
assert(state.teams[0].plainPassword === '00001', 'TEAM1 password strictly preserves leading zeros as string "00001"');
assert(state.teams[0].plainPassword !== '1', 'TEAM1 password is not numeric 1');
assert(state.teams[8].plainPassword === '00009', 'TEAM9 password is "00009"');
assert(state.teams[9].plainPassword === '00010', 'TEAM10 password is "00010"');
assert(state.teams[29].plainPassword === '00030', 'TEAM30 password is "00030"');

console.log(`\nALL ${passCount}/${testCount} AUTOMATED LOGIC TESTS PASSED SUCCESSFULLY!`);
