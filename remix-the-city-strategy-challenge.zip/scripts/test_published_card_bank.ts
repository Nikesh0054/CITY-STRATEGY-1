/**
 * Verification of Card Bank Management in Production / Published Build Environment
 * Tests routing (/admin, /admin?tab=cards, /card-bank, /api/cards),
 * 120 cards across all 4 categories, editing card name & description,
 * persistence across page refresh, and security permissions.
 */

const BASE_URL = 'http://localhost:3000';
const ADMIN_KEY = 'ANEKAL2026';

let passed = 0;
let total = 0;

function assert(cond: boolean, msg: string) {
  total++;
  if (!cond) {
    console.error(`❌ FAILED: ${msg}`);
    throw new Error(`Assertion failed: ${msg}`);
  }
  passed++;
  console.log(`✅ PASSED: ${msg}`);
}

async function run() {
  console.log('🚀 Running Published / Production Card Bank Verification Suite...\n');

  // 1. Static asset & SPA routing verification
  console.log('--- Test 1: Production SPA Routes & API Protection ---');
  const homeRes = await fetch(`${BASE_URL}/`);
  assert(homeRes.ok, 'Home route (/) responds HTTP 200');
  const homeHtml = await homeRes.text();
  assert(homeHtml.includes('The City Strategy Challenge'), 'HTML contains application title');

  const adminRouteRes = await fetch(`${BASE_URL}/admin`);
  assert(adminRouteRes.ok, '/admin route responds HTTP 200');

  const cardBankRouteRes = await fetch(`${BASE_URL}/card-bank`);
  assert(cardBankRouteRes.ok, '/card-bank route responds HTTP 200 for direct URL navigation');

  const adminCardsRouteRes = await fetch(`${BASE_URL}/admin/cards`);
  assert(adminCardsRouteRes.ok, '/admin/cards route responds HTTP 200');

  // Verify non-existent API returns 404 JSON, not HTML
  const badApiRes = await fetch(`${BASE_URL}/api/non-existent-endpoint`);
  assert(badApiRes.status === 404, 'Invalid API returns HTTP 404');
  const badApiJson = await badApiRes.json();
  assert(badApiJson.error !== undefined, 'Invalid API returns JSON error, not HTML');

  // 2. Fetch all cards via GET /api/cards
  console.log('\n--- Test 2: Card Bank 120 Cards (30/category) Verification ---');
  const cardsRes = await fetch(`${BASE_URL}/api/cards`);
  assert(cardsRes.ok, 'GET /api/cards responds HTTP 200');
  const cardsData = await cardsRes.json();
  assert(cardsData.success === true, 'cardsData.success is true');
  assert(Array.isArray(cardsData.cards), 'cards is an array');
  assert(cardsData.cards.length >= 120, `Card count is at least 120 (found: ${cardsData.cards.length})`);

  const stakeholders = cardsData.cards.filter((c: any) => c.category === 'STAKEHOLDER');
  const challenges = cardsData.cards.filter((c: any) => c.category === 'CHALLENGE');
  const constraints = cardsData.cards.filter((c: any) => c.category === 'CONSTRAINT');
  const impacts = cardsData.cards.filter((c: any) => c.category === 'IMPACT');

  console.log(`Category breakdown: Stakeholders: ${stakeholders.length}, Challenges: ${challenges.length}, Constraints: ${constraints.length}, Impacts: ${impacts.length}`);
  assert(stakeholders.length === 30, 'Exactly 30 Stakeholder cards present');
  assert(challenges.length === 30, 'Exactly 30 Challenge cards present');
  assert(constraints.length === 30, 'Exactly 30 Constraint cards present');
  assert(impacts.length === 30, 'Exactly 30 Impact cards present');

  // 3. Edit card verification with persistence across reload
  console.log('\n--- Test 3: Card Editing & Persistence Across Refresh ---');
  const testCard = stakeholders[0];
  const originalName = testCard.name;
  const originalDesc = testCard.description;
  const newName = `${originalName} [Verified Edit]`;
  const newDesc = 'Verified updated strategic description for published release.';

  // Attempt edit without admin key (should fail)
  const unauthorizedEdit = await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      cardId: testCard.id,
      name: newName,
    }),
  });
  assert(unauthorizedEdit.status === 403, 'Unauthorized card edit rejected with HTTP 403');

  // Perform authorized edit
  const authorizedEdit = await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-admin-key': ADMIN_KEY,
    },
    body: JSON.stringify({
      cardId: testCard.id,
      name: newName,
      category: testCard.category,
      sector: testCard.sector,
      description: newDesc,
    }),
  });
  assert(authorizedEdit.ok, 'Authorized card edit succeeded');
  const authEditJson = await authorizedEdit.json();
  assert(authEditJson.success === true, 'authEditJson.success is true');
  assert(authEditJson.card.name === newName, 'Card name was updated');
  assert(authEditJson.card.id === testCard.id, 'Card ID was preserved');

  // Simulate page refresh by querying /api/auction/state
  const refreshRes = await fetch(`${BASE_URL}/api/auction/state`);
  const refreshJson = await refreshRes.json();
  const refreshState = refreshJson.state || refreshJson;
  const refreshedCard = refreshState.cards.find((c: any) => c.id === testCard.id);
  assert(refreshedCard.name === newName, 'Edited card name persists after state refresh');
  assert(refreshedCard.description === newDesc, 'Edited card description persists after state refresh');
  assert(refreshState.cards.length === 120, 'Total card count remains exactly 120 (no duplicates)');

  // Restore original card data
  const restoreEdit = await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-admin-key': ADMIN_KEY,
    },
    body: JSON.stringify({
      cardId: testCard.id,
      name: originalName,
      category: testCard.category,
      sector: testCard.sector,
      description: originalDesc,
    }),
  });
  assert(restoreEdit.ok, 'Restored card to original data');

  console.log(`\n🎉 ALL ${passed}/${total} PUBLISHED CARD BANK VERIFICATION CHECKS PASSED CLEANLY!`);
}

run().catch((err) => {
  console.error('\n❌ Test suite failed:', err);
  process.exit(1);
});
