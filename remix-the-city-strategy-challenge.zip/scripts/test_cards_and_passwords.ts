/**
 * Comprehensive verification of Bank Card Management and Team Password Management
 */

const BASE_URL = 'http://127.0.0.1:3000';

async function runTests() {
  console.log('=== STARTING CSC BANK CARD & PASSWORD VERIFICATION SUITE ===\n');
  let passCount = 0;
  let failCount = 0;

  function assert(condition: boolean, msg: string) {
    if (condition) {
      console.log(`[PASS] ${msg}`);
      passCount++;
    } else {
      console.error(`[FAIL] ${msg}`);
      failCount++;
    }
  }

  // 1. Fetch initial state
  const stateRes = await fetch(`${BASE_URL}/api/auction/state`);
  const { state } = await stateRes.json();
  assert(state && state.cards && state.cards.length === 120, 'State contains exactly 120 cards');

  // Verify category counts
  const catCounts: Record<string, number> = {};
  for (const c of state.cards) {
    catCounts[c.category] = (catCounts[c.category] || 0) + 1;
  }
  assert(catCounts['STAKEHOLDER'] === 30, '30 Stakeholder cards present');
  assert(catCounts['CHALLENGE'] === 30, '30 Challenge cards present');
  assert(catCounts['CONSTRAINT'] === 30, '30 Constraint cards present');
  assert(catCounts['IMPACT'] === 30, '30 Impact cards present');

  // 2. Bank Card Editing Test (Edit 1 card in each category)
  // Load card-001 into auction so live auction sync can be tested
  await fetch(`${BASE_URL}/api/auction/load-card`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cardId: 'card-001' }),
  });

  // Edit Stakeholder
  const editRes1 = await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-admin-key': 'ANEKAL2026' },
    body: JSON.stringify({
      cardId: 'card-001',
      name: 'Metropolitan Transit Authority (Strategic Revamp)',
      category: 'STAKEHOLDER',
      sector: 'MOBILITY',
      description: 'Regional transit authority governing commuter rail and BRT multi-modal corridors.',
    }),
  });
  const editData1 = await editRes1.json();
  assert(editRes1.ok && editData1.success, 'Stakeholder card (card-001) edited successfully');
  assert(
    editData1.state.currentAuction.card.name === 'Metropolitan Transit Authority (Strategic Revamp)',
    'Live Auction currentAuction.card synchronized with edited card title immediately'
  );

  // Edit Challenge card (e.g. card-031)
  const editRes2 = await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-admin-key': 'ANEKAL2026' },
    body: JSON.stringify({
      cardId: 'card-031',
      name: 'Severe Arterial Gridlock & Rapid Bottlenecks',
      category: 'CHALLENGE',
      sector: 'MOBILITY',
      description: 'Peak-hour vehicle saturation causing average surface travel speeds to drop below 8 km/h.',
    }),
  });
  const editData2 = await editRes2.json();
  assert(editRes2.ok && editData2.success, 'Challenge card (card-031) edited and persisted');

  // Edit Constraint card (e.g. card-061)
  const editRes3 = await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-admin-key': 'ANEKAL2026' },
    body: JSON.stringify({
      cardId: 'card-061',
      name: 'Right-of-Way Acquisition Moratorium & Clearances',
      category: 'CONSTRAINT',
      sector: 'MOBILITY',
      description: 'Litigation and zoning moratoria preventing road widening.',
    }),
  });
  const editData3 = await editRes3.json();
  assert(editRes3.ok && editData3.success, 'Constraint card (card-061) edited and persisted');

  // Edit Impact card (e.g. card-091)
  const editRes4 = await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-admin-key': 'ANEKAL2026' },
    body: JSON.stringify({
      cardId: 'card-091',
      name: 'Multi-Modal Commute Time Reduction Benchmark',
      category: 'IMPACT',
      sector: 'MOBILITY',
      description: 'Achieves a 28% reduction in cross-city commuter travel time.',
    }),
  });
  const editData4 = await editRes4.json();
  assert(editRes4.ok && editData4.success, 'Impact card (card-091) edited and persisted');

  // Restore card-001 title to original official title
  await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-admin-key': 'ANEKAL2026' },
    body: JSON.stringify({
      cardId: 'card-001',
      name: 'Metropolitan Transit Authority',
      category: 'STAKEHOLDER',
      sector: 'MOBILITY',
      description: 'Governing body overseeing regional commuter rail, bus rapid transit, and multi-modal transit networks.',
    }),
  });

  // 3. Team Password Management & Verified Google Email
  // Test Team 1 login with initial password
  const t1Login = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ loginId: 'TEAM1', password: '00001', portal: 'team' }),
  });
  const t1LoginData = await t1Login.json();
  assert(t1Login.ok && t1LoginData.success, 'Team 1 logs in with initial password 00001');

  // Attempt forgot-password before email registration -> must be REJECTED (using unlinked TEAM2)
  const forgotBeforeReg = await fetch(`${BASE_URL}/api/team/forgot-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ loginId: 'TEAM2', email: 'unregistered@gmail.com' }),
  });
  const forgotBeforeRegData = await forgotBeforeReg.json();
  assert(
    !forgotBeforeReg.ok && forgotBeforeRegData.error.includes('Account setup required'),
    'Forgot password rejected when account has no verified Google email linked'
  );

  // Register Google email for Team 1
  const regEmail = await fetch(`${BASE_URL}/api/team/register-email`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      teamId: 'team-1',
      email: 'team1.strategy@gmail.com',
      currentPassword: '00001',
    }),
  });
  const regEmailData = await regEmail.json();
  assert(regEmail.ok && regEmailData.success, 'Team 1 Google email registration code generated');
  const code = regEmailData.verificationCodeForDev;

  // Verify email with wrong code -> REJECTED
  const wrongCode = await fetch(`${BASE_URL}/api/team/verify-email`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ teamId: 'team-1', code: '000000' }),
  });
  assert(!wrongCode.ok, 'Invalid verification code rejected');

  // Verify email with valid code -> ACCEPTED
  const validCode = await fetch(`${BASE_URL}/api/team/verify-email`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ teamId: 'team-1', code }),
  });
  const validCodeData = await validCode.json();
  assert(validCode.ok && validCodeData.success, 'Google email verified and linked to Team 1');

  // Prevent duplicate email assignment (Team 2 tries to use team1.strategy@gmail.com)
  const dupEmail = await fetch(`${BASE_URL}/api/team/register-email`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      teamId: 'team-2',
      email: 'team1.strategy@gmail.com',
      currentPassword: '00002',
    }),
  });
  const dupEmailData = await dupEmail.json();
  assert(!dupEmail.ok && dupEmailData.error.includes('already linked'), 'Duplicate email assignment to another team prevented');

  // Test Forgot Password workflow with registered email
  const forgotValid = await fetch(`${BASE_URL}/api/team/forgot-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ loginId: 'TEAM1', email: 'team1.strategy@gmail.com' }),
  });
  const forgotValidData = await forgotValid.json();
  assert(forgotValid.ok && forgotValidData.success && forgotValidData.resetToken, 'Forgot password dispatches reset token for verified email');

  // Reset password to new custom password
  const resetRes = await fetch(`${BASE_URL}/api/team/reset-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      loginId: 'TEAM1',
      resetToken: forgotValidData.resetToken,
      newPassword: 'Team1Custom#2026',
    }),
  });
  const resetData = await resetRes.json();
  assert(resetRes.ok && resetData.success, 'Team 1 sets custom password via reset token');

  // Old password 00001 must now be rejected
  const oldLogin = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ loginId: 'TEAM1', password: '00001', portal: 'team' }),
  });
  assert(!oldLogin.ok, 'Old password (00001) correctly rejected after password change');

  // New password must succeed
  const newLogin = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ loginId: 'TEAM1', password: 'Team1Custom#2026', portal: 'team' }),
  });
  const newLoginData = await newLogin.json();
  assert(newLogin.ok && newLoginData.success, 'Login with new custom password succeeds');

  // Change password while logged in via Team Portal account settings
  const changeRes = await fetch(`${BASE_URL}/api/team/change-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      teamId: 'team-1',
      currentPassword: 'Team1Custom#2026',
      newPassword: 'Team1Final#777',
    }),
  });
  const changeData = await changeRes.json();
  assert(changeRes.ok && changeData.success, 'Change password from Team Portal settings succeeds');

  // Verify Team 1 budget, spending, acquired cards remain completely preserved
  const stateAfter = await (await fetch(`${BASE_URL}/api/auction/state`)).json();
  const t1 = stateAfter.state.teams.find((t: any) => t.id === 'team-1');
  assert(t1.initialBudget === 100000000, 'Team 1 initial budget preserved at ₹10 Cr');
  assert(t1.remainingBudget === 100000000, 'Team 1 remaining budget preserved');
  assert(Array.isArray(t1.acquiredCards) && t1.acquiredCards.length === 0, 'Team 1 portfolio structure preserved');
  assert(t1.emailVerified === true && t1.registeredEmail === 'team1.strategy@gmail.com', 'Team 1 registered email verified');

  // Restore Team 1 password to standard 00001 for tournament uniformity
  await fetch(`${BASE_URL}/api/team/change-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      teamId: 'team-1',
      currentPassword: 'Team1Final#777',
      newPassword: '00001',
    }),
  });
  console.log('[Setup] Restored Team 1 password to 00001 for test baseline');

  console.log(`\n=== VERIFICATION COMPLETE: ${passCount} PASSED, ${failCount} FAILED ===`);
  if (failCount > 0) process.exit(1);
}

runTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
