/**
 * Comprehensive verification of Card Bank Management
 * Tests viewing all 120 cards, category breakdown, editing titles/descriptions/sectors,
 * security guardrails (rejecting non-admin requests), add/archive/delete controls,
 * and live synchronization across screens.
 */

const BASE_URL = 'http://localhost:3000';
const ADMIN_KEY = 'ANEKAL2026';

let passedTests = 0;
let totalTests = 0;

function assert(condition: boolean, message: string) {
  totalTests++;
  if (!condition) {
    console.error(`❌ FAILED: ${message}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  passedTests++;
  console.log(`✅ PASSED: ${message}`);
}

async function runTests() {
  console.log('🚀 Starting Card Bank Management Test Suite...\n');

  // Test 1: Fetch initial state
  console.log('--- Test 1: Card Bank Integrity (120 Cards, 30 per Category) ---');
  const res = await fetch(`${BASE_URL}/api/auction/state`);
  assert(res.ok, 'Fetched state successfully');
  const json = await res.json();
  const state = json.state || json;

  assert(Array.isArray(state.cards), 'state.cards is an array');
  assert(state.cards.length >= 120, `Card bank contains at least 120 cards (found: ${state.cards.length})`);

  const stakeholders = state.cards.filter((c: any) => c.category === 'STAKEHOLDER');
  const challenges = state.cards.filter((c: any) => c.category === 'CHALLENGE');
  const constraints = state.cards.filter((c: any) => c.category === 'CONSTRAINT');
  const impacts = state.cards.filter((c: any) => c.category === 'IMPACT');

  console.log(`Counts: Stakeholder=${stakeholders.length}, Challenge=${challenges.length}, Constraint=${constraints.length}, Impact=${impacts.length}`);
  assert(stakeholders.length >= 30, 'Contains at least 30 STAKEHOLDER cards');
  assert(challenges.length >= 30, 'Contains at least 30 CHALLENGE cards');
  assert(constraints.length >= 30, 'Contains at least 30 CONSTRAINT cards');
  assert(impacts.length >= 30, 'Contains at least 30 IMPACT cards');

  // Test 2: Admin Security & Protection (Reject Unauthorized Requests)
  console.log('\n--- Test 2: Security & Protection on Card Management Endpoints ---');
  const unauthEdit = await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      cardId: 'STK-01',
      name: 'Hacked Card Name',
    }),
  });
  assert(unauthEdit.status === 403, 'Unauthorized card edit rejected with HTTP 403 Forbidden');

  const unauthAdd = await fetch(`${BASE_URL}/api/cards/add`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Hacked New Card',
      category: 'STAKEHOLDER',
      sector: 'MOBILITY',
    }),
  });
  assert(unauthAdd.status === 403, 'Unauthorized card add rejected with HTTP 403 Forbidden');

  const unauthArchive = await fetch(`${BASE_URL}/api/cards/archive`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      cardId: 'STK-01',
      isArchived: true,
    }),
  });
  assert(unauthArchive.status === 403, 'Unauthorized card archive rejected with HTTP 403 Forbidden');

  const unauthDelete = await fetch(`${BASE_URL}/api/cards/delete`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cardId: 'STK-01' }),
  });
  assert(unauthDelete.status === 403, 'Unauthorized card delete rejected with HTTP 403 Forbidden');

  // Test 3: Authorized Card Edit
  console.log('\n--- Test 3: Authorized Card Editing & Synchronisation ---');
  const targetCard = state.cards.find((c: any) => c.category === 'STAKEHOLDER');
  assert(!!targetCard, 'Found target STAKEHOLDER card to edit');

  const originalName = targetCard.name;
  const updatedName = `${originalName} [Strategically Enhanced]`;
  const updatedDesc = 'Updated strategic description detailing metropolitan stakeholder responsibilities.';

  const editRes = await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-admin-key': ADMIN_KEY,
    },
    body: JSON.stringify({
      cardId: targetCard.id,
      name: updatedName,
      category: targetCard.category,
      sector: 'MOBILITY',
      description: updatedDesc,
    }),
  });

  assert(editRes.ok, 'Card edit request succeeded');
  const editData = await editRes.json();
  assert(editData.success === true, 'editData.success is true');
  assert(editData.card.name === updatedName, 'Updated card name reflects new title');
  assert(editData.card.id === targetCard.id, 'Card ID was strictly preserved');
  assert(editData.card.description === updatedDesc, 'Updated description matches');

  // Check state to confirm server state and currentAuction reflect changes if loaded
  if (editData.state.currentAuction?.cardId === targetCard.id) {
    assert(editData.state.currentAuction.card.name === updatedName, 'Live current auction card immediately updated name');
  }

  // Restore original card name
  const restoreRes = await fetch(`${BASE_URL}/api/cards/edit`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-admin-key': ADMIN_KEY,
    },
    body: JSON.stringify({
      cardId: targetCard.id,
      name: originalName,
      category: targetCard.category,
      sector: targetCard.sector,
      description: targetCard.description,
    }),
  });
  assert(restoreRes.ok, 'Restored original card details cleanly');

  // Test 4: Add New Card
  console.log('\n--- Test 4: Adding New Card to Repository ---');
  const addRes = await fetch(`${BASE_URL}/api/cards/add`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-admin-key': ADMIN_KEY,
    },
    body: JSON.stringify({
      name: 'Autonomous Metro Network Controller',
      category: 'IMPACT',
      sector: 'MOBILITY',
      description: 'AI-grounded intelligent signal control network increasing urban corridor throughput by 42%.',
    }),
  });

  assert(addRes.ok, 'Add card request succeeded');
  const addData = await addRes.json();
  assert(addData.success === true, 'addData.success is true');
  const createdCardId = addData.card.id;
  assert(!!createdCardId, `Created new card with ID: ${createdCardId}`);
  assert(addData.card.category === 'IMPACT', 'Created card has correct category IMPACT');
  assert(addData.state.cards.some((c: any) => c.id === createdCardId), 'New card is present in state.cards');
  assert(addData.state.auctionQueue.includes(createdCardId), 'New card was appended to state.auctionQueue');

  // Test 5: Archive and Unarchive Card
  console.log('\n--- Test 5: Card Archiving & Queue Management ---');
  const archiveRes = await fetch(`${BASE_URL}/api/cards/archive`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-admin-key': ADMIN_KEY,
    },
    body: JSON.stringify({
      cardId: createdCardId,
      isArchived: true,
    }),
  });
  assert(archiveRes.ok, 'Archive request succeeded');
  const archiveData = await archiveRes.json();
  assert(archiveData.card.status === 'ARCHIVED', 'Card status updated to ARCHIVED');
  assert(!archiveData.state.auctionQueue.includes(createdCardId), 'Archived card removed from active auction queue');

  // Unarchive
  const unarchiveRes = await fetch(`${BASE_URL}/api/cards/archive`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-admin-key': ADMIN_KEY,
    },
    body: JSON.stringify({
      cardId: createdCardId,
      isArchived: false,
    }),
  });
  assert(unarchiveRes.ok, 'Unarchive request succeeded');
  const unarchiveData = await unarchiveRes.json();
  assert(unarchiveData.card.status === 'AVAILABLE', 'Card status restored to AVAILABLE');
  assert(unarchiveData.state.auctionQueue.includes(createdCardId), 'Restored card added back to auction queue');

  // Test 6: Safe Deletion of Unreferenced Card
  console.log('\n--- Test 6: Safe Deletion of Unreferenced Card ---');
  const deleteRes = await fetch(`${BASE_URL}/api/cards/delete`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-admin-key': ADMIN_KEY,
    },
    body: JSON.stringify({ cardId: createdCardId }),
  });
  assert(deleteRes.ok, 'Delete request for unreferenced card succeeded');
  const deleteData = await deleteRes.json();
  assert(!deleteData.state.cards.some((c: any) => c.id === createdCardId), 'Deleted card removed from card bank');
  assert(!deleteData.state.auctionQueue.includes(createdCardId), 'Deleted card removed from auction queue');

  // Test 7: Safety Guardrails Against Deleting Active Auction Card
  console.log('\n--- Test 7: Safety Guardrails Against Deleting Active Auction Card ---');
  const currentAuctionCardId = deleteData.state.currentAuction?.cardId;
  if (currentAuctionCardId) {
    const blockedDelete = await fetch(`${BASE_URL}/api/cards/delete`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-key': ADMIN_KEY,
      },
      body: JSON.stringify({ cardId: currentAuctionCardId }),
    });
    assert(blockedDelete.status === 400, 'Attempt to delete active auction card correctly blocked with HTTP 400');
  }

  // Test 8: Verify Category Progression Sequence
  console.log('\n--- Test 8: Auction Category Sequence Preservation ---');
  const finalStateRes = await fetch(`${BASE_URL}/api/auction/state`);
  const finalJson = await finalStateRes.json();
  const finalState = finalJson.state || finalJson;
  const queueCards = finalState.auctionQueue.map((id: string) => finalState.cards.find((c: any) => c.id === id)).filter(Boolean);

  let seenChallenge = false;
  let seenConstraint = false;
  let seenImpact = false;
  let sequenceValid = true;

  for (const card of queueCards) {
    if (card.category === 'CHALLENGE') seenChallenge = true;
    if (card.category === 'CONSTRAINT') seenConstraint = true;
    if (card.category === 'IMPACT') seenImpact = true;

    if (!seenChallenge && card.category !== 'STAKEHOLDER') sequenceValid = false;
    if (seenChallenge && !seenConstraint && card.category === 'STAKEHOLDER') sequenceValid = false;
    if (seenConstraint && !seenImpact && (card.category === 'STAKEHOLDER' || card.category === 'CHALLENGE')) sequenceValid = false;
  }
  assert(sequenceValid, 'Auction queue preserves strict category order: Stakeholder -> Challenge -> Constraint -> Impact');

  console.log(`\n🎉 ALL ${passedTests}/${totalTests} TESTS PASSED CLEANLY! Card Bank Management is verified.`);
}

runTests().catch((err) => {
  console.error('\n❌ Test suite failed:', err);
  process.exit(1);
});
