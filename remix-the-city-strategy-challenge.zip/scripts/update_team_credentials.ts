import fs from 'fs';
import path from 'path';

const stateFile = path.join(process.cwd(), 'data', 'csc_state.json');

if (fs.existsSync(stateFile)) {
  const state = JSON.parse(fs.readFileSync(stateFile, 'utf-8'));
  if (state && Array.isArray(state.teams)) {
    for (let i = 1; i <= 30; i++) {
      const team = state.teams.find((t: any) => t.id === `team-${i}`);
      if (team) {
        team.loginId = `TEAM${i}`;
        team.plainPassword = i.toString().padStart(5, '0');
      }
    }
    fs.writeFileSync(stateFile, JSON.stringify(state, null, 2), 'utf-8');
    console.log('Successfully updated data/csc_state.json with TEAM1..TEAM30 credentials!');
  }
} else {
  console.log('csc_state.json does not exist yet; will be created on start.');
}
