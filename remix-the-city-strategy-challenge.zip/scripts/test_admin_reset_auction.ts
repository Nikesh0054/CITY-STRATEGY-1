/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import http from 'http';

function makeRequest(
  options: http.RequestOptions,
  bodyData?: any
): Promise<{ statusCode: number; headers: http.IncomingHttpHeaders; body: any }> {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ statusCode: res.statusCode || 0, headers: res.headers, body: parsed });
        } catch {
          resolve({ statusCode: res.statusCode || 0, headers: res.headers, body: data });
        }
      });
    });

    req.on('error', reject);

    if (bodyData) {
      req.setHeader('Content-Type', 'application/json');
      req.write(JSON.stringify(bodyData));
    }
    req.end();
  });
}

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`  FAIL: ${message}`);
    process.exit(1);
  }
  console.log(`  PASS: ${message}`);
}

async function runTests() {
  console.log('===============================================================');
  console.log('=== TEST SUITE: ADMIN-ONLY RESET AUCTION VERIFICATION ===');
  console.log('===============================================================\n');

  const PORT = 3000;

  // 1. TEST SECURITY: Unauthenticated / Team calls to /api/auction/reset must fail
  console.log('--- 1. Testing Administrator Authentication Enforcement ---');

  const unauthRes = await makeRequest({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/auction/reset',
    method: 'POST',
  }, {});
  assert(unauthRes.statusCode === 403, 'Unauthenticated POST /api/auction/reset returns 403 Forbidden');
  assert(unauthRes.body.success === false, 'Unauthenticated response indicates success: false');

  const teamAuthRes = await makeRequest({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/auction/reset',
    method: 'POST',
    headers: {
      'x-admin-key': '00001', // Team 1 password
    },
  }, { adminPassword: 'wrong_password' });
  assert(teamAuthRes.statusCode === 403, 'Team user credentials attempting reset returns 403 Forbidden');
  assert(teamAuthRes.body.error.includes('Only authenticated administrators'), 'Returns explicit error message blocking team users');

  // 2. TEST SETUP: Place a bid and complete a sale to mutate state
  console.log('\n--- 2. Setting up active auction progress (Bids & Sales) ---');
  
  // Fetch current state
  const stateRes1 = await makeRequest({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/auction/state',
    method: 'GET',
  });
  assert(stateRes1.statusCode === 200, 'Successfully fetched auction state');
  const currentState = stateRes1.body.state;
  const currentCard = currentState.currentAuction?.card;
  assert(!!currentCard, `Current auction has loaded card: "${currentCard?.name}"`);

  // Start timer / place bid on behalf of Team 1
  const bidRes = await makeRequest({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/auction/bid',
    method: 'POST',
  }, {
    teamId: 'team-1',
    amount: 2000000, // ₹20 Lakh
    isUnassignedAdmin: false,
  });
  console.log(`Bid status: ${bidRes.statusCode}`);

  // Confirm sale to Team 1 for ₹20 Lakh
  const sellRes = await makeRequest({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/auction/sell',
    method: 'POST',
  }, {
    teamId: 'team-1',
    amount: 2000000,
  });
  console.log(`Sell status: ${sellRes.statusCode}`);

  // Verify Team 1 has spent ₹20L and remaining is ₹9.80 Cr
  const stateRes2 = await makeRequest({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/auction/state',
    method: 'GET',
  });
  const team1Before = stateRes2.body.state.teams.find((t: any) => t.id === 'team-1');
  assert(team1Before.totalSpent > 0, `Team 1 totalSpent before reset is ₹${team1Before.totalSpent}`);
  assert(team1Before.remainingBudget < 100000000, `Team 1 remainingBudget before reset is ₹${team1Before.remainingBudget}`);
  assert(team1Before.acquiredCards.length > 0, `Team 1 acquiredCards before reset has ${team1Before.acquiredCards.length} cards`);
  assert(stateRes2.body.state.salesRegister.length > 0, `Sales register before reset has ${stateRes2.body.state.salesRegister.length} records`);

  // 3. EXECUTE AUTHORIZED RESET
  console.log('\n--- 3. Executing Authorized Admin RESET AUCTION ---');
  const resetRes = await makeRequest({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/auction/reset',
    method: 'POST',
    headers: {
      'x-admin-key': 'ANEKAL2026',
      'Authorization': 'Bearer ANEKAL2026',
    },
  }, {
    adminPassword: 'ANEKAL2026',
    adminUser: 'ALLIANCEONE2026',
  });

  assert(resetRes.statusCode === 200, 'POST /api/auction/reset with admin credentials returns 200 OK');
  assert(resetRes.body.success === true, 'Reset response body has success: true');
  assert(!!resetRes.body.state, 'Reset response returns full updated state');

  const resetState = resetRes.body.state;

  // 4. VERIFY FRESH STATE DETAILS
  console.log('\n--- 4. Verifying Reset State Requirements ---');

  // Verify Teams Preserved & Budgets Restored
  assert(Array.isArray(resetState.teams) && resetState.teams.length === 30, 'All 30 teams are preserved');
  for (let i = 1; i <= 30; i++) {
    const t = resetState.teams.find((team: any) => team.id === `team-${i}`);
    assert(!!t, `Team ${i} exists`);
    assert(t.loginId === `TEAM${i}`, `Team ${i} has user ID TEAM${i}`);
    assert(t.remainingBudget === 100000000, `Team ${i} budget restored to ₹10 Crore (100000000)`);
    assert(t.totalSpent === 0, `Team ${i} total spent restored to 0`);
    assert(t.acquiredCards.length === 0, `Team ${i} acquired cards portfolio is empty`);
    assert(t.categoryProgress.STAKEHOLDER === false, `Team ${i} categoryProgress for Stakeholder is false`);
    assert(t.categoryProgress.CHALLENGE === false, `Team ${i} categoryProgress for Challenge is false`);
    assert(t.categoryProgress.CONSTRAINT === false, `Team ${i} categoryProgress for Constraint is false`);
    assert(t.categoryProgress.IMPACT === false, `Team ${i} categoryProgress for Impact is false`);
    
    // Verify 5-char password with leading zeros preserved
    const expectedPass = i.toString().padStart(5, '0');
    assert(t.plainPassword === expectedPass, `Team ${i} password "${expectedPass}" preserved`);
  }

  // Verify Cards Preserved & Statuses Restored
  assert(Array.isArray(resetState.cards) && resetState.cards.length === 120, 'All 120 strategy cards are preserved');
  const availableCount = resetState.cards.filter((c: any) => c.status === 'AVAILABLE').length;
  const inAuctionCount = resetState.cards.filter((c: any) => c.status === 'IN_AUCTION').length;
  const soldCount = resetState.cards.filter((c: any) => c.status === 'SOLD').length;
  assert(soldCount === 0, 'Zero cards have SOLD status after reset');
  assert(inAuctionCount === 1, 'Exactly 1 card is loaded in auction (first Stakeholder card)');
  assert(availableCount === 119, 'Remaining 119 cards are in AVAILABLE status');

  // Verify Category Sequence Starts at Stakeholder
  const currentAuction = resetState.currentAuction;
  assert(!!currentAuction, 'currentAuction state exists');
  assert(currentAuction.status === 'READY', 'Auction status is READY (inactive until opened/started)');
  assert(currentAuction.timerSeconds === 60, 'Timer is reset to 60 seconds (01:00)');
  assert(currentAuction.timerIsRunning === false, 'Timer is NOT running (no auto-start on reset)');
  assert(currentAuction.timerDeadline === null, 'Timer deadline is null');
  assert(currentAuction.timerHasExtended === false, 'timerHasExtended is false');
  assert(currentAuction.bidCount === 0, 'bidCount is reset to 0');
  assert(currentAuction.currentBidder === null, 'currentBidder is null (no active bidder)');
  assert(currentAuction.currentBid === 1000000, 'currentBid reset to opening bid (₹10 Lakh)');
  assert(currentAuction.confirmedFinalBid === null, 'confirmedFinalBid is null');
  assert(currentAuction.completedSale === null, 'completedSale is null (no previous winning team)');

  assert(currentAuction.card?.category === 'STAKEHOLDER', 'Loaded card category is strictly STAKEHOLDER');

  // Verify Queue Sequence
  assert(resetState.auctionQueue.length === 120, 'Auction queue contains all 120 cards');
  const firstCardInQueue = resetState.cards.find((c: any) => c.id === resetState.auctionQueue[0]);
  assert(firstCardInQueue.category === 'STAKEHOLDER', 'Queue position #1 is a STAKEHOLDER card');

  // Verify Active Bids and Sales Cleared
  assert(resetState.bidHistory.length === 0, 'Active bid history is cleared to 0');
  assert(resetState.salesRegister.length === 0, 'Active sales register is cleared to 0');

  // Verify Archives and Audit Trail
  assert(Array.isArray(resetState.eventArchives) && resetState.eventArchives.length > 0, 'Prior event history safely preserved in eventArchives');
  const latestAuditLog = resetState.auditLogs[0];
  assert(latestAuditLog.action === 'RESET_AUCTION', 'Audit log records RESET_AUCTION action');
  assert(latestAuditLog.actor === 'ADMINISTRATOR', 'Audit log records actor as ADMINISTRATOR');

  console.log('\n===============================================================');
  console.log('=== ALL 52/52 ADMIN RESET VERIFICATION CHECKS PASSED! ===');
  console.log('===============================================================\n');
}

runTests().catch((err) => {
  console.error('Test execution error:', err);
  process.exit(1);
});
