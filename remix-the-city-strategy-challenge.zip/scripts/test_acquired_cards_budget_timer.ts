/**
 * Comprehensive Automated Verification Test for:
 * 1. Acquired Cards categorization and isolation
 * 2. Live Budget Status calculation & separation from active bids
 * 3. 60s Timer and one-time <=10s to 20s extension rule
 * 4. Undo Sale budget and portfolio restoration
 */

import { createDefaultState } from '../src/services/auctionStore';
import {
  OPENING_BID,
  INITIAL_TIMER_SECONDS,
  EXTENSION_THRESHOLD_SECONDS,
  EXTENSION_DURATION_SECONDS,
  checkTeamEligibility,
  getNextMinimumBid,
  validateBidAmount,
} from '../src/utils/auctionRules';

let passedTests = 0;
let totalTests = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    console.error(`  ✗ FAIL: ${testName}${detail ? ` - ${detail}` : ''}`);
    process.exitCode = 1;
  }
}

console.log('=== [1] TESTING AUCTION TIMER AND EXTENSION RULES (60s -> 20s if <=10s) ===');

// 1. Initial constants
assert(INITIAL_TIMER_SECONDS === 60, 'Initial timer seconds is exactly 60');
assert(EXTENSION_THRESHOLD_SECONDS === 10, 'Extension threshold is exactly 10 seconds');
assert(EXTENSION_DURATION_SECONDS === 20, 'Extension duration resets timer to 20 seconds');

const state = createDefaultState();
assert(state.currentAuction.timerSeconds === 60, 'Current auction starts with 60 seconds');
assert(state.currentAuction.timerHasExtended === false, 'timerHasExtended is false initially');

// Simulate bid at 15s remaining (should NOT trigger extension)
let timerSecs = 15;
let timerHasExtended = false;
if (timerSecs <= EXTENSION_THRESHOLD_SECONDS && !timerHasExtended) {
  timerHasExtended = true;
  timerSecs = EXTENSION_DURATION_SECONDS;
}
assert(!timerHasExtended && timerSecs === 15, 'Bid accepted at 15s does NOT trigger extension');

// Simulate bid at 10s remaining (SHOULD trigger extension to 20s)
timerSecs = 10;
if (timerSecs <= EXTENSION_THRESHOLD_SECONDS && !timerHasExtended) {
  timerHasExtended = true;
  timerSecs = EXTENSION_DURATION_SECONDS;
}
assert(timerHasExtended && timerSecs === 20, 'Bid accepted at 10s triggers reset to 20s and sets timerHasExtended=true');

// Simulate a second bid at 5s after extension was already used (SHOULD NOT trigger another extension)
timerSecs = 5;
let secondExtensionTriggered = false;
if (timerSecs <= EXTENSION_THRESHOLD_SECONDS && !timerHasExtended) {
  timerHasExtended = true;
  timerSecs = EXTENSION_DURATION_SECONDS;
  secondExtensionTriggered = true;
}
assert(!secondExtensionTriggered && timerSecs === 5, 'Second late bid does NOT grant a second extension (only 1 extension per card)');

// Simulate loading next card resets timer and extension flag
const nextCard = state.cards[1];
const resetAuctionState = {
  cardId: nextCard.id,
  card: nextCard,
  status: 'READY' as const,
  currentBid: OPENING_BID,
  timerSeconds: INITIAL_TIMER_SECONDS,
  timerHasExtended: false,
};
assert(resetAuctionState.timerSeconds === 60, 'Loading next card resets timer back to 60s');
assert(resetAuctionState.timerHasExtended === false, 'Loading next card resets timerHasExtended to false');

// Simulate bid accepted at 4s remaining on fresh card
let freshTimer = 4;
let freshHasExtended = false;
if (freshTimer <= EXTENSION_THRESHOLD_SECONDS && !freshHasExtended) {
  freshHasExtended = true;
  freshTimer = EXTENSION_DURATION_SECONDS;
}
assert(freshHasExtended && freshTimer === 20, 'Bid accepted at <=5s (e.g. 4s) correctly resets timer to 20s');

console.log('\n=== [2] TESTING LIVE BUDGET STATUS & SEPARATION FROM ACTIVE BIDS ===');

const team1 = state.teams.find((t) => t.id === 'team-1')!;
const team2 = state.teams.find((t) => t.id === 'team-2')!;

assert(team1.initialBudget === 100_000_000, 'Team 1 starts with ₹10 Cr initial budget');
assert(team1.totalSpent === 0, 'Team 1 starts with ₹0 total spent');
assert(team1.remainingBudget === 100_000_000, 'Team 1 starts with ₹10 Cr remaining budget');

// Simulate placing an active bid of ₹20 Lakh
const bidAmount = 2_000_000;
state.currentAuction.currentBid = bidAmount;
state.currentAuction.currentBidder = { id: team1.id, name: team1.name, isUnassignedAdmin: false };

// Check that placing a bid does NOT reduce remaining budget or increase totalSpent
assert(team1.remainingBudget === 100_000_000, 'Placing an active bid does NOT deduct from team remaining budget');
assert(team1.totalSpent === 0, 'Placing an active bid does NOT count toward totalSpent');
assert(team1.acquiredCards.length === 0, 'Placing an active bid does NOT add card to acquired portfolio');

console.log('\n=== [3] TESTING CONFIRMED SALE & TEAM PORTFOLIO ALLOCATION ===');

// Simulate administrator confirming sale to Team 1 for ₹20 Lakh
const cardToSell = state.cards[0];
const salePrice = 2_000_000;

team1.remainingBudget -= salePrice;
team1.totalSpent += salePrice;
team1.acquiredCards.push({
  cardId: cardToSell.id,
  cardName: cardToSell.name,
  category: cardToSell.category,
  sector: cardToSell.sector,
  amount: salePrice,
  timestamp: Date.now(),
  attemptId: 'att-test-1',
});
team1.categoryProgress[cardToSell.category] = true;
cardToSell.status = 'SOLD';

assert(team1.totalSpent === 2_000_000, 'Confirmed sale increases totalSpent to ₹20 Lakh');
assert(team1.remainingBudget === 98_000_000, 'Remaining budget is exactly 100,000,000 - 2,000,000 = 98,000,000');
assert(team1.remainingBudget === team1.initialBudget - team1.totalSpent, 'Remaining Budget = Starting Budget - Total Confirmed Spending strictly holds');
assert(team2.remainingBudget === 100_000_000, 'Non-winning team (Team 2) budget remains completely untouched');
assert(team1.acquiredCards.length === 1, 'Winning team portfolio now has 1 acquired card');
assert(team2.acquiredCards.length === 0, 'Team 2 portfolio remains empty (0 cards)');

console.log('\n=== [4] TESTING ACQUIRED CARDS CATEGORIZATION (4 CATEGORIES) ===');

const categories = ['STAKEHOLDER', 'CHALLENGE', 'CONSTRAINT', 'IMPACT'] as const;
for (const cat of categories) {
  const catCards = team1.acquiredCards.filter((ac) => ac.category === cat);
  if (cat === cardToSell.category) {
    assert(catCards.length === 1, `Category ${cat} shows 1 acquired card for Team 1`);
    assert(catCards[0].cardName === cardToSell.name, `Card name matches: ${catCards[0].cardName}`);
    assert(catCards[0].amount === salePrice, `Purchase price matches: ₹${catCards[0].amount}`);
  } else {
    assert(catCards.length === 0, `Category ${cat} is pending (0 cards) for Team 1`);
  }
}

// Eligibility test: Team 1 can no longer buy another card in cardToSell.category
const ineligibility = checkTeamEligibility(team1, cardToSell.category, 1_000_000);
assert(!ineligibility.eligible, 'Team 1 is ineligible to purchase another card in already owned category');

// Eligibility test: Team 1 IS eligible to buy card in a different category
const otherCat = categories.find((c) => c !== cardToSell.category)!;
const eligibilityOther = checkTeamEligibility(team1, otherCat, 1_000_000);
assert(eligibilityOther.eligible, `Team 1 remains eligible to purchase card in ${otherCat}`);

console.log('\n=== [5] TESTING UNDO SALE TRANSACTION RESTORATION ===');

// Undo sale
team1.remainingBudget += salePrice;
team1.totalSpent -= salePrice;
team1.acquiredCards = team1.acquiredCards.filter((ac) => ac.cardId !== cardToSell.id);
team1.categoryProgress[cardToSell.category] = false;
cardToSell.status = 'AVAILABLE';

assert(team1.totalSpent === 0, 'Undo Sale restores totalSpent to ₹0');
assert(team1.remainingBudget === 100_000_000, 'Undo Sale restores remaining budget to ₹10 Cr');
assert(team1.acquiredCards.length === 0, 'Undo Sale removes card from team acquired portfolio');
assert(cardToSell.status === 'AVAILABLE', 'Undo Sale returns card to AVAILABLE status in bank');

const eligibilityRestored = checkTeamEligibility(team1, cardToSell.category, 1_000_000);
assert(eligibilityRestored.eligible, 'Team 1 eligibility for original category is fully restored after undo');

console.log(`\n========================================`);
console.log(`RESULTS: ${passedTests}/${totalTests} TESTS PASSED`);
console.log(`========================================`);

if (passedTests !== totalTests) {
  process.exit(1);
}
